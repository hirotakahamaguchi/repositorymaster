import { z } from 'zod';
import {
  PUNCH_TYPES,
  PUNCH_SOURCES,
  WORK_PATTERN_TYPES,
  ROUNDING_MODES,
  LEAVE_TYPES,
  DAY_TYPES,
  ROLE_CODES,
} from './enums';

// ─── 共通 ──────────────────────────────────────────────────────────
export const uuid = z.string().uuid();
export const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'YYYY-MM-DD 形式で入力してください');
export const yearMonth = z.string().regex(/^\d{4}-\d{2}$/, 'YYYY-MM 形式で入力してください');
export const hhmm = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'HH:mm 形式で入力してください');
export const isoDateTime = z.string().datetime({ offset: true });

// ─── 認証 ──────────────────────────────────────────────────────────
export const LoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(4),
});
export type LoginInput = z.infer<typeof LoginSchema>;

export const ChangePasswordSchema = z.object({
  currentPassword: z.string().min(4),
  newPassword: z.string().min(8).max(72),
});
export type ChangePasswordInput = z.infer<typeof ChangePasswordSchema>;

// ─── 打刻 ──────────────────────────────────────────────────────────
export const CreatePunchSchema = z.object({
  punchType: z.enum(PUNCH_TYPES),
  /** クライアント側の打刻時刻 (ISO8601)。省略時はサーバ時刻 */
  punchedAt: isoDateTime.optional(),
  source: z.enum(PUNCH_SOURCES).default('WEB'),
  latitude: z.number().min(-90).max(90).optional(),
  longitude: z.number().min(-180).max(180).optional(),
  accuracyM: z.number().min(0).optional(),
  /** 二重送信防止の冪等キー（クライアント生成 UUID） */
  clientRequestId: uuid,
  deviceInfo: z.record(z.string(), z.unknown()).optional(),
  /** 管理者代理打刻時のみ */
  employeeId: uuid.optional(),
});
export type CreatePunchInput = z.infer<typeof CreatePunchSchema>;

// ─── 勤務パターン ──────────────────────────────────────────────────
export const BreakRuleSchema = z.object({ from: hhmm, to: hhmm });
export const RoundingSchema = z.object({
  unitMinutes: z.number().int().min(1).max(60).default(1),
  mode: z.enum(ROUNDING_MODES).default('NONE'),
});
export const WorkPatternRulesSchema = z.object({
  /** 所定始業・終業 (FIXED/SHIFT) */
  start: hhmm.optional(),
  end: hhmm.optional(),
  /** コアタイム (FLEX) */
  coreStart: hhmm.optional(),
  coreEnd: hhmm.optional(),
  /** フレキシブルタイム (FLEX) */
  flexStart: hhmm.optional(),
  flexEnd: hhmm.optional(),
  /** 1日の所定労働分 */
  scheduledMinutes: z.number().int().min(0).max(1440).default(480),
  /** 固定休憩。打刻休憩が無い場合はこの休憩を自動控除 */
  breaks: z.array(BreakRuleSchema).default([]),
  /** 法定休憩の自動控除 (6h超→45分, 8h超→60分) を強制するか */
  enforceLegalBreak: z.boolean().default(true),
  /** 出勤・退勤打刻の丸め */
  roundingIn: RoundingSchema.default({ unitMinutes: 1, mode: 'NONE' }),
  roundingOut: RoundingSchema.default({ unitMinutes: 1, mode: 'NONE' }),
  /** 所定労働日 (0=日 … 6=土) */
  workdays: z.array(z.number().int().min(0).max(6)).default([1, 2, 3, 4, 5]),
  /** 法定休日 (週1日)。省略時は日曜 */
  legalHolidayWeekday: z.number().int().min(0).max(6).default(0),
  /** 残業計算の基準: 所定超(SCHEDULED) / 法定超(LEGAL 8h) */
  overtimeBasis: z.enum(['SCHEDULED', 'LEGAL']).default('LEGAL'),
  /** この分数を超える未承認残業にフラグを立てる（短時間の残業は許容） */
  unapprovedOvertimeThresholdMinutes: z.number().int().min(0).max(480).default(30),
  /** 日付の切り替わり時刻（夜勤対応。例 "05:00"） */
  dayBoundary: hhmm.default('05:00'),
});
export type WorkPatternRules = z.infer<typeof WorkPatternRulesSchema>;

export const UpsertWorkPatternSchema = z.object({
  code: z.string().min(1).max(32),
  name: z.string().min(1).max(100),
  patternType: z.enum(WORK_PATTERN_TYPES),
  rules: WorkPatternRulesSchema,
  validFrom: isoDate,
  validTo: isoDate.nullable().optional(),
});
export type UpsertWorkPatternInput = z.infer<typeof UpsertWorkPatternSchema>;

export const AssignWorkPatternSchema = z.object({
  employeeId: uuid,
  workPatternId: uuid,
  validFrom: isoDate,
  validTo: isoDate.nullable().optional(),
});
export type AssignWorkPatternInput = z.infer<typeof AssignWorkPatternSchema>;

// ─── 従業員 ────────────────────────────────────────────────────────
export const UpsertEmployeeSchema = z.object({
  employeeCode: z.string().min(1).max(20),
  name: z.string().min(1).max(100),
  nameKana: z.string().max(100).optional(),
  email: z.string().email(),
  departmentId: uuid.nullable().optional(),
  hiredAt: isoDate,
  retiredAt: isoDate.nullable().optional(),
  roleCodes: z.array(z.enum(ROLE_CODES)).min(1).default(['EMPLOYEE']),
  /** 初期パスワード（ローカル認証時のみ） */
  password: z.string().min(8).optional(),
  workPatternId: uuid.optional(),
});
export type UpsertEmployeeInput = z.infer<typeof UpsertEmployeeSchema>;

export const UpsertDepartmentSchema = z.object({
  code: z.string().min(1).max(20),
  name: z.string().min(1).max(100),
  parentId: uuid.nullable().optional(),
  managerId: uuid.nullable().optional(),
});
export type UpsertDepartmentInput = z.infer<typeof UpsertDepartmentSchema>;

// ─── 勤怠修正 ──────────────────────────────────────────────────────
export const CorrectAttendanceSchema = z.object({
  clockInAt: isoDateTime.nullable().optional(),
  clockOutAt: isoDateTime.nullable().optional(),
  breakMinutes: z.number().int().min(0).max(1440).optional(),
  dayType: z.enum(DAY_TYPES).optional(),
  note: z.string().max(500).optional(),
  reason: z.string().min(1).max(500),
  /** 楽観ロック */
  version: z.number().int(),
});
export type CorrectAttendanceInput = z.infer<typeof CorrectAttendanceSchema>;

// ─── 申請 ──────────────────────────────────────────────────────────
export const CorrectionPayloadSchema = z.object({
  date: isoDate,
  clockInAt: isoDateTime.nullable().optional(),
  clockOutAt: isoDateTime.nullable().optional(),
  breakMinutes: z.number().int().min(0).optional(),
});
export const OvertimePayloadSchema = z.object({
  date: isoDate,
  plannedMinutes: z.number().int().min(1).max(720),
});
export const LeavePayloadSchema = z.object({
  dateFrom: isoDate,
  dateTo: isoDate,
  leaveType: z.enum(LEAVE_TYPES),
  /** 半休など */
  unit: z.enum(['FULL', 'AM', 'PM']).default('FULL'),
});
export const HolidayWorkPayloadSchema = z.object({
  date: isoDate,
  plannedStart: hhmm,
  plannedEnd: hhmm,
  compensatory: z.boolean().default(false),
});
export const LateEarlyPayloadSchema = z.object({
  date: isoDate,
  kind: z.enum(['LATE', 'EARLY']),
  minutes: z.number().int().min(1).max(720),
});

const reason = z.string().min(1).max(500);
export const CreateRequestSchema = z.discriminatedUnion('requestType', [
  z.object({ requestType: z.literal('CORRECTION'), reason, payload: CorrectionPayloadSchema }),
  z.object({ requestType: z.literal('OVERTIME'), reason, payload: OvertimePayloadSchema }),
  z.object({ requestType: z.literal('LEAVE'), reason, payload: LeavePayloadSchema }),
  z.object({ requestType: z.literal('HOLIDAY_WORK'), reason, payload: HolidayWorkPayloadSchema }),
  z.object({ requestType: z.literal('LATE_EARLY'), reason, payload: LateEarlyPayloadSchema }),
]);
export type CreateRequestInput = z.infer<typeof CreateRequestSchema>;

export const DecideRequestSchema = z.object({
  decision: z.enum(['APPROVED', 'REJECTED']),
  comment: z.string().max(500).optional(),
});
export type DecideRequestInput = z.infer<typeof DecideRequestSchema>;

// ─── 休日マスタ ────────────────────────────────────────────────────
export const UpsertHolidaySchema = z.object({
  date: isoDate,
  name: z.string().min(1).max(100),
  kind: z.enum(['NATIONAL', 'COMPANY']).default('COMPANY'),
});
export type UpsertHolidayInput = z.infer<typeof UpsertHolidaySchema>;

// ─── 休暇付与 ──────────────────────────────────────────────────────
export const GrantLeaveSchema = z.object({
  employeeId: uuid,
  leaveType: z.enum(LEAVE_TYPES),
  days: z.number().min(0.5).max(40),
  grantedAt: isoDate,
  expiresAt: isoDate,
  note: z.string().max(200).optional(),
});
export type GrantLeaveInput = z.infer<typeof GrantLeaveSchema>;

// ─── 月次締め ──────────────────────────────────────────────────────
export const CloseMonthSchema = z.object({
  yearMonth,
  employeeIds: z.array(uuid).optional(),
});
export type CloseMonthInput = z.infer<typeof CloseMonthSchema>;

// ─── 会社設定 ──────────────────────────────────────────────────────
export const CompanySettingsSchema = z.object({
  name: z.string().min(1).max(100),
  timezone: z.string().default('Asia/Tokyo'),
  /** 締め日 (1-28, 31=月末) */
  closingDay: z.number().int().min(1).max(31).default(31),
  officeLatitude: z.number().nullable().optional(),
  officeLongitude: z.number().nullable().optional(),
  geofenceRadiusM: z.number().int().min(10).max(100000).default(300),
  /** 法定時間外の上限警告 (月) */
  overtimeAlertMinutes: z.number().int().default(45 * 60),
  overtimeLimitMinutes: z.number().int().default(80 * 60),
});
export type CompanySettings = z.infer<typeof CompanySettingsSchema>;
