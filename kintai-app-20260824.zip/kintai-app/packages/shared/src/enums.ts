// ─── 共通の列挙値（API/Web で共有） ────────────────────────────────
export const PUNCH_TYPES = ['IN', 'OUT', 'BREAK_START', 'BREAK_END'] as const;
export type PunchType = (typeof PUNCH_TYPES)[number];

export const PUNCH_SOURCES = ['WEB', 'MOBILE', 'ICCARD', 'ADMIN', 'IMPORT'] as const;
export type PunchSource = (typeof PUNCH_SOURCES)[number];

export const ATTENDANCE_STATUSES = ['DRAFT', 'CONFIRMED', 'LOCKED'] as const;
export type AttendanceStatus = (typeof ATTENDANCE_STATUSES)[number];

export const DAY_TYPES = [
  'WORKDAY',
  'LEGAL_HOLIDAY',
  'NON_LEGAL_HOLIDAY',
  'COMPANY_HOLIDAY',
  'PAID_LEAVE',
  'SPECIAL_LEAVE',
  'ABSENCE',
] as const;
export type DayType = (typeof DAY_TYPES)[number];

export const WORK_PATTERN_TYPES = ['FIXED', 'SHIFT', 'FLEX', 'DISCRETIONARY'] as const;
export type WorkPatternType = (typeof WORK_PATTERN_TYPES)[number];

export const REQUEST_TYPES = ['CORRECTION', 'OVERTIME', 'LEAVE', 'HOLIDAY_WORK', 'LATE_EARLY'] as const;
export type RequestType = (typeof REQUEST_TYPES)[number];

export const REQUEST_STATUSES = ['DRAFT', 'PENDING', 'APPROVED', 'REJECTED', 'WITHDRAWN'] as const;
export type RequestStatus = (typeof REQUEST_STATUSES)[number];

export const APPROVAL_DECISIONS = ['PENDING', 'APPROVED', 'REJECTED', 'SKIPPED'] as const;
export type ApprovalDecision = (typeof APPROVAL_DECISIONS)[number];

export const LEAVE_TYPES = ['PAID', 'SPECIAL', 'COMPENSATORY', 'UNPAID'] as const;
export type LeaveType = (typeof LEAVE_TYPES)[number];

export const ROUNDING_MODES = ['NONE', 'FLOOR', 'CEIL', 'ROUND'] as const;
export type RoundingMode = (typeof ROUNDING_MODES)[number];

/** 権限コード。`resource:action:scope` 形式 */
export const PERMISSIONS = [
  'attendance:read:self',
  'attendance:read:department',
  'attendance:read:company',
  'attendance:write:department',
  'attendance:write:company',
  'punch:create:self',
  'punch:create:admin',
  'request:create:self',
  'request:approve:department',
  'request:approve:company',
  'employee:read:company',
  'employee:write:company',
  'master:write:company',
  'closing:execute:company',
  'export:csv:company',
  'audit:read:company',
] as const;
export type Permission = (typeof PERMISSIONS)[number];

export const ROLE_CODES = ['EMPLOYEE', 'MANAGER', 'HR', 'ADMIN'] as const;
export type RoleCode = (typeof ROLE_CODES)[number];

/** ロール → 権限 のデフォルト定義（seed で投入。DB 側で変更可能） */
export const DEFAULT_ROLE_PERMISSIONS: Record<RoleCode, Permission[]> = {
  EMPLOYEE: ['attendance:read:self', 'punch:create:self', 'request:create:self'],
  MANAGER: [
    'attendance:read:self',
    'punch:create:self',
    'request:create:self',
    'attendance:read:department',
    'attendance:write:department',
    'request:approve:department',
  ],
  HR: [
    'attendance:read:self',
    'punch:create:self',
    'request:create:self',
    'attendance:read:company',
    'attendance:write:company',
    'request:approve:company',
    'employee:read:company',
    'employee:write:company',
    'master:write:company',
    'closing:execute:company',
    'export:csv:company',
    'punch:create:admin',
    'audit:read:company',
  ],
  ADMIN: [...PERMISSIONS],
};

export const PUNCH_TYPE_LABEL: Record<PunchType, string> = {
  IN: '出勤',
  OUT: '退勤',
  BREAK_START: '休憩開始',
  BREAK_END: '休憩終了',
};
export const REQUEST_TYPE_LABEL: Record<RequestType, string> = {
  CORRECTION: '打刻修正',
  OVERTIME: '残業申請',
  LEAVE: '休暇申請',
  HOLIDAY_WORK: '休日出勤',
  LATE_EARLY: '遅刻・早退',
};
export const REQUEST_STATUS_LABEL: Record<RequestStatus, string> = {
  DRAFT: '下書き',
  PENDING: '承認待ち',
  APPROVED: '承認済',
  REJECTED: '却下',
  WITHDRAWN: '取下げ',
};
export const DAY_TYPE_LABEL: Record<DayType, string> = {
  WORKDAY: '出勤日',
  LEGAL_HOLIDAY: '法定休日',
  NON_LEGAL_HOLIDAY: '所定休日',
  COMPANY_HOLIDAY: '会社休日',
  PAID_LEAVE: '有給休暇',
  SPECIAL_LEAVE: '特別休暇',
  ABSENCE: '欠勤',
};
export const WORK_PATTERN_TYPE_LABEL: Record<WorkPatternType, string> = {
  FIXED: '固定時間制',
  SHIFT: 'シフト制',
  FLEX: 'フレックス',
  DISCRETIONARY: '裁量労働',
};
export const LEAVE_TYPE_LABEL: Record<LeaveType, string> = {
  PAID: '年次有給休暇',
  SPECIAL: '特別休暇',
  COMPENSATORY: '代休',
  UNPAID: '無給休暇',
};
export const ROLE_LABEL: Record<RoleCode, string> = {
  EMPLOYEE: '一般社員',
  MANAGER: '管理職',
  HR: '労務担当',
  ADMIN: 'システム管理者',
};
export const ATTENDANCE_STATUS_LABEL: Record<AttendanceStatus, string> = {
  DRAFT: '未確定',
  CONFIRMED: '確定',
  LOCKED: '締め済',
};
