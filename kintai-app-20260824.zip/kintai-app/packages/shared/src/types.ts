import type {
  AttendanceStatus,
  DayType,
  PunchSource,
  PunchType,
  RequestStatus,
  RequestType,
  ApprovalDecision,
  LeaveType,
  Permission,
  RoleCode,
  WorkPatternType,
} from './enums';
import type { WorkPatternRules, CompanySettings } from './schemas';

// ─── API レスポンス型（Web 側で使用） ──────────────────────────────
export interface ApiError {
  statusCode: number;
  message: string | string[];
  error?: string;
  issues?: { path: string; message: string }[];
}

export interface CurrentUser {
  id: string;
  employeeCode: string;
  name: string;
  email: string;
  companyId: string;
  companyName: string;
  departmentId: string | null;
  departmentName: string | null;
  roles: RoleCode[];
  permissions: Permission[];
  /** 管理対象の部署ID（MANAGER） */
  managedDepartmentIds: string[];
  settings: CompanySettings;
}

export interface EmployeeDto {
  id: string;
  employeeCode: string;
  name: string;
  nameKana: string | null;
  email: string;
  departmentId: string | null;
  departmentName: string | null;
  hiredAt: string;
  retiredAt: string | null;
  roles: RoleCode[];
  currentWorkPattern: { id: string; code: string; name: string } | null;
}

export interface DepartmentDto {
  id: string;
  code: string;
  name: string;
  parentId: string | null;
  managerId: string | null;
  managerName: string | null;
  headcount: number;
}

export interface PunchDto {
  id: string;
  employeeId: string;
  punchType: PunchType;
  punchedAt: string;
  receivedAt: string;
  source: PunchSource;
  latitude: number | null;
  longitude: number | null;
  accuracyM: number | null;
  geofenceOk: boolean | null;
  clockDriftSec: number | null;
}

export interface AttendanceDayDto {
  id: string;
  employeeId: string;
  employeeCode?: string;
  employeeName?: string;
  departmentName?: string | null;
  workDate: string;
  dayType: DayType;
  workPatternId: string | null;
  workPatternName?: string | null;
  clockInAt: string | null;
  clockOutAt: string | null;
  breakMinutes: number;
  workMinutes: number;
  scheduledMinutes: number;
  overtimeMinutes: number;
  legalOvertimeMinutes: number;
  lateNightMinutes: number;
  holidayWorkMinutes: number;
  lateMinutes: number;
  earlyLeaveMinutes: number;
  status: AttendanceStatus;
  note: string | null;
  flags: string[];
  version: number;
  calcVersion: number;
  updatedAt: string;
}

export interface AttendanceMonthSummary {
  yearMonth: string;
  employeeId: string;
  employeeName?: string;
  employeeCode?: string;
  departmentName?: string | null;
  scheduledDays: number;
  actualWorkDays: number;
  absenceDays: number;
  paidLeaveDays: number;
  workMinutes: number;
  overtimeMinutes: number;
  legalOvertimeMinutes: number;
  lateNightMinutes: number;
  holidayWorkMinutes: number;
  lateCount: number;
  earlyLeaveCount: number;
  alerts: string[];
  status: AttendanceStatus;
}

export interface AttendanceRevisionDto {
  id: string;
  attendanceDayId: string;
  version: number;
  before: Partial<AttendanceDayDto> | null;
  after: Partial<AttendanceDayDto>;
  reason: string;
  changedBy: { id: string; name: string } | null;
  requestId: string | null;
  changedAt: string;
}

export interface WorkPatternDto {
  id: string;
  code: string;
  name: string;
  patternType: WorkPatternType;
  rules: WorkPatternRules;
  validFrom: string;
  validTo: string | null;
  assignedCount: number;
}

export interface WorkPatternAssignmentDto {
  id: string;
  employeeId: string;
  workPatternId: string;
  workPatternName: string;
  validFrom: string;
  validTo: string | null;
}

export interface RequestDto {
  id: string;
  requestType: RequestType;
  employeeId: string;
  employeeName: string;
  employeeCode: string;
  departmentName: string | null;
  payload: Record<string, unknown>;
  reason: string;
  status: RequestStatus;
  targetDateFrom: string;
  targetDateTo: string;
  currentStep: number;
  approvals: {
    stepNo: number;
    /** DEPARTMENT_MANAGER | HR | EMPLOYEE */
    approverType: string;
    approverId: string | null;
    approverName: string | null;
    decision: ApprovalDecision;
    comment: string | null;
    decidedAt: string | null;
  }[];
  createdAt: string;
  updatedAt: string;
  canDecide?: boolean;
}

export interface LeaveBalanceDto {
  leaveType: LeaveType;
  grantedDays: number;
  usedDays: number;
  remainingDays: number;
  nextExpiry: { days: number; expiresAt: string } | null;
}

export interface HolidayDto {
  id: string;
  date: string;
  name: string;
  kind: 'NATIONAL' | 'COMPANY';
}

export interface MonthlyClosingDto {
  id: string;
  yearMonth: string;
  employeeId: string;
  employeeName: string;
  employeeCode: string;
  lockedAt: string;
  lockedByName: string;
  snapshot: AttendanceMonthSummary;
}

export interface AuditLogDto {
  id: string;
  actorId: string | null;
  actorName: string | null;
  action: string;
  targetType: string;
  targetId: string | null;
  detail: Record<string, unknown> | null;
  ip: string | null;
  createdAt: string;
}

export interface DashboardDto {
  today: string;
  todayAttendance: AttendanceDayDto | null;
  todayPunches: PunchDto[];
  lastPunch: PunchDto | null;
  /** 出勤中か */
  working: boolean;
  onBreak: boolean;
  monthSummary: AttendanceMonthSummary;
  pendingRequests: number;
  pendingApprovals: number;
  leaveBalances: LeaveBalanceDto[];
  geofence: { latitude: number; longitude: number; radiusM: number } | null;
}

export interface AdminDashboardDto {
  date: string;
  headcount: number;
  presentCount: number;
  leftCount: number;
  notYetCount: number;
  onLeaveCount: number;
  pendingApprovals: number;
  overtimeAlerts: { employeeId: string; name: string; overtimeMinutes: number; level: 'WARN' | 'LIMIT' }[];
  missingPunches: { employeeId: string; name: string; workDate: string; flags: string[] }[];
  unlockedMonths: string[];
}

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}
