# 引き継ぎ資料（kintai-app）

## 1. これは何か
100 名規模（→300 名）企業向けの出退勤管理アプリ一式です。打刻（GPS・オフライン対応）、勤怠照会、申請・承認、月次締め、給与 CSV 出力、各種マスタ管理、監査ログまで実装済みで、ローカルではインストール不要の PGlite（WASM 版 PostgreSQL）、本番では PostgreSQL（Aurora/RDS）で同じコードが動きます。

## 2. 動作要件
- Node.js 20 以上（開発時は 24 で検証）、npm 10 以上
- Docker / PostgreSQL は **不要**（本番相当で動かす場合のみ `docker compose`）
- OS: Windows / macOS / Linux

## 3. 最短セットアップ
```bash
npm install          # 依存関係（1〜2 分）
npm run dev          # API: http://localhost:3001 / Web: http://localhost:3100
```
初回起動時に `apps/api/.pgdata` に DB が作成され、マイグレーションとデモデータ（100 名・直近 3 か月）が自動投入されます。
やり直したいときは `npm run db:reset`。

デモアカウント（パスワードはすべて `password123`）

| ロール | メール |
|---|---|
| システム管理者 | admin@example.com |
| 労務担当 | hr@example.com |
| 管理職（開発1課） | manager@example.com |
| 一般社員 | employee@example.com |

## 4. 本番相当で動かす
```bash
docker compose up --build      # Postgres + API + Web (http://localhost:3100)
```
または既存の PostgreSQL に対して:
```bash
DATABASE_URL=postgres://user:pass@host:5432/kintai JWT_SECRET=... npm run build && npm run start -w @kintai/api
```
環境変数一覧は `apps/api/.env.example` / `apps/web/.env.example` を参照。`SEED_ON_EMPTY=false` でデモデータ投入を無効化してください。

## 5. ディレクトリ構成
```
apps/api/src/
  domain/attendance-calc.ts   勤怠計算（純粋関数。法改正時はここと CALC_VERSION を更新）
  db/migrations/*.sql         DDL（パーティション・EXCLUDE 制約含む）
  db/schema.ts                Drizzle スキーマ
  db/seed.ts                  デモデータ
  modules/<機能>/             auth / employees / work-patterns / holidays / punches /
                              attendance / requests / leaves / closings / dashboard / audit / jobs
apps/web/src/
  app/(app)/                  画面（従業員向け: /, /attendance, /requests, /approvals, /settings
                              管理者向け: /admin/*）
  components/                 UI キット・機能別コンポーネント
  lib/                        API クライアント・認証・フォーマット
packages/shared/src/          列挙・zod スキーマ・DTO 型（API と Web で共有）
docs/ARCHITECTURE.md          設計詳細（ER 図・再計算トリガ・権限・スケール方針）
apps/web/AGENT_NOTES.md       画面実装規約と API 一覧
```

## 6. テスト・品質
```bash
npm test          # API: 勤怠計算ユニット 21 件 + 結合テスト 9 件（インメモリ PGlite）
npm run typecheck # 全ワークスペースの型チェック
npm run build     # 本番ビルド
```

## 7. 運用上の注意
- **打刻ログは追記専用**（UPDATE/DELETE はトリガで拒否）。修正は勤怠日次（attendance_days）側で行い、履歴が残ります。
- **締め済み月は編集不可**。修正が必要な場合は「月次締め」画面で締め解除 → 修正 → 再締め。
- 打刻テーブルの月次パーティションは起動時と毎月 1 日に自動作成されます（+12 か月分）。
- 本番では JWT の `JWT_SECRET` を必ず変更し、`COOKIE_SECURE=true`、HTTPS 配下で運用してください。
- 認証を SSO にする場合は `apps/api/src/common/guards.ts` の `AuthGuard` を IdP のトークン検証に差し替えます（`employees.auth_subject` 列を用意済み）。

## 8. 既知の制約 / 今後の候補
- 通知（メール/Slack）は未実装（承認依頼・打刻漏れ通知など）。
- 打刻→再計算は同一プロセス内イベント。スケールアウト時は SQS 等のキューに置き換える（`PunchesService.onPunchCreated` がワーカーの処理内容）。
- 36 協定の年間上限（720h/年・複数月平均 80h）は月次アラートのみ。年間集計は `AttendanceCore.monthSummary` を拡張して追加可能。
- 給与 CSV の列定義は `apps/api/src/modules/closings/closings.module.ts` の `PAYROLL_CSV_COLUMNS` で変更できます。
