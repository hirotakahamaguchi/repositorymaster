# アーキテクチャ / 設計ドキュメント

## 1. 全体構成

```
┌──────────────┐   /api/* (rewrite)   ┌──────────────────┐        ┌────────────────────┐
│ Next.js (Web)│ ───────────────────▶ │ NestJS (API)     │ ─────▶ │ PostgreSQL          │
│ PWA / SP・PC │ ◀─────────────────── │ zod 検証 / RBAC  │        │ (Aurora / PGlite)   │
└──────────────┘   httpOnly Cookie    │ EventEmitter     │        └────────────────────┘
                                       │ Cron (夜間再計算) │
                                       └──────────────────┘
```

- **本番想定**: CloudFront + (Next.js on ECS Fargate) / ALB + (NestJS on ECS Fargate) / Aurora PostgreSQL / SQS (打刻→再計算) / EventBridge (定期ジョブ) / S3 (CSV) / Cognito or Auth0 (SSO)。
- **ローカル**: `npm run dev` のみ。PGlite（WASM 版 PostgreSQL）を `apps/api/.pgdata` に永続化。`DATABASE_URL` を与えれば同じコードが本物の PostgreSQL で動く。

## 2. ER 図

```mermaid
erDiagram
  companies ||--o{ departments : has
  companies ||--o{ employees : has
  companies ||--o{ roles : has
  companies ||--o{ work_patterns : has
  companies ||--o{ holidays : has
  companies ||--o{ approval_routes : has
  departments ||--o{ employees : belongs
  employees ||--o{ employee_roles : has
  roles ||--o{ employee_roles : has
  roles ||--o{ role_permissions : has
  permissions ||--o{ role_permissions : has
  employees ||--o{ employee_work_pattern_assignments : "期間付き割当"
  work_patterns ||--o{ employee_work_pattern_assignments : has
  employees ||--o{ time_punches : "打刻(追記専用・月次パーティション)"
  employees ||--o{ attendance_days : "日次勤怠(再計算可能)"
  work_patterns ||--o{ attendance_days : "適用パターン"
  attendance_days ||--o{ attendance_day_revisions : "修正履歴"
  employees ||--o{ requests : "申請"
  requests ||--o{ request_approvals : "承認ステップ"
  requests ||--o{ attendance_day_revisions : "反映元"
  employees ||--o{ leave_grants : "付与"
  employees ||--o{ leave_usages : "消化"
  requests ||--o{ leave_usages : "由来"
  employees ||--o{ monthly_closings : "月次締め(スナップショット)"
  companies ||--o{ csv_exports : "出力履歴"
  companies ||--o{ audit_logs : "監査"
```

DDL は [`apps/api/src/db/migrations/0001_init.sql`](../apps/api/src/db/migrations/0001_init.sql)、Drizzle 定義は [`apps/api/src/db/schema.ts`](../apps/api/src/db/schema.ts)。

### 主要テーブルの役割

| テーブル | 役割 | ポイント |
|---|---|---|
| `time_punches` | 打刻の **事実** | `punched_at`(端末時刻) と `received_at`(サーバ時刻) を両方保持し `clock_drift_sec` で乖離検知。GPS・ジオフェンス判定結果・冪等キー `client_request_id`。UPDATE/DELETE はトリガで拒否。`punched_at` で月次 RANGE パーティション（起動時/月次ジョブで自動作成） |
| `attendance_days` | 日次勤怠の **解釈** | 打刻 + 勤務パターン + 休日 + 手修正(`manual`) + 承認結果(`approvals`) から **再計算可能**。`flags` に打刻漏れ/未承認残業等。`version`(楽観ロック)、`calc_version`(計算ロジック版)、`status` DRAFT→CONFIRMED→LOCKED |
| `attendance_day_revisions` | 修正の **監査証跡** | 管理者修正・申請承認による変更のたびに before/after/理由/操作者/申請ID を INSERT |
| `work_patterns` + `employee_work_pattern_assignments` | 勤務制度 | ルールは JSONB（zod `WorkPatternRulesSchema` で検証）。従業員には `valid_from/valid_to` 付きで割当、`EXCLUDE USING gist` で期間重複を DB レベルで禁止 |
| `roles` / `permissions` / `role_permissions` / `employee_roles` | スコープ付き RBAC | 権限コードは `resource:action:scope`。`employee_roles.scope_type/scope_id` で部署スコープ。部署の `manager_id` も管理対象に含める |
| `requests` / `request_approvals` / `approval_routes` | 申請ワークフロー | 種別ごとの承認ルート（部署管理者 → 労務）。ステップ行を作成時に確定し、承認者不在は SKIPPED。最終承認で `attendance_days.manual/approvals` に反映 |
| `monthly_closings` | 月次の **確定** | 締め時に勤怠を LOCKED にし、集計スナップショットを JSONB で凍結。CSV はここから生成 |
| `csv_exports` / `audit_logs` | 運用 | 出力履歴（本番は S3 キー）、操作ログ |

## 3. 勤怠計算ロジック

`apps/api/src/domain/attendance-calc.ts` の `calculateAttendance()` は **純粋関数**。

入力: 勤務日 / TZ / パターン種別とルール / その日の打刻 / 休日種別 / 手修正 / 承認結果 / 現在時刻
出力: 日種別、出退勤、休憩、実労働、所定、所定外残業、法定外残業、深夜、休日労働、遅刻、早退、フラグ

処理順:
1. **日種別**: 手修正 > 承認済み終日休暇 > 会社休日/祝日 > 法定休日(週1日) > 所定休日 > 出勤日
2. **出退勤**: 手修正 > 最初の IN / 最後の OUT。打刻漏れ・ジオフェンス外をフラグ。丸め（切上/切捨/四捨五入 × 単位）
3. **休憩**: 休憩打刻があればそれを採用、無ければ固定休憩の重なり分、法定休憩（6h超45分/8h超60分）を強制可
4. **所定**: 出勤日のみ。半休は 1/2
5. **遅刻早退**: 固定/シフトは始業終業、フレックスはコアタイム。承認済みなら別フラグ
6. **残業**: 法定休日は全量「休日労働」、所定休日は法定外扱い、出勤日は所定超/法定8h超。承認残業分を超えたら未承認フラグ（閾値あり）。裁量労働はみなし
7. **深夜**: 22:00〜翌5:00 の重なりから休憩を控除

日付境界 (`dayBoundary`, 既定 05:00) により、夜勤の「翌朝の退勤」は前日の勤務日に帰属する。

**法改正時**: `LEGAL` 定数やロジックを変更し `CALC_VERSION` を上げる → 未締め月のみ再計算（`POST /attendance/recalc` またはジョブ）。締め済みはスナップショットが守られる。

## 4. 再計算のトリガ

| イベント | 再計算範囲 | 方式 |
|---|---|---|
| 打刻登録 | 当該従業員の前日〜当日 | `EventEmitter`（本番: SQS へ発行しワーカーが処理） |
| 勤怠の手修正 / 手修正解除 | 当日 | 同期（トランザクション内） |
| 申請承認 | 対象期間 | 同期（承認トランザクション内） |
| 勤務パターン割当/変更、休日マスタ変更 | 影響期間（会社全体） | 非同期（fire-and-forget。本番はジョブキュー） |
| 夜間 05:30 | 全従業員の直近 2 日 | Cron（退勤漏れフラグの確定など） |
| 月次締め | 対象月 | 締め直前に強制再計算してからロック |

## 5. 権限モデル

```
ADMIN    = 全権限
HR       = attendance:read/write:company, request:approve:company, employee:*, master:write, closing, export, audit, punch:create:admin
MANAGER  = attendance:read/write:department, request:approve:department (+ 一般社員権限)
EMPLOYEE = attendance:read:self, punch:create:self, request:create:self
```
- ハンドラは `@RequirePermissions(...)`（いずれか）で入口を絞り、`AccessService` が **対象従業員が自分/管理部署/全社のどれか** を確認する。
- 承認可否は `RequestsService.canDecide()`：HR ステップは会社承認権限者のみ、部署管理者ステップは指名された管理者（不在時は管理部署の承認権限者 or 会社承認権限者が代理）。

## 6. スケール・運用上の設計判断

1. **打刻は INSERT のみ・即応答**。集計は非同期。月末の打刻集中でも DB ロック競合が起きにくい。冪等キーでクライアント再送に強く、PWA 側はオフラインキューを持つ。
2. **パーティション**: `time_punches` は月次。`ensurePunchPartitions()` が起動時と毎月1日に +12 か月分を先行作成。古い月はパーティション単位でアーカイブ/DETACH 可能。
3. **読み取り負荷**: 管理画面の月次サマリは `attendance_days` の集計で十分だが、300 名超・複数年では `attendance_month_summaries`（マテビュー or 集計テーブル）を追加する余地を残している（`AttendanceCore.monthSummary` の差し替えで対応可能）。
4. **認証の差し替え**: `AuthService.loadUser()` は JWT の `sub` からユーザを組み立てるだけなので、Cognito/Auth0 の ID トークン検証に `AuthGuard` を差し替えれば SSO 化できる（`employees.auth_subject` を用意済み）。
5. **マルチテナント準備**: 主要テーブルに `company_id`。1 社運用でも将来のグループ会社展開に備える。
6. **監査**: 重要操作は `audit_logs`、勤怠値の変更は `attendance_day_revisions` に必ず残す（労基署対応）。
7. **CSV/締め**: 締めスナップショットから出力するため、後からマスタやロジックが変わっても過去の給与データは不変。

## 7. API 一覧

`apps/web/AGENT_NOTES.md` の「API 一覧」を参照（全エンドポイントと入出力型）。

## 8. テスト戦略

- ドメイン計算: 純粋関数のユニットテスト（`attendance-calc.test.ts`）。法改正・ルール追加時はここにケースを追加。
- API: インメモリ PGlite で Nest を起動する結合テスト（`app.e2e.test.ts`）。本物の PostgreSQL を CI で使う場合は `DATABASE_URL` を与えるだけ。
