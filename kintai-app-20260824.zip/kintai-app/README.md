# 勤怠管理アプリ（kintai-app）

100 名規模（→300 名）の企業向け **出退勤管理アプリ**。打刻（GPS・オフライン対応）、勤怠照会、申請・承認ワークフロー、月次締め、給与システム向け CSV 出力を備えたフルスタック実装です。

| レイヤ | 技術 |
|---|---|
| Web / モバイル | **Next.js 16 (App Router) + React 19 + TypeScript + Tailwind CSS v4**、PWA（ホーム画面追加・オフライン打刻キュー） |
| API | **NestJS 11 + TypeScript**、zod による入力検証（スキーマはフロントと共有） |
| DB | **PostgreSQL**（本番: Aurora/RDS）。ローカルは **PGlite（WASM 版 PostgreSQL）** を同一 SQL で利用、Docker 不要 |
| ORM | **Drizzle ORM**（型安全クエリ）＋ 手書き SQL マイグレーション（パーティション・EXCLUDE 制約） |
| 認証 | JWT（httpOnly Cookie）。本番は Cognito/Auth0 の OIDC/SAML に差し替え前提 |
| 非同期 | Nest EventEmitter（打刻 → 再計算）、@nestjs/schedule（夜間再計算・パーティション作成）。本番は SQS/EventBridge に置換可能 |

```
kintai-app/
├─ apps/
│  ├─ api/   NestJS API（src/modules/* 機能別モジュール、src/domain/* 純粋な勤怠計算ロジック）
│  └─ web/   Next.js フロント（src/app/(app)/* 画面、src/components/* UI）
├─ packages/
│  └─ shared/ 列挙・zod スキーマ・DTO 型・ユーティリティ（API/Web 共有）
├─ docs/ARCHITECTURE.md  設計ドキュメント（ER 図・計算ロジック・スケール方針）
├─ docker-compose.yml    PostgreSQL + API + Web（本番相当構成の確認用）
└─ package.json          npm workspaces
```

---

## クイックスタート（Docker 不要）

```bash
npm install
npm run dev
```

- Web: http://localhost:3100  API: http://localhost:3001
- 初回起動時に PGlite（`apps/api/.pgdata`）へマイグレーションと **デモデータ（100 名・直近 3 か月の打刻・申請・締め）** が自動投入されます。

### デモアカウント（パスワードは全て `password123`）

| ロール | メール | できること |
|---|---|---|
| システム管理者 | admin@example.com | 全機能 |
| 労務担当 (HR) | hr@example.com | 全社勤怠の閲覧/修正、申請の最終承認、マスタ管理、締め・CSV、監査ログ |
| 管理職（開発1課） | manager@example.com | 自部署の勤怠閲覧/修正、自部署の申請の一次承認 |
| 一般社員 | employee@example.com | 打刻、勤怠照会、申請 |

他に `emp005@example.com` … `emp100@example.com`（一般社員／各部署の管理職）が存在します。

### 主なコマンド

| コマンド | 内容 |
|---|---|
| `npm run dev` | shared をビルドし、API (watch) と Web (dev) を同時起動 |
| `npm run build` | shared → api → web を本番ビルド |
| `npm test` | API のユニットテスト（勤怠計算）＋ 結合テスト（インメモリ PGlite で Nest を起動し主要フローを検証） |
| `npm run typecheck` | 全ワークスペースの型チェック |
| `npm run db:reset` | ローカル DB を削除 → マイグレーション → シード |
| `npm run db:migrate` / `db:seed` | マイグレーション適用 / シード（空のときのみ） |

### PostgreSQL（本番相当）で動かす

```bash
docker compose up -d postgres
DATABASE_URL=postgres://kintai:kintai@localhost:5432/kintai npm run dev:api
```

または `docker compose up --build` で Postgres + API + Web をまとめて起動できます（Web: http://localhost:3100）。

環境変数は `apps/api/.env.example` / `apps/web/.env.example` を参照。

---

## 機能一覧

### 従業員（スマホ / PC）
- **打刻**：出勤・退勤・休憩開始/終了。GPS を取得しオフィスからの距離・ジオフェンス内外を記録（打刻は拒否せず記録のみ → 管理者がフラグで確認）。端末時刻とサーバ時刻の乖離も記録。
- **オフライン打刻**：通信断時は端末に保存し、復帰後に自動再送（`clientRequestId` による冪等性でサーバ側の二重登録を防止）。
- **勤怠照会**：月次カレンダー、実労働・残業・深夜・遅刻早退、フラグ（打刻漏れ・未承認残業など）、打刻ログ、修正履歴。
- **申請**：打刻修正 / 残業 / 休暇（終日・半休）/ 休日出勤（代休付与）/ 遅刻早退。休暇残日数チェック、承認状況の可視化、取下げ。
- **PWA**：ホーム画面に追加してアプリとして利用可能。

### 管理者・労務（PC）
- **管理ダッシュボード**：出勤状況、残業アラート（45h/80h）、打刻漏れ、未締め月。
- **勤怠管理**：部署別・月次サマリ、要確認日一覧、従業員別の日次編集（楽観ロック・理由必須・全履歴保存）、手修正解除、月次確定。
- **承認**：受信箱（自分が承認者のもの / 部署 / 全社）、2 段階承認ルート（部署管理者 → 労務）、一括承認、却下コメント。
- **マスタ**：従業員（ロール・勤務パターン履歴・休暇付与）、部署（管理者設定）、勤務パターン（固定/シフト/フレックス/裁量、丸め、休憩、日付境界）、休日カレンダー、会社設定（ジオフェンス、残業閾値、締め日）。
- **月次締め / CSV**：締め前チェック（打刻漏れ）、強制締め、締め解除、給与システム向け CSV（UTF-8 BOM / Shift_JIS、締め済スナップショットから生成）、出力履歴。
- **監査ログ**：ログイン・修正・承認・締め・出力などの操作履歴。

---

## 設計のポイント（提案書との対応）

- **「事実 → 解釈 → 確定」の 3 層**：`time_punches`（追記専用、UPDATE/DELETE をトリガで禁止、月次パーティション）→ `attendance_days`（打刻から再計算可能、手修正は `manual`、承認結果は `approvals` に保持）→ `monthly_closings`（締め時点のスナップショットを凍結）。
- **修正履歴**：`attendance_day_revisions` に before/after・理由・操作者・紐づく申請 ID を毎回保存。
- **勤務パターン**：`work_patterns.rules (jsonb)` を zod スキーマで検証。従業員には **期間付きで割当**（`employee_work_pattern_assignments`、EXCLUDE 制約で期間重複を禁止）。
- **スコープ付き RBAC**：`roles` × `permissions`（`resource:action:scope`）＋ `employee_roles.scope`。管理職は自部署のみ、労務は全社。
- **計算ロジックの分離**：`apps/api/src/domain/attendance-calc.ts` は純粋関数。`CALC_VERSION` と `LEGAL` 定数で法改正を吸収し、`attendance_days.calc_version` でどの版で計算されたかを追跡。
- **月末集中への備え**：打刻 API は INSERT のみで即時応答、集計はイベント駆動で非同期。CSV/締めはスナップショットから生成。詳細は [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)。

## テスト

```bash
npm test
```

- `apps/api/src/domain/attendance-calc.test.ts`：固定・フレックス・夜勤・裁量、休憩控除、丸め、遅刻早退、休日労働、半休、承認済み残業 等 21 ケース
- `apps/api/src/app.e2e.test.ts`：ログイン/権限スコープ、打刻の冪等性・ジオフェンス、休暇申請の 2 段階承認と勤怠反映、楽観ロック、締め→CSV→締め解除、監査ログ

## ライセンス

社内利用を想定したサンプル実装です。
