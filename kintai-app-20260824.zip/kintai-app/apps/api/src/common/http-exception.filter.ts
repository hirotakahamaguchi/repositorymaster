import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import type { Response } from 'express';

@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  private readonly logger = new Logger('HTTP');

  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const res = ctx.getResponse<Response>();
    const req = ctx.getRequest<{ method: string; url: string }>();

    if (exception instanceof HttpException) {
      const status = exception.getStatus();
      const body = exception.getResponse();
      const payload = typeof body === 'string' ? { statusCode: status, message: body } : (body as object);
      if (status >= 500) this.logger.error(`${req.method} ${req.url} → ${status}`, (exception as Error).stack);
      return res.status(status).json(payload);
    }

    // PostgreSQL の一意制約違反などをわかりやすく変換
    const err = exception as { code?: string; detail?: string; message?: string; stack?: string };
    if (err?.code === '23505') {
      return res.status(HttpStatus.CONFLICT).json({ statusCode: 409, error: 'Conflict', message: '既に同じデータが存在します', detail: err.detail });
    }
    if (err?.code === '23P01') {
      return res.status(HttpStatus.CONFLICT).json({ statusCode: 409, error: 'Conflict', message: '期間が重複しています', detail: err.detail });
    }
    if (err?.code === '23503') {
      return res.status(HttpStatus.BAD_REQUEST).json({ statusCode: 400, error: 'BadRequest', message: '参照先のデータが存在しません', detail: err.detail });
    }
    this.logger.error(`${req.method} ${req.url} → 500 ${err?.message}`, err?.stack);
    return res.status(500).json({ statusCode: 500, error: 'InternalServerError', message: 'サーバ内部エラーが発生しました' });
  }
}
