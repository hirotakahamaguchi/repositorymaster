import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import type { Request } from 'express';
import type { Permission } from '@kintai/shared';
import { IS_PUBLIC_KEY, PERMISSIONS_KEY } from './decorators';
import { AuthService } from '../modules/auth/auth.service';
import { hasPermission } from './auth-user';

export const AUTH_COOKIE = 'kintai_token';

function extractToken(req: Request): string | null {
  const h = req.headers.authorization;
  if (h && h.startsWith('Bearer ')) return h.slice(7);
  const cookie = (req as unknown as { cookies?: Record<string, string> }).cookies?.[AUTH_COOKIE];
  return cookie ?? null;
}

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly jwt: JwtService,
    private readonly auth: AuthService,
  ) {}

  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [ctx.getHandler(), ctx.getClass()]);
    if (isPublic) return true;
    const req = ctx.switchToHttp().getRequest<Request>();
    const token = extractToken(req);
    if (!token) throw new UnauthorizedException('ログインが必要です');
    let payload: { sub: string };
    try {
      payload = await this.jwt.verifyAsync(token);
    } catch {
      throw new UnauthorizedException('セッションが無効です。再ログインしてください');
    }
    const user = await this.auth.loadUser(payload.sub);
    if (!user) throw new UnauthorizedException('ユーザが見つかりません');
    (req as unknown as { user: unknown }).user = user;
    return true;
  }
}

@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(ctx: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<Permission[] | undefined>(PERMISSIONS_KEY, [
      ctx.getHandler(),
      ctx.getClass(),
    ]);
    if (!required || required.length === 0) return true;
    const req = ctx.switchToHttp().getRequest();
    const user = req.user;
    if (!user) throw new UnauthorizedException();
    if (!hasPermission(user, ...required)) throw new ForbiddenException('この操作を行う権限がありません');
    return true;
  }
}
