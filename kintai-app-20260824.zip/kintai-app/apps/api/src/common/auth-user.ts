import type { Permission, RoleCode, CompanySettings } from '@kintai/shared';

/** リクエストに付与される認証済みユーザ情報 */
export interface AuthUser {
  id: string;
  employeeCode: string;
  name: string;
  email: string;
  companyId: string;
  companyName: string;
  timezone: string;
  settings: CompanySettings;
  departmentId: string | null;
  departmentName: string | null;
  roles: RoleCode[];
  permissions: Permission[];
  /** 管理対象部署（自身が manager の部署 + DEPARTMENT スコープのロール） */
  managedDepartmentIds: string[];
}

export function hasPermission(user: AuthUser, ...perms: Permission[]): boolean {
  return perms.some((p) => user.permissions.includes(p));
}
