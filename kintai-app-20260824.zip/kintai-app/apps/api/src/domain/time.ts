import { localDateTimeToUtc, toLocalDate, addDays, hmToMinutes, tzOffsetMinutes } from '@kintai/shared';

export { localDateTimeToUtc, toLocalDate, addDays, hmToMinutes };

/** 打刻時刻が属する勤務日（dayBoundary 以前は前日扱い。夜勤対応） */
export function workDateOf(punchedAt: Date, timezone: string, dayBoundary = '05:00'): string {
  const local = toLocalDate(punchedAt, timezone);
  const boundary = localDateTimeToUtc(local, dayBoundary, timezone);
  return punchedAt.getTime() < boundary.getTime() ? addDays(local, -1) : local;
}

/** 勤務日 D の打刻ウィンドウ [D boundary, D+1 boundary) */
export function workDateWindow(workDate: string, timezone: string, dayBoundary = '05:00'): { start: Date; end: Date } {
  return {
    start: localDateTimeToUtc(workDate, dayBoundary, timezone),
    end: localDateTimeToUtc(addDays(workDate, 1), dayBoundary, timezone),
  };
}

/** 2区間の重なり (分) */
export function overlapMinutes(aStart: Date, aEnd: Date, bStart: Date, bEnd: Date): number {
  const s = Math.max(aStart.getTime(), bStart.getTime());
  const e = Math.min(aEnd.getTime(), bEnd.getTime());
  return e > s ? Math.round((e - s) / 60_000) : 0;
}

export function diffMinutes(a: Date, b: Date): number {
  return Math.round((b.getTime() - a.getTime()) / 60_000);
}

export type RoundMode = 'NONE' | 'FLOOR' | 'CEIL' | 'ROUND';

/** 時刻を unit 分単位で丸める（分未満は切り捨ててから丸め） */
export function roundTime(d: Date, unitMinutes: number, mode: RoundMode): Date {
  const ms = d.getTime();
  const minuteMs = 60_000;
  const floored = Math.floor(ms / minuteMs) * minuteMs;
  if (mode === 'NONE' || unitMinutes <= 1) return new Date(floored);
  const unit = unitMinutes * minuteMs;
  // TZ に依存しないよう「その日の 00:00 UTC からの経過」ではなく単純に epoch 基準で丸める。
  // 丸め単位が 60 の約数である限り、結果はローカル時刻の分単位丸めと一致する。
  let r: number;
  if (mode === 'FLOOR') r = Math.floor(floored / unit) * unit;
  else if (mode === 'CEIL') r = Math.ceil(floored / unit) * unit;
  else r = Math.round(floored / unit) * unit;
  return new Date(r);
}

export function localWeekday(workDate: string): number {
  const [y, m, d] = workDate.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
}

export function yearMonthOf(workDate: string): string {
  return workDate.slice(0, 7);
}

export function monthRange(yearMonth: string): { from: string; to: string } {
  const [y, m] = yearMonth.split('-').map(Number);
  const last = new Date(Date.UTC(y, m, 0)).getUTCDate();
  return { from: `${yearMonth}-01`, to: `${yearMonth}-${String(last).padStart(2, '0')}` };
}

export function eachDate(from: string, to: string): string[] {
  const out: string[] = [];
  let d = from;
  while (d <= to) {
    out.push(d);
    d = addDays(d, 1);
  }
  return out;
}

export function nowLocalDate(timezone: string, now = new Date()): string {
  return toLocalDate(now, timezone);
}

export { tzOffsetMinutes };
