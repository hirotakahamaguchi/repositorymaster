/**
 * 日次勤怠 計算ロジック（純粋関数・副作用なし）
 *
 * 入力: 勤務日 / 勤務パターンのルール / その日の打刻 / 休日情報 / 手修正値 / 承認済み申請
 * 出力: 労働時間・残業・深夜・休日労働・遅刻早退・フラグ
 *
 * ※ ルール変更時は CALC_VERSION を上げ、attendance_days.calc_version で「どの版で計算したか」を追跡する
 */
import type { DayType, PunchType, WorkPatternRules, WorkPatternType } from '@kintai/shared';
import type { AttendanceApprovals, AttendanceManual } from '../db/schema';
import {
  localDateTimeToUtc,
  addDays,
  overlapMinutes,
  diffMinutes,
  roundTime,
  localWeekday,
  hmToMinutes,
} from './time';

export const CALC_VERSION = 1;

/** 労基法由来の定数。法改正時はここを変更し CALC_VERSION を上げる */
export const LEGAL = {
  dailyLegalMinutes: 8 * 60,
  lateNightStart: '22:00',
  lateNightEnd: '05:00',
  /** 労働時間 >6h → 45分, >8h → 60分 の休憩 */
  breakOver6h: 45,
  breakOver8h: 60,
};

export interface CalcPunch {
  punchType: PunchType;
  punchedAt: Date;
  geofenceOk: boolean | null;
}

export interface CalcInput {
  workDate: string;
  timezone: string;
  patternType: WorkPatternType;
  rules: WorkPatternRules;
  punches: CalcPunch[];
  /** 会社休日/祝日 */
  holidayKind: 'NATIONAL' | 'COMPANY' | null;
  manual: AttendanceManual;
  approvals: AttendanceApprovals;
  /** 現在時刻（退勤漏れ判定用） */
  now: Date;
}

export interface CalcResult {
  dayType: DayType;
  clockInAt: Date | null;
  clockOutAt: Date | null;
  breakMinutes: number;
  workMinutes: number;
  scheduledMinutes: number;
  overtimeMinutes: number;
  legalOvertimeMinutes: number;
  lateNightMinutes: number;
  holidayWorkMinutes: number;
  lateMinutes: number;
  earlyLeaveMinutes: number;
  flags: string[];
}

export const FLAGS = {
  MISSING_IN: 'MISSING_IN',
  MISSING_OUT: 'MISSING_OUT',
  NO_PUNCH: 'NO_PUNCH',
  BREAK_ADJUSTED: 'BREAK_ADJUSTED',
  UNAPPROVED_OVERTIME: 'UNAPPROVED_OVERTIME',
  UNAPPROVED_HOLIDAY_WORK: 'UNAPPROVED_HOLIDAY_WORK',
  WORK_ON_LEAVE: 'WORK_ON_LEAVE',
  GEOFENCE_NG: 'GEOFENCE_NG',
  LATE: 'LATE',
  LATE_APPROVED: 'LATE_APPROVED',
  EARLY_LEAVE: 'EARLY_LEAVE',
  EARLY_APPROVED: 'EARLY_APPROVED',
  HALF_LEAVE_AM: 'HALF_LEAVE_AM',
  HALF_LEAVE_PM: 'HALF_LEAVE_PM',
  MANUAL: 'MANUAL',
  CORE_TIME_VIOLATION: 'CORE_TIME_VIOLATION',
  OVER_12H: 'OVER_12H',
} as const;

export const FLAG_LABEL: Record<string, string> = {
  MISSING_IN: '出勤打刻なし',
  MISSING_OUT: '退勤打刻なし',
  NO_PUNCH: '打刻なし',
  BREAK_ADJUSTED: '法定休憩を自動控除',
  UNAPPROVED_OVERTIME: '未承認残業',
  UNAPPROVED_HOLIDAY_WORK: '未承認休日出勤',
  WORK_ON_LEAVE: '休暇日に勤務',
  GEOFENCE_NG: '勤務地外打刻',
  LATE: '遅刻',
  LATE_APPROVED: '遅刻(承認済)',
  EARLY_LEAVE: '早退',
  EARLY_APPROVED: '早退(承認済)',
  HALF_LEAVE_AM: '午前半休',
  HALF_LEAVE_PM: '午後半休',
  MANUAL: '手修正あり',
  CORE_TIME_VIOLATION: 'コアタイム違反',
  OVER_12H: '12時間超勤務',
};

function leaveDayType(leaveType: string): DayType {
  return leaveType === 'PAID' ? 'PAID_LEAVE' : 'SPECIAL_LEAVE';
}

/** 休憩区間（打刻ベース） */
function punchBreakIntervals(punches: CalcPunch[], clockOut: Date | null): { start: Date; end: Date }[] {
  const out: { start: Date; end: Date }[] = [];
  let open: Date | null = null;
  for (const p of punches) {
    if (p.punchType === 'BREAK_START' && !open) open = p.punchedAt;
    else if (p.punchType === 'BREAK_END' && open) {
      out.push({ start: open, end: p.punchedAt });
      open = null;
    }
  }
  // 休憩開始のまま退勤した場合は退勤時刻で閉じる
  if (open && clockOut && clockOut > open) out.push({ start: open, end: clockOut });
  return out;
}

export function calculateAttendance(input: CalcInput): CalcResult {
  const { workDate, timezone, rules, patternType, punches, manual, approvals } = input;
  const flags = new Set<string>();
  const tz = timezone;
  const at = (hm: string, dayOffset = 0) => localDateTimeToUtc(addDays(workDate, dayOffset), hm, tz);
  /** 勤務日ウィンドウは dayBoundary から始まるため、それより前の HH:mm は翌日側に属する */
  const dayOf = (hm: string) => (hmToMinutes(hm) < hmToMinutes(rules.dayBoundary) ? 1 : 0);
  const atW = (hm: string) => at(hm, dayOf(hm));

  // ── 1. 日種別 ─────────────────────────────────────────────
  const weekday = localWeekday(workDate);
  let dayType: DayType;
  if (manual.dayType) dayType = manual.dayType as DayType;
  else if (approvals.leave && approvals.leave.unit === 'FULL') dayType = leaveDayType(approvals.leave.type);
  else if (input.holidayKind) dayType = 'COMPANY_HOLIDAY';
  else if (weekday === rules.legalHolidayWeekday) dayType = 'LEGAL_HOLIDAY';
  else if (!rules.workdays.includes(weekday)) dayType = 'NON_LEGAL_HOLIDAY';
  else dayType = 'WORKDAY';

  const isLeave = dayType === 'PAID_LEAVE' || dayType === 'SPECIAL_LEAVE';
  const isHoliday = dayType === 'LEGAL_HOLIDAY' || dayType === 'NON_LEGAL_HOLIDAY' || dayType === 'COMPANY_HOLIDAY';
  const halfLeave = approvals.leave && approvals.leave.unit !== 'FULL' ? approvals.leave.unit : null;
  if (halfLeave === 'AM') flags.add(FLAGS.HALF_LEAVE_AM);
  if (halfLeave === 'PM') flags.add(FLAGS.HALF_LEAVE_PM);

  // ── 2. 出退勤時刻 ─────────────────────────────────────────
  const sorted = [...punches].sort((a, b) => a.punchedAt.getTime() - b.punchedAt.getTime());
  const firstIn = sorted.find((p) => p.punchType === 'IN') ?? null;
  const lastOut = [...sorted].reverse().find((p) => p.punchType === 'OUT') ?? null;

  let clockIn: Date | null = manual.clockInAt !== undefined ? (manual.clockInAt ? new Date(manual.clockInAt) : null) : firstIn?.punchedAt ?? null;
  let clockOut: Date | null = manual.clockOutAt !== undefined ? (manual.clockOutAt ? new Date(manual.clockOutAt) : null) : lastOut?.punchedAt ?? null;

  if (manual.clockInAt !== undefined || manual.clockOutAt !== undefined || manual.breakMinutes !== undefined || manual.dayType)
    flags.add(FLAGS.MANUAL);
  if (sorted.some((p) => p.geofenceOk === false)) flags.add(FLAGS.GEOFENCE_NG);

  const hasAnyPunch = sorted.length > 0 || !!clockIn || !!clockOut;
  const isPastDay = input.now.getTime() >= at(rules.dayBoundary, 1).getTime();

  if (!clockIn && (clockOut || sorted.length > 0)) flags.add(FLAGS.MISSING_IN);
  if (clockIn && !clockOut && isPastDay) flags.add(FLAGS.MISSING_OUT);
  if (!hasAnyPunch && dayType === 'WORKDAY' && isPastDay) flags.add(FLAGS.NO_PUNCH);
  if (dayType === 'ABSENCE' && hasAnyPunch) flags.add(FLAGS.WORK_ON_LEAVE);

  // 丸め
  if (clockIn) clockIn = roundTime(clockIn, rules.roundingIn.unitMinutes, rules.roundingIn.mode);
  if (clockOut) clockOut = roundTime(clockOut, rules.roundingOut.unitMinutes, rules.roundingOut.mode);
  if (clockIn && clockOut && clockOut < clockIn) clockOut = null;

  // ── 3. 所定労働時間 ───────────────────────────────────────
  let scheduledMinutes = dayType === 'WORKDAY' ? rules.scheduledMinutes : 0;
  if (halfLeave && dayType === 'WORKDAY') scheduledMinutes = Math.round(rules.scheduledMinutes / 2);

  // ── 4. 休憩・実労働 ───────────────────────────────────────
  let breakMinutes = 0;
  let gross = 0;
  let breakIntervals: { start: Date; end: Date }[] = [];
  if (clockIn && clockOut) {
    gross = Math.max(0, diffMinutes(clockIn, clockOut));
    if (manual.breakMinutes !== undefined) {
      breakMinutes = manual.breakMinutes;
    } else {
      breakIntervals = punchBreakIntervals(sorted, clockOut);
      if (breakIntervals.length > 0) {
        breakMinutes = breakIntervals.reduce((s, b) => s + diffMinutes(b.start, b.end), 0);
      } else {
        // 固定休憩のうち実労働区間に重なる部分を控除
        for (const b of rules.breaks) {
          const bs = atW(b.from);
          let be = atW(b.to);
          if (be <= bs) be = at(b.to, dayOf(b.to) + 1); // 日跨ぎ休憩
          const ov = overlapMinutes(clockIn, clockOut, bs, be);
          if (ov > 0) {
            breakMinutes += ov;
            breakIntervals.push({ start: new Date(Math.max(bs.getTime(), clockIn.getTime())), end: new Date(Math.min(be.getTime(), clockOut.getTime())) });
          }
        }
      }
      if (rules.enforceLegalBreak) {
        const net = gross - breakMinutes;
        const required = net > LEGAL.dailyLegalMinutes ? LEGAL.breakOver8h : net > 6 * 60 ? LEGAL.breakOver6h : 0;
        if (breakMinutes < required && gross > required) {
          breakMinutes = required;
          flags.add(FLAGS.BREAK_ADJUSTED);
        }
      }
    }
  }
  breakMinutes = Math.min(breakMinutes, gross);
  let workMinutes = Math.max(0, gross - breakMinutes);
  if (workMinutes > 12 * 60) flags.add(FLAGS.OVER_12H);

  // 裁量労働: みなし労働時間
  if (patternType === 'DISCRETIONARY' && dayType === 'WORKDAY' && hasAnyPunch) {
    workMinutes = scheduledMinutes;
  }

  // ── 5. 遅刻・早退 ─────────────────────────────────────────
  let lateMinutes = 0;
  let earlyLeaveMinutes = 0;
  if (dayType === 'WORKDAY' && patternType !== 'DISCRETIONARY') {
    const startHm = patternType === 'FLEX' ? rules.coreStart : rules.start;
    const endHm = patternType === 'FLEX' ? rules.coreEnd : rules.end;
    if (startHm && clockIn && halfLeave !== 'AM') {
      lateMinutes = Math.max(0, diffMinutes(atW(startHm), clockIn));
    }
    if (endHm && clockOut && halfLeave !== 'PM') {
      let endAt = atW(endHm);
      if (startHm && endAt <= atW(startHm)) endAt = at(endHm, dayOf(endHm) + 1);
      earlyLeaveMinutes = Math.max(0, diffMinutes(clockOut, endAt));
    }
    if (lateMinutes > 0) flags.add(approvals.late ? FLAGS.LATE_APPROVED : FLAGS.LATE);
    if (earlyLeaveMinutes > 0) flags.add(approvals.early ? FLAGS.EARLY_APPROVED : FLAGS.EARLY_LEAVE);
    if (patternType === 'FLEX' && (lateMinutes > 0 || earlyLeaveMinutes > 0)) flags.add(FLAGS.CORE_TIME_VIOLATION);
  }

  // ── 6. 残業・休日労働 ─────────────────────────────────────
  let overtimeMinutes = 0;
  let legalOvertimeMinutes = 0;
  let holidayWorkMinutes = 0;
  if (workMinutes > 0) {
    if (dayType === 'LEGAL_HOLIDAY') {
      holidayWorkMinutes = workMinutes;
      if (!approvals.holidayWork) flags.add(FLAGS.UNAPPROVED_HOLIDAY_WORK);
    } else if (isHoliday) {
      // 所定休日労働: 週40h超とみなし全量を法定外扱い（保守的）
      overtimeMinutes = workMinutes;
      legalOvertimeMinutes = workMinutes;
      if (!approvals.holidayWork) flags.add(FLAGS.UNAPPROVED_HOLIDAY_WORK);
    } else if (isLeave) {
      flags.add(FLAGS.WORK_ON_LEAVE);
      overtimeMinutes = workMinutes;
      legalOvertimeMinutes = workMinutes;
    } else if (patternType !== 'DISCRETIONARY') {
      overtimeMinutes = Math.max(0, workMinutes - scheduledMinutes);
      legalOvertimeMinutes =
        rules.overtimeBasis === 'LEGAL' ? Math.max(0, workMinutes - LEGAL.dailyLegalMinutes) : overtimeMinutes;
      if (overtimeMinutes > (approvals.overtimeMinutes ?? 0) + rules.unapprovedOvertimeThresholdMinutes) flags.add(FLAGS.UNAPPROVED_OVERTIME);
    }
  }

  // ── 7. 深夜労働 (22:00〜翌5:00) ──────────────────────────
  let lateNightMinutes = 0;
  if (clockIn && clockOut && workMinutes > 0 && patternType !== 'DISCRETIONARY') {
    const windows = [
      { s: at('00:00'), e: at(LEGAL.lateNightEnd) },
      { s: at(LEGAL.lateNightStart), e: at(LEGAL.lateNightEnd, 1) },
    ];
    for (const w of windows) {
      let ov = overlapMinutes(clockIn, clockOut, w.s, w.e);
      for (const b of breakIntervals) ov -= overlapMinutes(b.start, b.end, w.s, w.e);
      lateNightMinutes += Math.max(0, ov);
    }
  }

  return {
    dayType,
    clockInAt: clockIn,
    clockOutAt: clockOut,
    breakMinutes,
    workMinutes,
    scheduledMinutes,
    overtimeMinutes,
    legalOvertimeMinutes,
    lateNightMinutes,
    holidayWorkMinutes,
    lateMinutes,
    earlyLeaveMinutes,
    flags: [...flags],
  };
}

/** 月次サマリ用: 勤怠日配列から集計 */
export interface SummaryDay {
  workDate: string;
  dayType: DayType;
  workMinutes: number;
  overtimeMinutes: number;
  legalOvertimeMinutes: number;
  lateNightMinutes: number;
  holidayWorkMinutes: number;
  lateMinutes: number;
  earlyLeaveMinutes: number;
  flags: string[];
  status: string;
}

export function summarize(
  days: SummaryDay[],
  opts: { overtimeAlertMinutes: number; overtimeLimitMinutes: number; today: string },
) {
  const s = {
    scheduledDays: 0,
    actualWorkDays: 0,
    absenceDays: 0,
    paidLeaveDays: 0,
    workMinutes: 0,
    overtimeMinutes: 0,
    legalOvertimeMinutes: 0,
    lateNightMinutes: 0,
    holidayWorkMinutes: 0,
    lateCount: 0,
    earlyLeaveCount: 0,
    alerts: [] as string[],
    status: 'DRAFT' as 'DRAFT' | 'CONFIRMED' | 'LOCKED',
  };
  let locked = 0;
  let confirmed = 0;
  for (const d of days) {
    if (d.dayType === 'WORKDAY' || d.dayType === 'PAID_LEAVE' || d.dayType === 'SPECIAL_LEAVE' || d.dayType === 'ABSENCE') s.scheduledDays++;
    if (d.workMinutes > 0) s.actualWorkDays++;
    if (d.dayType === 'PAID_LEAVE') s.paidLeaveDays++;
    if (d.flags.includes('HALF_LEAVE_AM') || d.flags.includes('HALF_LEAVE_PM')) s.paidLeaveDays += 0.5;
    if (d.dayType === 'ABSENCE' || (d.dayType === 'WORKDAY' && d.flags.includes('NO_PUNCH') && d.workDate < opts.today)) s.absenceDays++;
    s.workMinutes += d.workMinutes;
    s.overtimeMinutes += d.overtimeMinutes;
    s.legalOvertimeMinutes += d.legalOvertimeMinutes;
    s.lateNightMinutes += d.lateNightMinutes;
    s.holidayWorkMinutes += d.holidayWorkMinutes;
    if (d.lateMinutes > 0 && !d.flags.includes('LATE_APPROVED')) s.lateCount++;
    if (d.earlyLeaveMinutes > 0 && !d.flags.includes('EARLY_APPROVED')) s.earlyLeaveCount++;
    if (d.status === 'LOCKED') locked++;
    if (d.status === 'CONFIRMED') confirmed++;
  }
  const legalOt = s.legalOvertimeMinutes + s.holidayWorkMinutes;
  if (legalOt >= opts.overtimeLimitMinutes) s.alerts.push('OVERTIME_LIMIT');
  else if (legalOt >= opts.overtimeAlertMinutes) s.alerts.push('OVERTIME_WARN');
  if (days.some((d) => d.flags.includes('MISSING_OUT') || d.flags.includes('MISSING_IN'))) s.alerts.push('MISSING_PUNCH');
  if (days.some((d) => d.flags.includes('UNAPPROVED_OVERTIME'))) s.alerts.push('UNAPPROVED_OVERTIME');
  if (days.length > 0 && locked === days.length) s.status = 'LOCKED';
  else if (days.length > 0 && locked + confirmed === days.length) s.status = 'CONFIRMED';
  return s;
}
