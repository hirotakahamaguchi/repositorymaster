import { describe, it, expect } from 'vitest';
import { WorkPatternRulesSchema } from '@kintai/shared';
import { calculateAttendance, CalcInput, FLAGS, summarize } from './attendance-calc';
import { workDateOf, roundTime } from './time';

const TZ = 'Asia/Tokyo';
const jst = (date: string, hm: string) => new Date(`${date}T${hm}:00+09:00`);

const fixedRules = WorkPatternRulesSchema.parse({
  start: '09:00',
  end: '18:00',
  scheduledMinutes: 480,
  breaks: [{ from: '12:00', to: '13:00' }],
});

function base(partial: Partial<CalcInput> = {}): CalcInput {
  return {
    workDate: '2026-08-03', // 月曜
    timezone: TZ,
    patternType: 'FIXED',
    rules: fixedRules,
    punches: [],
    holidayKind: null,
    manual: {},
    approvals: {},
    now: new Date('2026-08-10T00:00:00Z'),
    ...partial,
  };
}

describe('calculateAttendance (FIXED 9:00-18:00)', () => {
  it('定時勤務: 8h 労働・休憩1h・残業0', () => {
    const r = calculateAttendance(
      base({
        punches: [
          { punchType: 'IN', punchedAt: jst('2026-08-03', '09:00'), geofenceOk: true },
          { punchType: 'OUT', punchedAt: jst('2026-08-03', '18:00'), geofenceOk: true },
        ],
      }),
    );
    expect(r.dayType).toBe('WORKDAY');
    expect(r.breakMinutes).toBe(60);
    expect(r.workMinutes).toBe(480);
    expect(r.overtimeMinutes).toBe(0);
    expect(r.legalOvertimeMinutes).toBe(0);
    expect(r.lateMinutes).toBe(0);
    expect(r.flags).not.toContain(FLAGS.LATE);
  });

  it('残業 + 深夜: 9:00-23:30 → 残業5.5h, 法定外5.5h, 深夜1.5h, 未承認フラグ', () => {
    const r = calculateAttendance(
      base({
        punches: [
          { punchType: 'IN', punchedAt: jst('2026-08-03', '09:00'), geofenceOk: true },
          { punchType: 'OUT', punchedAt: jst('2026-08-03', '23:30'), geofenceOk: true },
        ],
      }),
    );
    expect(r.workMinutes).toBe(13.5 * 60);
    expect(r.overtimeMinutes).toBe(5.5 * 60);
    expect(r.legalOvertimeMinutes).toBe(5.5 * 60);
    expect(r.lateNightMinutes).toBe(90);
    expect(r.flags).toContain(FLAGS.UNAPPROVED_OVERTIME);
    expect(r.flags).toContain(FLAGS.OVER_12H);
  });

  it('承認済み残業は未承認フラグが付かない', () => {
    const r = calculateAttendance(
      base({
        approvals: { overtimeMinutes: 120 },
        punches: [
          { punchType: 'IN', punchedAt: jst('2026-08-03', '09:00'), geofenceOk: true },
          { punchType: 'OUT', punchedAt: jst('2026-08-03', '20:00'), geofenceOk: true },
        ],
      }),
    );
    expect(r.overtimeMinutes).toBe(120);
    expect(r.flags).not.toContain(FLAGS.UNAPPROVED_OVERTIME);
  });

  it('遅刻・早退を分単位で計測', () => {
    const r = calculateAttendance(
      base({
        punches: [
          { punchType: 'IN', punchedAt: jst('2026-08-03', '09:17'), geofenceOk: true },
          { punchType: 'OUT', punchedAt: jst('2026-08-03', '17:30'), geofenceOk: true },
        ],
      }),
    );
    expect(r.lateMinutes).toBe(17);
    expect(r.earlyLeaveMinutes).toBe(30);
    expect(r.flags).toContain(FLAGS.LATE);
    expect(r.flags).toContain(FLAGS.EARLY_LEAVE);
  });

  it('休憩打刻があれば固定休憩ではなく打刻ベースで控除', () => {
    const r = calculateAttendance(
      base({
        punches: [
          { punchType: 'IN', punchedAt: jst('2026-08-03', '09:00'), geofenceOk: true },
          { punchType: 'BREAK_START', punchedAt: jst('2026-08-03', '12:30'), geofenceOk: true },
          { punchType: 'BREAK_END', punchedAt: jst('2026-08-03', '13:15'), geofenceOk: true },
          { punchType: 'OUT', punchedAt: jst('2026-08-03', '18:00'), geofenceOk: true },
        ],
      }),
    );
    // 45分休憩だが 8h 超労働 → 法定休憩60分に自動調整
    expect(r.breakMinutes).toBe(60);
    expect(r.flags).toContain(FLAGS.BREAK_ADJUSTED);
    expect(r.workMinutes).toBe(480);
  });

  it('退勤打刻漏れ (過去日) → MISSING_OUT', () => {
    const r = calculateAttendance(
      base({ punches: [{ punchType: 'IN', punchedAt: jst('2026-08-03', '09:00'), geofenceOk: true }] }),
    );
    expect(r.flags).toContain(FLAGS.MISSING_OUT);
    expect(r.workMinutes).toBe(0);
  });

  it('当日の勤務中は MISSING_OUT にならない', () => {
    const r = calculateAttendance(
      base({
        now: jst('2026-08-03', '15:00'),
        punches: [{ punchType: 'IN', punchedAt: jst('2026-08-03', '09:00'), geofenceOk: true }],
      }),
    );
    expect(r.flags).not.toContain(FLAGS.MISSING_OUT);
  });

  it('法定休日 (日曜) の労働は全量 holidayWork', () => {
    const r = calculateAttendance(
      base({
        workDate: '2026-08-02',
        punches: [
          { punchType: 'IN', punchedAt: jst('2026-08-02', '10:00'), geofenceOk: true },
          { punchType: 'OUT', punchedAt: jst('2026-08-02', '15:00'), geofenceOk: true },
        ],
      }),
    );
    expect(r.dayType).toBe('LEGAL_HOLIDAY');
    expect(r.holidayWorkMinutes).toBe(240); // 10-15 から固定休憩1hを控除
    expect(r.overtimeMinutes).toBe(0);
    expect(r.flags).toContain(FLAGS.UNAPPROVED_HOLIDAY_WORK);
  });

  it('所定休日 (土曜) の労働は法定外残業扱い', () => {
    const r = calculateAttendance(
      base({
        workDate: '2026-08-01',
        approvals: { holidayWork: true },
        punches: [
          { punchType: 'IN', punchedAt: jst('2026-08-01', '10:00'), geofenceOk: true },
          { punchType: 'OUT', punchedAt: jst('2026-08-01', '14:00'), geofenceOk: true },
        ],
      }),
    );
    expect(r.dayType).toBe('NON_LEGAL_HOLIDAY');
    expect(r.legalOvertimeMinutes).toBe(180); // 10-14 から固定休憩1hを控除
    expect(r.flags).not.toContain(FLAGS.UNAPPROVED_HOLIDAY_WORK);
  });

  it('有給 (終日) → PAID_LEAVE, 所定0', () => {
    const r = calculateAttendance(base({ approvals: { leave: { type: 'PAID', unit: 'FULL' } } }));
    expect(r.dayType).toBe('PAID_LEAVE');
    expect(r.scheduledMinutes).toBe(0);
    expect(r.flags).not.toContain(FLAGS.NO_PUNCH);
  });

  it('午前半休 → 所定4h, 遅刻計測なし', () => {
    const r = calculateAttendance(
      base({
        approvals: { leave: { type: 'PAID', unit: 'AM' } },
        punches: [
          { punchType: 'IN', punchedAt: jst('2026-08-03', '13:00'), geofenceOk: true },
          { punchType: 'OUT', punchedAt: jst('2026-08-03', '18:00'), geofenceOk: true },
        ],
      }),
    );
    expect(r.scheduledMinutes).toBe(240);
    expect(r.lateMinutes).toBe(0);
    expect(r.workMinutes).toBe(300);
    expect(r.overtimeMinutes).toBe(60);
    expect(r.flags).toContain(FLAGS.HALF_LEAVE_AM);
  });

  it('手修正値は打刻より優先される', () => {
    const r = calculateAttendance(
      base({
        manual: { clockOutAt: jst('2026-08-03', '18:00').toISOString() },
        punches: [{ punchType: 'IN', punchedAt: jst('2026-08-03', '09:00'), geofenceOk: true }],
      }),
    );
    expect(r.workMinutes).toBe(480);
    expect(r.flags).toContain(FLAGS.MANUAL);
    expect(r.flags).not.toContain(FLAGS.MISSING_OUT);
  });

  it('打刻なしの過去の出勤日 → NO_PUNCH', () => {
    const r = calculateAttendance(base());
    expect(r.flags).toContain(FLAGS.NO_PUNCH);
  });

  it('丸め: 出勤15分切上げ・退勤15分切捨て', () => {
    const rules = WorkPatternRulesSchema.parse({
      ...fixedRules,
      roundingIn: { unitMinutes: 15, mode: 'CEIL' },
      roundingOut: { unitMinutes: 15, mode: 'FLOOR' },
    });
    const r = calculateAttendance(
      base({
        rules,
        punches: [
          { punchType: 'IN', punchedAt: jst('2026-08-03', '08:52'), geofenceOk: true },
          { punchType: 'OUT', punchedAt: jst('2026-08-03', '18:14'), geofenceOk: true },
        ],
      }),
    );
    expect(r.clockInAt?.toISOString()).toBe(jst('2026-08-03', '09:00').toISOString());
    expect(r.clockOutAt?.toISOString()).toBe(jst('2026-08-03', '18:00').toISOString());
  });

  it('勤務地外打刻 → GEOFENCE_NG', () => {
    const r = calculateAttendance(
      base({
        punches: [
          { punchType: 'IN', punchedAt: jst('2026-08-03', '09:00'), geofenceOk: false },
          { punchType: 'OUT', punchedAt: jst('2026-08-03', '18:00'), geofenceOk: true },
        ],
      }),
    );
    expect(r.flags).toContain(FLAGS.GEOFENCE_NG);
  });
});

describe('FLEX / 夜勤 / 裁量', () => {
  it('フレックス: コアタイム違反', () => {
    const rules = WorkPatternRulesSchema.parse({ coreStart: '10:00', coreEnd: '15:00', scheduledMinutes: 480, breaks: [{ from: '12:00', to: '13:00' }] });
    const r = calculateAttendance(
      base({
        patternType: 'FLEX',
        rules,
        punches: [
          { punchType: 'IN', punchedAt: jst('2026-08-03', '10:30'), geofenceOk: true },
          { punchType: 'OUT', punchedAt: jst('2026-08-03', '19:30'), geofenceOk: true },
        ],
      }),
    );
    expect(r.lateMinutes).toBe(30);
    expect(r.flags).toContain(FLAGS.CORE_TIME_VIOLATION);
    expect(r.workMinutes).toBe(480);
  });

  it('夜勤: 22:00〜翌6:00 は同一勤務日、深夜7h', () => {
    const rules = WorkPatternRulesSchema.parse({ start: '22:00', end: '06:00', scheduledMinutes: 420, breaks: [{ from: '02:00', to: '03:00' }], dayBoundary: '12:00' });
    const r = calculateAttendance(
      base({
        patternType: 'SHIFT',
        rules,
        punches: [
          { punchType: 'IN', punchedAt: jst('2026-08-03', '22:00'), geofenceOk: true },
          { punchType: 'OUT', punchedAt: jst('2026-08-04', '06:00'), geofenceOk: true },
        ],
      }),
    );
    expect(r.breakMinutes).toBe(60);
    expect(r.workMinutes).toBe(420);
    expect(r.lateNightMinutes).toBe(6 * 60); // 22-5 の7hから休憩1hを控除
    expect(r.overtimeMinutes).toBe(0);
    expect(r.earlyLeaveMinutes).toBe(0);
  });

  it('裁量労働: みなし所定時間', () => {
    const rules = WorkPatternRulesSchema.parse({ scheduledMinutes: 480 });
    const r = calculateAttendance(
      base({
        patternType: 'DISCRETIONARY',
        rules,
        punches: [
          { punchType: 'IN', punchedAt: jst('2026-08-03', '11:00'), geofenceOk: true },
          { punchType: 'OUT', punchedAt: jst('2026-08-03', '23:00'), geofenceOk: true },
        ],
      }),
    );
    expect(r.workMinutes).toBe(480);
    expect(r.overtimeMinutes).toBe(0);
    expect(r.lateNightMinutes).toBe(0);
  });
});

describe('time helpers', () => {
  it('workDateOf: 日付境界 05:00 以前は前日', () => {
    expect(workDateOf(jst('2026-08-04', '02:00'), TZ, '05:00')).toBe('2026-08-03');
    expect(workDateOf(jst('2026-08-04', '05:00'), TZ, '05:00')).toBe('2026-08-04');
  });
  it('roundTime', () => {
    expect(roundTime(jst('2026-08-03', '08:52'), 15, 'CEIL').toISOString()).toBe(jst('2026-08-03', '09:00').toISOString());
    expect(roundTime(jst('2026-08-03', '18:14'), 15, 'FLOOR').toISOString()).toBe(jst('2026-08-03', '18:00').toISOString());
    expect(roundTime(jst('2026-08-03', '18:08'), 15, 'ROUND').toISOString()).toBe(jst('2026-08-03', '18:15').toISOString());
  });
});

describe('summarize', () => {
  it('月次集計とアラート', () => {
    const days = [
      { workDate: '2026-08-03', dayType: 'WORKDAY' as const, workMinutes: 600, overtimeMinutes: 120, legalOvertimeMinutes: 120, lateNightMinutes: 0, holidayWorkMinutes: 0, lateMinutes: 10, earlyLeaveMinutes: 0, flags: ['LATE'], status: 'DRAFT' },
      { workDate: '2026-08-04', dayType: 'PAID_LEAVE' as const, workMinutes: 0, overtimeMinutes: 0, legalOvertimeMinutes: 0, lateNightMinutes: 0, holidayWorkMinutes: 0, lateMinutes: 0, earlyLeaveMinutes: 0, flags: [], status: 'DRAFT' },
      { workDate: '2026-08-05', dayType: 'WORKDAY' as const, workMinutes: 0, overtimeMinutes: 0, legalOvertimeMinutes: 0, lateNightMinutes: 0, holidayWorkMinutes: 0, lateMinutes: 0, earlyLeaveMinutes: 0, flags: ['NO_PUNCH'], status: 'DRAFT' },
    ];
    const s = summarize(days, { overtimeAlertMinutes: 100, overtimeLimitMinutes: 500, today: '2026-08-20' });
    expect(s.scheduledDays).toBe(3);
    expect(s.actualWorkDays).toBe(1);
    expect(s.paidLeaveDays).toBe(1);
    expect(s.absenceDays).toBe(1);
    expect(s.lateCount).toBe(1);
    expect(s.alerts).toContain('OVERTIME_WARN');
  });
});
