/**
 * API 結合テスト（インメモリ PGlite で Nest アプリを起動し、主要フローを通す）
 */
import { beforeAll, afterAll, describe, it, expect } from 'vitest';
import 'reflect-metadata';
import { Test } from '@nestjs/testing';
import type { INestApplication } from '@nestjs/common';
import cookieParser from 'cookie-parser';
import { AppModule } from './app.module';
import { AllExceptionsFilter } from './common/http-exception.filter';

process.env.PGLITE_DIR = 'memory';
process.env.JWT_SECRET = 'test-secret';

let app: INestApplication;
let base: string;

async function call(method: string, path: string, opts: { token?: string; body?: unknown } = {}) {
  const res = await fetch(`${base}${path}`, {
    method,
    headers: {
      ...(opts.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      ...(opts.token ? { Authorization: `Bearer ${opts.token}` } : {}),
    },
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
  });
  const text = await res.text();
  let json: unknown = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = text;
  }
  return { status: res.status, body: json as Record<string, unknown> & Record<string, any> };
}

async function login(email: string): Promise<string> {
  const r = await call('POST', '/auth/login', { body: { email, password: 'password123' } });
  expect(r.status).toBe(200);
  return r.body.token as string;
}

beforeAll(async () => {
  const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
  app = moduleRef.createNestApplication();
  app.use(cookieParser());
  app.useGlobalFilters(new AllExceptionsFilter());
  await app.init();
  await app.listen(0);
  const addr = app.getHttpServer().address();
  base = `http://127.0.0.1:${typeof addr === 'string' ? 3001 : addr.port}`;
}, 180_000);

afterAll(async () => {
  await app?.close();
});

describe('API e2e', () => {
  it('health は公開', async () => {
    const r = await call('GET', '/health');
    expect(r.status).toBe(200);
    expect(r.body.status).toBe('ok');
  });

  it('未認証は 401', async () => {
    const r = await call('GET', '/auth/me');
    expect(r.status).toBe(401);
  });

  it('ログイン → me → 権限スコープ', async () => {
    const token = await login('employee@example.com');
    const me = await call('GET', '/auth/me', { token });
    expect(me.status).toBe(200);
    expect(me.body.roles).toEqual(['EMPLOYEE']);
    const forbidden = await call('GET', '/attendance/company/summary', { token });
    expect(forbidden.status).toBe(403);
  });

  it('打刻: 冪等キーで重複排除 / ジオフェンス判定 / 勤怠に反映', async () => {
    const token = await login('employee@example.com');
    const me = (await call('GET', '/auth/me', { token })).body;
    const clientRequestId = '22222222-2222-4222-8222-222222222222';
    const body = { punchType: 'IN', source: 'MOBILE', latitude: 35.6813, longitude: 139.7671, accuracyM: 10, clientRequestId };
    const a = await call('POST', '/punches', { token, body });
    expect(a.status).toBe(201);
    expect(a.body.duplicate).toBe(false);
    expect(a.body.punch.geofenceOk).toBe(true);
    const b = await call('POST', '/punches', { token, body });
    expect(b.body.duplicate).toBe(true);
    expect(b.body.punch.id).toBe(a.body.punch.id);

    // 勤務地外
    const far = await call('POST', '/punches', { token, body: { ...body, latitude: 35.0, longitude: 139.0, clientRequestId: '33333333-3333-4333-8333-333333333333', punchType: 'BREAK_START' } });
    expect(far.body.punch.geofenceOk).toBe(false);

    // 代理打刻は権限なし
    const proxy = await call('POST', '/punches', { token, body: { ...body, employeeId: me.id, clientRequestId: '44444444-4444-4444-8444-444444444444' } });
    expect(proxy.status).toBe(201); // 自分自身の employeeId は代理ではない
    const other = (await call('GET', '/employees', { token })).body;
    expect(other.status ?? 200).not.toBe(500);

    // イベント経由の再計算を待つ
    await new Promise((r) => setTimeout(r, 500));
    const dash = await call('GET', '/dashboard/me', { token });
    expect(dash.status).toBe(200);
    expect(dash.body.working).toBe(true);
    expect(dash.body.todayPunches.length).toBeGreaterThanOrEqual(2);
  });

  it('休暇申請 → 管理者承認 → 労務承認 → 勤怠/残日数に反映', async () => {
    const emp = await login('employee@example.com');
    const mgr = await login('manager@example.com');
    const hr = await login('hr@example.com');
    const before = (await call('GET', '/leaves/balances', { token: emp })).body as { leaveType: string; remainingDays: number }[];
    const paidBefore = before.find((b) => b.leaveType === 'PAID')!.remainingDays;

    const created = await call('POST', '/requests', {
      token: emp,
      body: { requestType: 'LEAVE', reason: 'e2e', payload: { dateFrom: '2026-10-05', dateTo: '2026-10-06', leaveType: 'PAID', unit: 'FULL' } },
    });
    expect(created.status).toBe(201);
    expect(created.body.status).toBe('PENDING');
    expect(created.body.approvals.length).toBe(2);
    const id = created.body.id as string;

    // 本人は承認できない
    const self = await call('POST', `/requests/${id}/decide`, { token: emp, body: { decision: 'APPROVED' } });
    expect(self.status).toBe(403);

    const step1 = await call('POST', `/requests/${id}/decide`, { token: mgr, body: { decision: 'APPROVED', comment: 'ok' } });
    expect(step1.status).toBe(201);
    expect(step1.body.status).toBe('PENDING');
    expect(step1.body.currentStep).toBe(2);

    // 管理者は 2 段階目(HR)を承認できない
    const again = await call('POST', `/requests/${id}/decide`, { token: mgr, body: { decision: 'APPROVED' } });
    expect(again.status).toBe(403);

    const step2 = await call('POST', `/requests/${id}/decide`, { token: hr, body: { decision: 'APPROVED' } });
    expect(step2.body.status).toBe('APPROVED');

    const after = (await call('GET', '/leaves/balances', { token: emp })).body as { leaveType: string; remainingDays: number }[];
    expect(after.find((b) => b.leaveType === 'PAID')!.remainingDays).toBe(paidBefore - 2);

    const month = await call('GET', '/attendance/me?month=2026-10', { token: emp });
    const d = (month.body.days as { workDate: string; dayType: string }[]).find((x) => x.workDate === '2026-10-05');
    expect(d?.dayType).toBe('PAID_LEAVE');

    // 修正履歴に申請IDが残る
    const day = (month.body.days as { id: string; workDate: string }[]).find((x) => x.workDate === '2026-10-05')!;
    const revs = await call('GET', `/attendance/days/${day.id}/revisions`, { token: emp });
    expect(revs.body[0].requestId).toBe(id);
  });

  it('残日数不足の休暇申請は 400', async () => {
    const emp = await login('employee@example.com');
    const r = await call('POST', '/requests', {
      token: emp,
      body: { requestType: 'LEAVE', reason: 'too many', payload: { dateFrom: '2026-11-02', dateTo: '2026-12-30', leaveType: 'PAID', unit: 'FULL' } },
    });
    expect(r.status).toBe(400);
  });

  it('勤怠修正（楽観ロック・履歴）と締め・再開', async () => {
    const hr = await login('hr@example.com');
    const emp = await login('employee@example.com');
    const me = (await call('GET', '/auth/me', { token: emp })).body;
    const month = await call('GET', `/attendance/employees/${me.id}?month=2026-07`, { token: hr });
    expect(month.status).toBe(200);
    const day = (month.body.days as { id: string; version: number; status: string; workDate: string }[]).find((d) => d.status !== 'LOCKED' && d.workDate >= '2026-07-01');
    if (!day) return; // 7月が既に締め済みのケース（seed の締め対象月に依存）
    const fixed = await call('PATCH', `/attendance/days/${day.id}`, {
      token: hr,
      body: { clockInAt: `${day.workDate}T00:00:00.000Z`, clockOutAt: `${day.workDate}T09:00:00.000Z`, reason: 'e2e 修正', version: day.version },
    });
    expect(fixed.status).toBe(200);
    expect(fixed.body.flags).toContain('MANUAL');
    expect(fixed.body.version).toBe(day.version + 1);
    const stale = await call('PATCH', `/attendance/days/${day.id}`, { token: hr, body: { reason: 'stale', version: day.version } });
    expect(stale.status).toBe(409);
    const revs = await call('GET', `/attendance/days/${day.id}/revisions`, { token: hr });
    expect(revs.body[0].reason).toBe('e2e 修正');

    // 一般社員は修正不可
    const denied = await call('PATCH', `/attendance/days/${day.id}`, { token: emp, body: { reason: 'x', version: day.version + 1 } });
    expect(denied.status).toBe(403);
  });

  it('月次締め → 締め後は修正不可 → CSV → 締め解除', async () => {
    const admin = await login('admin@example.com');
    const emp = await login('employee@example.com');
    const me = (await call('GET', '/auth/me', { token: emp })).body;
    const close = await call('POST', '/closings?force=true', { token: admin, body: { yearMonth: '2026-07', employeeIds: [me.id] } });
    expect(close.status).toBe(201);
    expect(close.body.closed).toBe(1);
    const list = await call('GET', '/closings?month=2026-07', { token: admin });
    expect((list.body as unknown[]).some((c: any) => c.employeeId === me.id)).toBe(true);
    const month = await call('GET', `/attendance/employees/${me.id}?month=2026-07`, { token: admin });
    const day = (month.body.days as { id: string; version: number; status: string }[])[0];
    expect(day.status).toBe('LOCKED');
    const denied = await call('PATCH', `/attendance/days/${day.id}`, { token: admin, body: { reason: 'x', version: day.version } });
    expect(denied.status).toBe(400);

    const csv = await fetch(`${base}/closings/csv?month=2026-07&lockedOnly=true`, { headers: { Authorization: `Bearer ${admin}` } });
    expect(csv.status).toBe(200);
    const text = await csv.text();
    expect(text.split('\r\n')[0]).toContain('社員番号');
    expect(text).toContain(me.employeeCode);

    const reopen = await call('POST', `/closings/2026-07/reopen/${me.id}`, { token: admin });
    expect(reopen.status).toBe(201);
    const month2 = await call('GET', `/attendance/employees/${me.id}?month=2026-07`, { token: admin });
    expect((month2.body.days as { status: string }[])[0].status).toBe('DRAFT');

    // 当月は締められない
    const now = new Date();
    const ym = `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, '0')}`;
    const bad = await call('POST', '/closings', { token: admin, body: { yearMonth: ym } });
    expect(bad.status).toBe(400);
  });

  it('監査ログが記録される', async () => {
    const admin = await login('admin@example.com');
    const logs = await call('GET', '/audit-logs?pageSize=5', { token: admin });
    expect(logs.status).toBe(200);
    expect((logs.body.items as unknown[]).length).toBeGreaterThan(0);
  });
});
