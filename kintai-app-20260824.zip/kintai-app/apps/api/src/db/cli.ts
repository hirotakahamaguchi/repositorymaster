/* eslint-disable no-console */
/**
 * DB 管理 CLI
 *   npm run db:migrate  -- マイグレーション適用
 *   npm run db:seed     -- デモデータ投入（空のときのみ）
 *   npm run db:reset    -- PGlite データ削除 → migrate → seed（PostgreSQL の場合は FORCE_RESET=1 で public スキーマを DROP）
 */
import 'reflect-metadata';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { sql } from 'drizzle-orm';
import { createDb } from './client';
import { runMigrations } from './migrate';
import { seed, seedIfEmpty } from './seed';

async function main() {
  const cmd = process.argv[2] ?? 'migrate';
  const log = (m: string) => console.log(`[db] ${m}`);

  if (cmd === 'reset') {
    if (process.env.DATABASE_URL) {
      if (process.env.FORCE_RESET !== '1') {
        console.error('DATABASE_URL が設定されています。本当にリセットする場合は FORCE_RESET=1 を付けてください');
        process.exit(1);
      }
      const h = await createDb();
      await h.db.execute(sql`drop schema public cascade; create schema public;`);
      await runMigrations(h, log);
      await seed(h.db, log);
      await h.close();
      return;
    }
    const dir = process.env.PGLITE_DIR ?? path.resolve(process.cwd(), '.pgdata');
    if (fs.existsSync(dir)) {
      fs.rmSync(dir, { recursive: true, force: true });
      log(`removed ${dir}`);
    }
  }

  const h = await createDb();
  try {
    await runMigrations(h, log);
    if (cmd === 'seed' || cmd === 'reset') {
      const seeded = await seedIfEmpty(h.db, log);
      log(seeded ? 'seeded' : 'already has data, skip seed');
    }
  } finally {
    await h.close();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
