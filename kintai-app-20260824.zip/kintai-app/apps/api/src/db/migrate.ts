/**
 * 軽量マイグレーションランナー
 *  - src/db/migrations/*.sql を名前順に適用し schema_migrations に記録
 *  - time_punches の月次パーティションを過去24か月〜将来12か月ぶん作成（冪等）
 */
import * as fs from 'node:fs';
import * as path from 'node:path';
import { sql } from 'drizzle-orm';
import type { Db, DbHandle } from './client';

function migrationsDir(): string {
  // ts-node 実行時 (src) と nest build 後 (dist) の両方に対応
  const candidates = [path.resolve(__dirname, 'migrations'), path.resolve(process.cwd(), 'src/db/migrations')];
  for (const c of candidates) if (fs.existsSync(c)) return c;
  throw new Error('migrations directory not found');
}

export async function runMigrations(handle: DbHandle, log: (m: string) => void = () => {}): Promise<string[]> {
  const db = handle.db;
  await db.execute(sql`create table if not exists schema_migrations (name text primary key, applied_at timestamptz not null default now())`);
  const applied = new Set<string>(
    ((await db.execute(sql`select name from schema_migrations`)).rows as { name: string }[]).map((r) => r.name),
  );
  const dir = migrationsDir();
  const files = fs
    .readdirSync(dir)
    .filter((f) => f.endsWith('.sql'))
    .sort();
  const newly: string[] = [];
  for (const f of files) {
    if (applied.has(f)) continue;
    const body = fs.readFileSync(path.join(dir, f), 'utf8');
    log(`applying migration ${f}`);
    // 複数ステートメントを含むため simple query protocol で実行（暗黙のトランザクション）
    await handle.execRaw(`begin;
${body}
commit;`);
    await db.execute(sql`insert into schema_migrations(name) values (${f})`);
    newly.push(f);
  }
  await ensurePunchPartitions(db, log);
  return newly;
}

/** time_punches の月次パーティションを作成（存在すればスキップ） */
export async function ensurePunchPartitions(
  db: Db,
  log: (m: string) => void = () => {},
  opts: { pastMonths?: number; futureMonths?: number; now?: Date } = {},
): Promise<void> {
  const past = opts.pastMonths ?? 24;
  const future = opts.futureMonths ?? 12;
  const now = opts.now ?? new Date();
  const existing = new Set<string>(
    (
      (
        await db.execute(
          sql`select c.relname as name from pg_inherits i join pg_class c on c.oid = i.inhrelid join pg_class p on p.oid = i.inhparent where p.relname = 'time_punches'`,
        )
      ).rows as { name: string }[]
    ).map((r) => r.name),
  );
  for (let i = -past; i <= future; i++) {
    const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + i, 1));
    const end = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + i + 1, 1));
    const name = `time_punches_y${start.getUTCFullYear()}m${String(start.getUTCMonth() + 1).padStart(2, '0')}`;
    if (existing.has(name)) continue;
    // DEFAULT パーティションに該当期間の行があると CREATE に失敗するため、事前に検知して警告のみ出す
    const conflict = (
      await db.execute(
        sql.raw(
          `select count(*)::int as n from time_punches_default where punched_at >= '${start.toISOString()}' and punched_at < '${end.toISOString()}'`,
        ),
      )
    ).rows[0] as { n: number };
    if (conflict && Number(conflict.n) > 0) {
      log(`skip partition ${name}: ${conflict.n} rows already in default partition (run maintenance manually)`);
      continue;
    }
    log(`creating partition ${name}`);
    await db.execute(
      sql.raw(
        `create table if not exists ${name} partition of time_punches for values from ('${start.toISOString()}') to ('${end.toISOString()}')`,
      ),
    );
  }
}
