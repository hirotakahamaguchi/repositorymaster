-- ============================================================
-- 0001_init: 出退勤管理 初期スキーマ (PostgreSQL 14+ / PGlite)
-- ============================================================
create extension if not exists btree_gist;

-- ─── 会社・組織 ────────────────────────────────────────────
create table if not exists companies (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  timezone    text not null default 'Asia/Tokyo',
  settings    jsonb not null default '{}'::jsonb,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists departments (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references companies(id),
  code        text not null,
  name        text not null,
  parent_id   uuid references departments(id),
  manager_id  uuid,                      -- FK は employees 作成後に追加
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (company_id, code)
);

create table if not exists employees (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null references companies(id),
  employee_code  text not null,
  name           text not null,
  name_kana      text,
  email          text not null,
  password_hash  text,
  auth_subject   text,                   -- IdP (Cognito/Auth0) 側の subject
  department_id  uuid references departments(id),
  hired_at       date not null,
  retired_at     date,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (company_id, employee_code),
  unique (email)
);
create index if not exists idx_employees_department on employees(department_id);

alter table departments
  add constraint fk_departments_manager foreign key (manager_id) references employees(id);

-- ─── 権限 (スコープ付き RBAC) ──────────────────────────────
create table if not exists roles (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references companies(id),
  code        text not null,
  name        text not null,
  unique (company_id, code)
);

create table if not exists permissions (
  code         text primary key,
  description  text
);

create table if not exists role_permissions (
  role_id          uuid not null references roles(id) on delete cascade,
  permission_code  text not null references permissions(code),
  primary key (role_id, permission_code)
);

create table if not exists employee_roles (
  id           uuid primary key default gen_random_uuid(),
  employee_id  uuid not null references employees(id) on delete cascade,
  role_id      uuid not null references roles(id) on delete cascade,
  scope_type   text not null default 'COMPANY' check (scope_type in ('COMPANY','DEPARTMENT')),
  scope_id     uuid,
  valid_from   date not null,
  valid_to     date,
  created_at   timestamptz not null default now()
);
create index if not exists idx_employee_roles_employee on employee_roles(employee_id);

-- ─── 勤務パターン（期間付き） ──────────────────────────────
create table if not exists work_patterns (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null references companies(id),
  code          text not null,
  name          text not null,
  pattern_type  text not null check (pattern_type in ('FIXED','SHIFT','FLEX','DISCRETIONARY')),
  rules         jsonb not null,
  valid_from    date not null,
  valid_to      date,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (company_id, code)
);

create table if not exists employee_work_pattern_assignments (
  id               uuid primary key default gen_random_uuid(),
  employee_id      uuid not null references employees(id) on delete cascade,
  work_pattern_id  uuid not null references work_patterns(id),
  valid_from       date not null,
  valid_to         date,
  created_at       timestamptz not null default now(),
  check (valid_to is null or valid_to >= valid_from),
  -- 同一従業員で有効期間が重複する割当を禁止
  exclude using gist (
    employee_id with =,
    daterange(valid_from, coalesce(valid_to, 'infinity'::date), '[]') with &&
  )
);
create index if not exists idx_wp_assign_employee on employee_work_pattern_assignments(employee_id, valid_from);

create table if not exists holidays (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references companies(id),
  date        date not null,
  name        text not null,
  kind        text not null default 'COMPANY' check (kind in ('NATIONAL','COMPANY')),
  unique (company_id, date)
);

-- ─── 打刻ログ（追記専用・月次パーティション） ──────────────
create table if not exists time_punches (
  id                 bigint generated always as identity,
  employee_id        uuid not null,                          -- パーティションテーブルの FK は意図的に省略
  punch_type         text not null check (punch_type in ('IN','OUT','BREAK_START','BREAK_END')),
  punched_at         timestamptz not null,                   -- 打刻時刻 (UTC)
  received_at        timestamptz not null default now(),     -- サーバ受信時刻
  source             text not null check (source in ('WEB','MOBILE','ICCARD','ADMIN','IMPORT')),
  latitude           numeric(9,6),
  longitude          numeric(9,6),
  accuracy_m         numeric(8,2),
  geofence_ok        boolean,
  clock_drift_sec    integer,                                -- received_at - punched_at (秒)
  device_info        jsonb,
  client_request_id  uuid not null,                          -- 冪等キー
  created_by         uuid,
  primary key (id, punched_at),
  unique (client_request_id, punched_at)
) partition by range (punched_at);
create index if not exists idx_time_punches_emp_time on time_punches(employee_id, punched_at);
-- DEFAULT パーティション（範囲外の保険）。月次パーティションはアプリ起動時/月次ジョブで作成
create table if not exists time_punches_default partition of time_punches default;

-- ─── 日次勤怠 ──────────────────────────────────────────────
create table if not exists attendance_days (
  id                      uuid primary key default gen_random_uuid(),
  employee_id             uuid not null references employees(id) on delete cascade,
  work_date               date not null,
  day_type                text not null default 'WORKDAY',
  work_pattern_id         uuid references work_patterns(id),
  clock_in_at             timestamptz,
  clock_out_at            timestamptz,
  break_minutes           integer not null default 0,
  work_minutes            integer not null default 0,
  scheduled_minutes       integer not null default 0,
  overtime_minutes        integer not null default 0,
  legal_overtime_minutes  integer not null default 0,
  late_night_minutes      integer not null default 0,
  holiday_work_minutes    integer not null default 0,
  late_minutes            integer not null default 0,
  early_leave_minutes     integer not null default 0,
  status                  text not null default 'DRAFT' check (status in ('DRAFT','CONFIRMED','LOCKED')),
  note                    text,
  flags                   jsonb not null default '[]'::jsonb,
  manual                  jsonb not null default '{}'::jsonb,
  approvals               jsonb not null default '{}'::jsonb,
  version                 integer not null default 1,
  calc_version            integer not null default 1,
  created_at              timestamptz not null default now(),
  updated_at              timestamptz not null default now(),
  unique (employee_id, work_date)
);
create index if not exists idx_attendance_days_date on attendance_days(work_date);
create index if not exists idx_attendance_days_status on attendance_days(status) where status <> 'LOCKED';

create table if not exists attendance_day_revisions (
  id                 uuid primary key default gen_random_uuid(),
  attendance_day_id  uuid not null references attendance_days(id) on delete cascade,
  version            integer not null,
  before             jsonb,
  after              jsonb not null,
  reason             text not null,
  changed_by         uuid,
  request_id         uuid,
  changed_at         timestamptz not null default now()
);
create index if not exists idx_revisions_day on attendance_day_revisions(attendance_day_id, version);

-- ─── 申請・承認 ────────────────────────────────────────────
create table if not exists approval_routes (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null references companies(id),
  request_type  text not null,
  name          text not null,
  steps         jsonb not null,
  unique (company_id, request_type)
);

create table if not exists requests (
  id                uuid primary key default gen_random_uuid(),
  company_id        uuid not null references companies(id),
  employee_id       uuid not null references employees(id),
  request_type      text not null check (request_type in ('CORRECTION','OVERTIME','LEAVE','HOLIDAY_WORK','LATE_EARLY')),
  payload           jsonb not null,
  reason            text not null,
  status            text not null default 'PENDING' check (status in ('DRAFT','PENDING','APPROVED','REJECTED','WITHDRAWN')),
  target_date_from  date not null,
  target_date_to    date not null,
  current_step      integer not null default 1,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
create index if not exists idx_requests_employee on requests(employee_id, created_at desc);
create index if not exists idx_requests_status on requests(company_id, status);

create table if not exists request_approvals (
  id             uuid primary key default gen_random_uuid(),
  request_id     uuid not null references requests(id) on delete cascade,
  step_no        integer not null,
  approver_type  text not null,
  approver_id    uuid,
  decision       text not null default 'PENDING' check (decision in ('PENDING','APPROVED','REJECTED','SKIPPED')),
  comment        text,
  decided_at     timestamptz,
  unique (request_id, step_no)
);

-- ─── 休暇 ──────────────────────────────────────────────────
create table if not exists leave_grants (
  id           uuid primary key default gen_random_uuid(),
  employee_id  uuid not null references employees(id) on delete cascade,
  leave_type   text not null,
  days         numeric(5,2) not null,
  granted_at   date not null,
  expires_at   date not null,
  note         text,
  created_by   uuid,
  created_at   timestamptz not null default now()
);
create index if not exists idx_leave_grants_emp on leave_grants(employee_id, leave_type);

create table if not exists leave_usages (
  id           uuid primary key default gen_random_uuid(),
  employee_id  uuid not null references employees(id) on delete cascade,
  leave_type   text not null,
  date         date not null,
  days         numeric(3,2) not null,
  request_id   uuid,
  created_at   timestamptz not null default now(),
  unique (employee_id, date, leave_type)
);

-- ─── 月次締め・CSV ─────────────────────────────────────────
create table if not exists monthly_closings (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null references companies(id),
  employee_id  uuid not null references employees(id),
  year_month   text not null,
  locked_at    timestamptz not null default now(),
  locked_by    uuid,
  snapshot     jsonb not null,
  unique (employee_id, year_month)
);

create table if not exists csv_exports (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null references companies(id),
  year_month   text not null,
  format       text not null,
  file_name    text not null,
  content      text,
  storage_key  text,
  row_count    integer not null,
  created_by   uuid,
  created_at   timestamptz not null default now()
);

-- ─── 監査ログ ──────────────────────────────────────────────
create table if not exists audit_logs (
  id           bigint generated always as identity primary key,
  company_id   uuid not null,
  actor_id     uuid,
  action       text not null,
  target_type  text not null,
  target_id    text,
  detail       jsonb,
  ip           text,
  created_at   timestamptz not null default now()
);
create index if not exists idx_audit_logs_company_time on audit_logs(company_id, created_at desc);

-- ─── updated_at 自動更新 ───────────────────────────────────
create or replace function set_updated_at() returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

do $$
declare t text;
begin
  foreach t in array array['companies','departments','employees','work_patterns','attendance_days','requests']
  loop
    execute format('drop trigger if exists trg_%s_updated_at on %s', t, t);
    execute format('create trigger trg_%s_updated_at before update on %s for each row execute function set_updated_at()', t, t);
  end loop;
end $$;

-- ─── 打刻ログの改ざん防止（UPDATE/DELETE 禁止） ─────────────
create or replace function reject_punch_mutation() returns trigger as $$
begin
  raise exception 'time_punches is append-only';
end;
$$ language plpgsql;
drop trigger if exists trg_time_punches_immutable on time_punches;
create trigger trg_time_punches_immutable
  before update or delete on time_punches
  for each row execute function reject_punch_mutation();
