/**
 * Drizzle スキーマ定義（PostgreSQL）
 *
 * 設計方針:
 *  - 打刻 (time_punches) は追記専用の「事実」。UPDATE/DELETE しない
 *  - 日次勤怠 (attendance_days) は打刻から再計算可能な「解釈」。修正は revisions に全履歴を残す
 *  - 月次締め (monthly_closings) は「確定」。スナップショットを JSONB で凍結
 *  - 制度系マスタ (work_patterns / assignments / roles) は valid_from / valid_to で期間管理
 *
 * 実テーブルは src/db/migrations/*.sql で作成する（パーティション・EXCLUDE 制約など Drizzle で
 * 表現できない DDL を含むため）。このファイルは型安全なクエリビルダのための定義。
 */
import {
  pgTable,
  uuid,
  text,
  timestamp,
  date,
  integer,
  boolean,
  jsonb,
  numeric,
  bigint,
  primaryKey,
} from 'drizzle-orm/pg-core';
import { sql } from 'drizzle-orm';

const ts = (name: string) => timestamp(name, { withTimezone: true, mode: 'date' });
const createdAt = ts('created_at').notNull().defaultNow();
const updatedAt = ts('updated_at').notNull().defaultNow();

export const companies = pgTable('companies', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  name: text('name').notNull(),
  timezone: text('timezone').notNull().default('Asia/Tokyo'),
  settings: jsonb('settings').$type<Record<string, unknown>>().notNull().default({}),
  createdAt,
  updatedAt,
});

export const departments = pgTable('departments', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  companyId: uuid('company_id')
    .notNull()
    .references(() => companies.id),
  code: text('code').notNull(),
  name: text('name').notNull(),
  parentId: uuid('parent_id'),
  managerId: uuid('manager_id'),
  createdAt,
  updatedAt,
});

export const employees = pgTable('employees', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  companyId: uuid('company_id')
    .notNull()
    .references(() => companies.id),
  employeeCode: text('employee_code').notNull(),
  name: text('name').notNull(),
  nameKana: text('name_kana'),
  email: text('email').notNull(),
  passwordHash: text('password_hash'),
  authSubject: text('auth_subject'),
  departmentId: uuid('department_id').references(() => departments.id),
  hiredAt: date('hired_at', { mode: 'string' }).notNull(),
  retiredAt: date('retired_at', { mode: 'string' }),
  createdAt,
  updatedAt,
});

export const roles = pgTable('roles', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  companyId: uuid('company_id')
    .notNull()
    .references(() => companies.id),
  code: text('code').notNull(),
  name: text('name').notNull(),
});

export const permissions = pgTable('permissions', {
  code: text('code').primaryKey(),
  description: text('description'),
});

export const rolePermissions = pgTable(
  'role_permissions',
  {
    roleId: uuid('role_id')
      .notNull()
      .references(() => roles.id, { onDelete: 'cascade' }),
    permissionCode: text('permission_code')
      .notNull()
      .references(() => permissions.code),
  },
  (t) => [primaryKey({ columns: [t.roleId, t.permissionCode] })],
);

export const employeeRoles = pgTable('employee_roles', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  employeeId: uuid('employee_id')
    .notNull()
    .references(() => employees.id, { onDelete: 'cascade' }),
  roleId: uuid('role_id')
    .notNull()
    .references(() => roles.id, { onDelete: 'cascade' }),
  /** COMPANY | DEPARTMENT */
  scopeType: text('scope_type').notNull().default('COMPANY'),
  scopeId: uuid('scope_id'),
  validFrom: date('valid_from', { mode: 'string' }).notNull(),
  validTo: date('valid_to', { mode: 'string' }),
  createdAt,
});

export const workPatterns = pgTable('work_patterns', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  companyId: uuid('company_id')
    .notNull()
    .references(() => companies.id),
  code: text('code').notNull(),
  name: text('name').notNull(),
  patternType: text('pattern_type').notNull(),
  rules: jsonb('rules').$type<Record<string, unknown>>().notNull(),
  validFrom: date('valid_from', { mode: 'string' }).notNull(),
  validTo: date('valid_to', { mode: 'string' }),
  createdAt,
  updatedAt,
});

export const employeeWorkPatternAssignments = pgTable('employee_work_pattern_assignments', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  employeeId: uuid('employee_id')
    .notNull()
    .references(() => employees.id, { onDelete: 'cascade' }),
  workPatternId: uuid('work_pattern_id')
    .notNull()
    .references(() => workPatterns.id),
  validFrom: date('valid_from', { mode: 'string' }).notNull(),
  validTo: date('valid_to', { mode: 'string' }),
  createdAt,
});

export const holidays = pgTable('holidays', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  companyId: uuid('company_id')
    .notNull()
    .references(() => companies.id),
  date: date('date', { mode: 'string' }).notNull(),
  name: text('name').notNull(),
  kind: text('kind').notNull().default('COMPANY'),
});

/** 打刻（追記専用・月次パーティション） */
export const timePunches = pgTable('time_punches', {
  id: bigint('id', { mode: 'number' }).notNull().generatedAlwaysAsIdentity(),
  employeeId: uuid('employee_id').notNull(),
  punchType: text('punch_type').notNull(),
  punchedAt: ts('punched_at').notNull(),
  receivedAt: ts('received_at').notNull().defaultNow(),
  source: text('source').notNull(),
  latitude: numeric('latitude', { precision: 9, scale: 6 }),
  longitude: numeric('longitude', { precision: 9, scale: 6 }),
  accuracyM: numeric('accuracy_m', { precision: 8, scale: 2 }),
  geofenceOk: boolean('geofence_ok'),
  clockDriftSec: integer('clock_drift_sec'),
  deviceInfo: jsonb('device_info').$type<Record<string, unknown>>(),
  clientRequestId: uuid('client_request_id').notNull(),
  createdBy: uuid('created_by'),
});

export interface AttendanceManual {
  clockInAt?: string | null;
  clockOutAt?: string | null;
  breakMinutes?: number;
  dayType?: string;
}
export interface AttendanceApprovals {
  overtimeMinutes?: number;
  holidayWork?: boolean;
  late?: boolean;
  early?: boolean;
  leave?: { type: string; unit: 'FULL' | 'AM' | 'PM' };
}

/** 日次勤怠（打刻から再計算可能。status=LOCKED は再計算対象外） */
export const attendanceDays = pgTable('attendance_days', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  employeeId: uuid('employee_id')
    .notNull()
    .references(() => employees.id, { onDelete: 'cascade' }),
  workDate: date('work_date', { mode: 'string' }).notNull(),
  dayType: text('day_type').notNull().default('WORKDAY'),
  workPatternId: uuid('work_pattern_id'),
  clockInAt: ts('clock_in_at'),
  clockOutAt: ts('clock_out_at'),
  breakMinutes: integer('break_minutes').notNull().default(0),
  workMinutes: integer('work_minutes').notNull().default(0),
  scheduledMinutes: integer('scheduled_minutes').notNull().default(0),
  overtimeMinutes: integer('overtime_minutes').notNull().default(0),
  legalOvertimeMinutes: integer('legal_overtime_minutes').notNull().default(0),
  lateNightMinutes: integer('late_night_minutes').notNull().default(0),
  holidayWorkMinutes: integer('holiday_work_minutes').notNull().default(0),
  lateMinutes: integer('late_minutes').notNull().default(0),
  earlyLeaveMinutes: integer('early_leave_minutes').notNull().default(0),
  status: text('status').notNull().default('DRAFT'),
  note: text('note'),
  flags: jsonb('flags').$type<string[]>().notNull().default([]),
  /** 手修正された項目（再計算で上書きしない） */
  manual: jsonb('manual').$type<AttendanceManual>().notNull().default({}),
  /** 申請承認によって付与された属性 */
  approvals: jsonb('approvals').$type<AttendanceApprovals>().notNull().default({}),
  version: integer('version').notNull().default(1),
  calcVersion: integer('calc_version').notNull().default(1),
  createdAt,
  updatedAt,
});

export const attendanceDayRevisions = pgTable('attendance_day_revisions', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  attendanceDayId: uuid('attendance_day_id')
    .notNull()
    .references(() => attendanceDays.id, { onDelete: 'cascade' }),
  version: integer('version').notNull(),
  before: jsonb('before').$type<Record<string, unknown> | null>(),
  after: jsonb('after').$type<Record<string, unknown>>().notNull(),
  reason: text('reason').notNull(),
  changedBy: uuid('changed_by'),
  requestId: uuid('request_id'),
  changedAt: ts('changed_at').notNull().defaultNow(),
});

export const approvalRoutes = pgTable('approval_routes', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  companyId: uuid('company_id')
    .notNull()
    .references(() => companies.id),
  requestType: text('request_type').notNull(),
  name: text('name').notNull(),
  /** [{stepNo, approverType: 'DEPARTMENT_MANAGER'|'HR'|'EMPLOYEE', approverId?}] */
  steps: jsonb('steps').$type<{ stepNo: number; approverType: string; approverId?: string }[]>().notNull(),
});

export const requests = pgTable('requests', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  companyId: uuid('company_id')
    .notNull()
    .references(() => companies.id),
  employeeId: uuid('employee_id')
    .notNull()
    .references(() => employees.id),
  requestType: text('request_type').notNull(),
  payload: jsonb('payload').$type<Record<string, unknown>>().notNull(),
  reason: text('reason').notNull(),
  status: text('status').notNull().default('PENDING'),
  targetDateFrom: date('target_date_from', { mode: 'string' }).notNull(),
  targetDateTo: date('target_date_to', { mode: 'string' }).notNull(),
  currentStep: integer('current_step').notNull().default(1),
  createdAt,
  updatedAt,
});

export const requestApprovals = pgTable('request_approvals', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  requestId: uuid('request_id')
    .notNull()
    .references(() => requests.id, { onDelete: 'cascade' }),
  stepNo: integer('step_no').notNull(),
  approverType: text('approver_type').notNull(),
  approverId: uuid('approver_id'),
  decision: text('decision').notNull().default('PENDING'),
  comment: text('comment'),
  decidedAt: ts('decided_at'),
});

export const leaveGrants = pgTable('leave_grants', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  employeeId: uuid('employee_id')
    .notNull()
    .references(() => employees.id, { onDelete: 'cascade' }),
  leaveType: text('leave_type').notNull(),
  days: numeric('days', { precision: 5, scale: 2 }).notNull(),
  grantedAt: date('granted_at', { mode: 'string' }).notNull(),
  expiresAt: date('expires_at', { mode: 'string' }).notNull(),
  note: text('note'),
  createdBy: uuid('created_by'),
  createdAt,
});

export const leaveUsages = pgTable('leave_usages', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  employeeId: uuid('employee_id')
    .notNull()
    .references(() => employees.id, { onDelete: 'cascade' }),
  leaveType: text('leave_type').notNull(),
  date: date('date', { mode: 'string' }).notNull(),
  days: numeric('days', { precision: 3, scale: 2 }).notNull(),
  requestId: uuid('request_id'),
  createdAt,
});

export const monthlyClosings = pgTable('monthly_closings', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  companyId: uuid('company_id')
    .notNull()
    .references(() => companies.id),
  employeeId: uuid('employee_id')
    .notNull()
    .references(() => employees.id),
  yearMonth: text('year_month').notNull(),
  lockedAt: ts('locked_at').notNull().defaultNow(),
  lockedBy: uuid('locked_by'),
  snapshot: jsonb('snapshot').$type<Record<string, unknown>>().notNull(),
});

export const csvExports = pgTable('csv_exports', {
  id: uuid('id').primaryKey().default(sql`gen_random_uuid()`),
  companyId: uuid('company_id')
    .notNull()
    .references(() => companies.id),
  yearMonth: text('year_month').notNull(),
  format: text('format').notNull(),
  fileName: text('file_name').notNull(),
  /** 本番では S3 キーを保持し content は持たない */
  content: text('content'),
  storageKey: text('storage_key'),
  rowCount: integer('row_count').notNull(),
  createdBy: uuid('created_by'),
  createdAt,
});

export const auditLogs = pgTable('audit_logs', {
  id: bigint('id', { mode: 'number' }).primaryKey().generatedAlwaysAsIdentity(),
  companyId: uuid('company_id').notNull(),
  actorId: uuid('actor_id'),
  action: text('action').notNull(),
  targetType: text('target_type').notNull(),
  targetId: text('target_id'),
  detail: jsonb('detail').$type<Record<string, unknown>>(),
  ip: text('ip'),
  createdAt,
});

export const schema = {
  companies,
  departments,
  employees,
  roles,
  permissions,
  rolePermissions,
  employeeRoles,
  workPatterns,
  employeeWorkPatternAssignments,
  holidays,
  timePunches,
  attendanceDays,
  attendanceDayRevisions,
  approvalRoutes,
  requests,
  requestApprovals,
  leaveGrants,
  leaveUsages,
  monthlyClosings,
  csvExports,
  auditLogs,
};
export type Schema = typeof schema;
