/**
 * デモ用シードデータ（100名規模の会社・直近3か月の打刻・申請・締め）
 */
import * as bcrypt from 'bcryptjs';
import { eq, sql } from 'drizzle-orm';
import { DEFAULT_ROLE_PERMISSIONS, PERMISSIONS, ROLE_CODES, ROLE_LABEL, type CreateRequestInput, type RoleCode } from '@kintai/shared';
import type { Db } from './client';
import {
  approvalRoutes,
  companies,
  departments,
  employeeRoles,
  employees,
  employeeWorkPatternAssignments,
  holidays,
  leaveGrants,
  permissions,
  rolePermissions,
  roles,
  timePunches,
  workPatterns,
} from './schema';
import { AttendanceCore } from '../modules/attendance/core';
import { DEFAULT_ROUTES, RequestCore } from '../modules/requests/core';
import { addDays, eachDate, localDateTimeToUtc, localWeekday, nowLocalDate } from '../domain/time';

export const DEMO_PASSWORD = 'password123';
const TZ = 'Asia/Tokyo';

// 再現性のある疑似乱数
function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 0xffffffff;
  };
}

const SURNAMES = ['佐藤', '鈴木', '高橋', '田中', '伊藤', '渡辺', '山本', '中村', '小林', '加藤', '吉田', '山田', '佐々木', '山口', '松本', '井上', '木村', '林', '斎藤', '清水', '山崎', '森', '池田', '橋本', '阿部', '石川', '山下', '中島', '石井', '小川', '前田', '岡田', '長谷川', '藤田', '後藤', '近藤', '村上', '遠藤', '青木', '坂本'];
const GIVEN = ['翔太', '陽菜', '大輝', '美咲', '健太', '結衣', '拓也', '葵', '直樹', '優花', '達也', '莉子', '大樹', '彩花', '亮', '七海', '悠斗', '真央', '颯太', '凛', '和也', '愛', '光', '遥', '蓮', '花音', '隼人', '芽依', '竜也', '杏'];
const SURNAMES_KANA = ['サトウ', 'スズキ', 'タカハシ', 'タナカ', 'イトウ', 'ワタナベ', 'ヤマモト', 'ナカムラ', 'コバヤシ', 'カトウ', 'ヨシダ', 'ヤマダ', 'ササキ', 'ヤマグチ', 'マツモト', 'イノウエ', 'キムラ', 'ハヤシ', 'サイトウ', 'シミズ', 'ヤマザキ', 'モリ', 'イケダ', 'ハシモト', 'アベ', 'イシカワ', 'ヤマシタ', 'ナカジマ', 'イシイ', 'オガワ', 'マエダ', 'オカダ', 'ハセガワ', 'フジタ', 'ゴトウ', 'コンドウ', 'ムラカミ', 'エンドウ', 'アオキ', 'サカモト'];

const NATIONAL_HOLIDAYS_2026: [string, string][] = [
  ['2026-01-01', '元日'], ['2026-01-12', '成人の日'], ['2026-02-11', '建国記念の日'], ['2026-02-23', '天皇誕生日'],
  ['2026-03-20', '春分の日'], ['2026-04-29', '昭和の日'], ['2026-05-03', '憲法記念日'], ['2026-05-04', 'みどりの日'],
  ['2026-05-05', 'こどもの日'], ['2026-05-06', '振替休日'], ['2026-07-20', '海の日'], ['2026-08-11', '山の日'],
  ['2026-09-21', '敬老の日'], ['2026-09-22', '国民の休日'], ['2026-09-23', '秋分の日'], ['2026-10-12', 'スポーツの日'],
  ['2026-11-03', '文化の日'], ['2026-11-23', '勤労感謝の日'],
];
const COMPANY_HOLIDAYS: [string, string][] = [
  ['2026-08-13', '夏季休暇'], ['2026-08-14', '夏季休暇'], ['2026-12-29', '年末休暇'], ['2026-12-30', '年末休暇'], ['2026-12-31', '年末休暇'],
  ['2027-01-02', '年始休暇'], ['2027-01-03', '年始休暇'], ['2025-12-29', '年末休暇'], ['2025-12-30', '年末休暇'], ['2025-12-31', '年末休暇'],
];

export async function seedIfEmpty(db: Db, log: (m: string) => void = () => {}): Promise<boolean> {
  const c = await db.select({ n: sql<number>`count(*)::int` }).from(companies);
  if (Number(c[0].n) > 0) return false;
  await seed(db, log);
  return true;
}

export async function seed(db: Db, log: (m: string) => void = () => {}, opts: { now?: Date } = {}) {
  const now = opts.now ?? new Date();
  const today = nowLocalDate(TZ, now);
  const rand = rng(20260821);
  const pick = <T>(arr: T[]) => arr[Math.floor(rand() * arr.length)];
  const passwordHash = await bcrypt.hash(DEMO_PASSWORD, 10);

  // ── 会社 ───────────────────────────────────────────────
  log('seeding company / roles / departments');
  const [company] = await db
    .insert(companies)
    .values({
      name: '株式会社サンプル',
      timezone: TZ,
      settings: {
        name: '株式会社サンプル',
        timezone: TZ,
        closingDay: 31,
        officeLatitude: 35.681236,
        officeLongitude: 139.767125,
        geofenceRadiusM: 500,
        overtimeAlertMinutes: 45 * 60,
        overtimeLimitMinutes: 80 * 60,
      },
    })
    .returning();
  const companyId = company.id;

  // ── 権限・ロール ─────────────────────────────────────────
  await db.insert(permissions).values(PERMISSIONS.map((code) => ({ code }))).onConflictDoNothing();
  const roleRows = await db
    .insert(roles)
    .values(ROLE_CODES.map((code) => ({ companyId, code, name: ROLE_LABEL[code] })))
    .returning();
  const roleId: Record<RoleCode, string> = Object.fromEntries(roleRows.map((r) => [r.code, r.id])) as Record<RoleCode, string>;
  await db.insert(rolePermissions).values(
    ROLE_CODES.flatMap((code) => DEFAULT_ROLE_PERMISSIONS[code].map((p) => ({ roleId: roleId[code], permissionCode: p }))),
  );

  // ── 部署 ───────────────────────────────────────────────
  const deptDefs = [
    { code: 'MGMT', name: '経営企画室', size: 4 },
    { code: 'SALES1', name: '営業1課', size: 14 },
    { code: 'SALES2', name: '営業2課', size: 12 },
    { code: 'DEV1', name: '開発1課', size: 16 },
    { code: 'DEV2', name: '開発2課', size: 14 },
    { code: 'QA', name: '品質保証課', size: 8 },
    { code: 'CS', name: 'カスタマーサクセス', size: 12 },
    { code: 'HR', name: '人事総務部', size: 8 },
    { code: 'FIN', name: '経理部', size: 6 },
    { code: 'MKT', name: 'マーケティング部', size: 6 },
  ];
  const deptRows = await db.insert(departments).values(deptDefs.map((d) => ({ companyId, code: d.code, name: d.name }))).returning();
  const deptByCode = Object.fromEntries(deptRows.map((d) => [d.code, d]));

  // ── 勤務パターン ─────────────────────────────────────────
  log('seeding work patterns');
  const wpDefs = [
    { code: 'STD', name: '標準勤務 (9:00-18:00)', patternType: 'FIXED', rules: { start: '09:00', end: '18:00', scheduledMinutes: 480, breaks: [{ from: '12:00', to: '13:00' }], roundingIn: { unitMinutes: 1, mode: 'NONE' }, roundingOut: { unitMinutes: 1, mode: 'NONE' } } },
    { code: 'FLEX', name: 'フレックス (コア10:00-15:00)', patternType: 'FLEX', rules: { coreStart: '10:00', coreEnd: '15:00', flexStart: '07:00', flexEnd: '22:00', scheduledMinutes: 480, breaks: [{ from: '12:00', to: '13:00' }] } },
    { code: 'EARLY', name: '早番 (7:00-16:00)', patternType: 'SHIFT', rules: { start: '07:00', end: '16:00', scheduledMinutes: 480, breaks: [{ from: '11:30', to: '12:30' }] } },
    { code: 'LATE', name: '遅番 (13:00-22:00)', patternType: 'SHIFT', rules: { start: '13:00', end: '22:00', scheduledMinutes: 480, breaks: [{ from: '17:00', to: '18:00' }] } },
    { code: 'NIGHT', name: '夜勤 (22:00-翌7:00)', patternType: 'SHIFT', rules: { start: '22:00', end: '07:00', scheduledMinutes: 480, breaks: [{ from: '02:00', to: '03:00' }], dayBoundary: '12:00' } },
    { code: 'DISC', name: '裁量労働 (みなし8h)', patternType: 'DISCRETIONARY', rules: { scheduledMinutes: 480, breaks: [] } },
    { code: 'STD15', name: '標準勤務 15分丸め', patternType: 'FIXED', rules: { start: '09:00', end: '18:00', scheduledMinutes: 480, breaks: [{ from: '12:00', to: '13:00' }], roundingIn: { unitMinutes: 15, mode: 'CEIL' }, roundingOut: { unitMinutes: 15, mode: 'FLOOR' } } },
  ];
  const wpRows = await db
    .insert(workPatterns)
    .values(wpDefs.map((w) => ({ companyId, code: w.code, name: w.name, patternType: w.patternType, rules: w.rules, validFrom: '2020-04-01' })))
    .returning();
  const wpByCode = Object.fromEntries(wpRows.map((w) => [w.code, w]));

  // ── 休日 ───────────────────────────────────────────────
  await db.insert(holidays).values([
    ...NATIONAL_HOLIDAYS_2026.map(([date, name]) => ({ companyId, date, name, kind: 'NATIONAL' })),
    ...COMPANY_HOLIDAYS.map(([date, name]) => ({ companyId, date, name, kind: 'COMPANY' })),
  ]);

  // ── 承認ルート ─────────────────────────────────────────
  await db.insert(approvalRoutes).values(
    Object.entries(DEFAULT_ROUTES).map(([requestType, steps]) => ({ companyId, requestType, name: `${requestType} 既定ルート`, steps })),
  );

  // ── 従業員 ─────────────────────────────────────────────
  log('seeding employees');
  type EmpSeed = { code: string; name: string; kana: string; email: string; dept: string; roles: RoleCode[]; pattern: string; hiredAt: string };
  const emps: EmpSeed[] = [];
  let seq = 1;
  const mk = (dept: string, rolesArr: RoleCode[], pattern: string, email?: string, name?: string, kana?: string): EmpSeed => {
    const si = Math.floor(rand() * SURNAMES.length);
    const gi = Math.floor(rand() * GIVEN.length);
    const code = `E${String(seq).padStart(4, '0')}`;
    const e: EmpSeed = {
      code,
      name: name ?? `${SURNAMES[si]} ${GIVEN[gi]}`,
      kana: kana ?? `${SURNAMES_KANA[si]}`,
      email: email ?? `emp${String(seq).padStart(3, '0')}@example.com`,
      dept,
      roles: rolesArr,
      pattern,
      hiredAt: `${2015 + Math.floor(rand() * 11)}-04-01`,
    };
    seq++;
    return e;
  };
  // 固定アカウント
  emps.push(mk('HR', ['ADMIN'], 'STD', 'admin@example.com', '管理 太郎', 'カンリ'));
  emps.push(mk('HR', ['HR'], 'STD', 'hr@example.com', '労務 花子', 'ロウム'));
  emps.push(mk('DEV1', ['MANAGER'], 'FLEX', 'manager@example.com', '開発 一郎', 'カイハツ'));
  emps.push(mk('DEV1', ['EMPLOYEE'], 'FLEX', 'employee@example.com', '社員 次郎', 'シャイン'));
  // 各部署に管理者1名 + メンバー
  const patternFor = (dept: string) => {
    if (dept.startsWith('DEV')) return rand() < 0.7 ? 'FLEX' : 'DISC';
    if (dept === 'CS') return pick(['EARLY', 'LATE', 'STD']);
    if (dept === 'QA') return rand() < 0.5 ? 'STD15' : 'FLEX';
    if (dept === 'MGMT') return 'DISC';
    return 'STD';
  };
  for (const d of deptDefs) {
    const already = emps.filter((e) => e.dept === d.code).length;
    if (d.code !== 'DEV1') emps.push(mk(d.code, ['MANAGER'], d.code.startsWith('DEV') ? 'FLEX' : 'STD'));
    const remaining = Math.max(0, d.size - already - (d.code !== 'DEV1' ? 1 : 0));
    for (let i = 0; i < remaining; i++) emps.push(mk(d.code, d.code === 'HR' && i === 0 ? ['HR'] : ['EMPLOYEE'], patternFor(d.code)));
  }
  // 夜勤者を CS に数名
  emps.filter((e) => e.dept === 'CS').slice(-3).forEach((e) => (e.pattern = 'NIGHT'));

  const empRows = await db
    .insert(employees)
    .values(
      emps.map((e) => ({
        companyId,
        employeeCode: e.code,
        name: e.name,
        nameKana: e.kana,
        email: e.email,
        passwordHash,
        departmentId: deptByCode[e.dept].id,
        hiredAt: e.hiredAt,
      })),
    )
    .returning();
  const empByCode = Object.fromEntries(empRows.map((r) => [r.employeeCode, r]));

  // 管理者を部署に設定
  for (const d of deptDefs) {
    const mgr = emps.find((e) => e.dept === d.code && e.roles.includes('MANAGER'));
    if (mgr) await db.update(departments).set({ managerId: empByCode[mgr.code].id }).where(eq(departments.id, deptByCode[d.code].id));
  }
  // ロール付与
  await db.insert(employeeRoles).values(
    emps.flatMap((e) =>
      e.roles.map((r) => ({
        employeeId: empByCode[e.code].id,
        roleId: roleId[r],
        scopeType: r === 'MANAGER' ? 'DEPARTMENT' : 'COMPANY',
        scopeId: r === 'MANAGER' ? deptByCode[e.dept].id : null,
        validFrom: e.hiredAt,
      })),
    ),
  );
  // 勤務パターン割当（一部は途中で変更歴あり）
  const assignRows: (typeof employeeWorkPatternAssignments.$inferInsert)[] = [];
  for (const e of emps) {
    const id = empByCode[e.code].id;
    if (rand() < 0.15 && e.pattern !== 'NIGHT') {
      // 今年7月からパターン変更した人
      const before = e.pattern === 'FLEX' ? 'STD' : 'FLEX';
      assignRows.push({ employeeId: id, workPatternId: wpByCode[before].id, validFrom: e.hiredAt, validTo: '2026-06-30' });
      assignRows.push({ employeeId: id, workPatternId: wpByCode[e.pattern].id, validFrom: '2026-07-01', validTo: null });
    } else {
      assignRows.push({ employeeId: id, workPatternId: wpByCode[e.pattern].id, validFrom: e.hiredAt, validTo: null });
    }
  }
  await db.insert(employeeWorkPatternAssignments).values(assignRows);

  // 有給付与
  await db.insert(leaveGrants).values(
    emps.flatMap((e) => {
      const id = empByCode[e.code].id;
      const years = 2026 - Number(e.hiredAt.slice(0, 4));
      const days = Math.min(20, 10 + Math.max(0, years - 1) * 2);
      return [
        { employeeId: id, leaveType: 'PAID', days: String(days), grantedAt: '2026-04-01', expiresAt: '2028-03-31', note: '2026年度付与' },
        { employeeId: id, leaveType: 'PAID', days: String(Math.floor(rand() * 6)), grantedAt: '2025-04-01', expiresAt: '2027-03-31', note: '2025年度繰越' },
        { employeeId: id, leaveType: 'SPECIAL', days: '3', grantedAt: '2026-04-01', expiresAt: '2027-03-31', note: '特別休暇' },
      ];
    }),
  );

  // ── 打刻 (直近3か月) ─────────────────────────────────────
  log('seeding punches (this may take a moment)');
  const from = addDays(today, -80).slice(0, 7) + '-01';
  const dates = eachDate(from, today);
  const holidaySet = new Set([...NATIONAL_HOLIDAYS_2026, ...COMPANY_HOLIDAYS].map(([d]) => d));
  const office = { lat: 35.681236, lng: 139.767125 };
  const wpRulesByCode: Record<string, { start: string; end: string; boundary: string; breaks: boolean }> = {
    STD: { start: '09:00', end: '18:00', boundary: '05:00', breaks: false },
    STD15: { start: '09:00', end: '18:00', boundary: '05:00', breaks: false },
    FLEX: { start: '09:30', end: '18:30', boundary: '05:00', breaks: false },
    EARLY: { start: '07:00', end: '16:00', boundary: '05:00', breaks: true },
    LATE: { start: '13:00', end: '22:00', boundary: '05:00', breaks: true },
    NIGHT: { start: '22:00', end: '07:00', boundary: '12:00', breaks: true },
    DISC: { start: '10:00', end: '19:00', boundary: '05:00', breaks: false },
  };
  const hmPlus = (hm: string, minutes: number) => {
    const [h, m] = hm.split(':').map(Number);
    const t = ((h * 60 + m + minutes) % 1440 + 1440) % 1440;
    return `${String(Math.floor(t / 60)).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`;
  };
  const punchBatch: (typeof timePunches.$inferInsert)[] = [];
  const leaveDays: { emp: EmpSeed; date: string }[] = [];
  const nowMs = now.getTime();
  let uuidSeq = 0;
  const mkUuid = () => {
    // 決定論的 UUID v4 風
    const hex = (n: number) => n.toString(16).padStart(8, '0');
    uuidSeq++;
    return `${hex(uuidSeq)}-0000-4000-8000-${hex(Math.floor(rand() * 0xffffffff))}0000`.slice(0, 36);
  };
  for (const e of emps) {
    const id = empByCode[e.code].id;
    const r = wpRulesByCode[e.pattern];
    const punctual = rand(); // 個人の傾向
    const hardWorker = rand();
    for (const d of dates) {
      const wd = localWeekday(d);
      if (wd === 0 || wd === 6 || holidaySet.has(d)) {
        // たまに休日出勤
        if (rand() < 0.03 && wd === 6) {
          const inAt = localDateTimeToUtc(d, '10:00', TZ);
          const outAt = localDateTimeToUtc(d, '15:00', TZ);
          if (outAt.getTime() < nowMs) {
            punchBatch.push({ employeeId: id, punchType: 'IN', punchedAt: inAt, receivedAt: inAt, source: 'WEB', clientRequestId: mkUuid(), geofenceOk: true, latitude: String(office.lat), longitude: String(office.lng) });
            punchBatch.push({ employeeId: id, punchType: 'OUT', punchedAt: outAt, receivedAt: outAt, source: 'WEB', clientRequestId: mkUuid(), geofenceOk: true, latitude: String(office.lat), longitude: String(office.lng) });
          }
        }
        continue;
      }
      const roll = rand();
      if (roll < 0.025) {
        leaveDays.push({ emp: e, date: d });
        continue;
      }
      if (roll < 0.035) continue; // 打刻なし（欠勤 or 漏れ）
      const lateJitter = punctual < 0.15 ? Math.floor(rand() * 40) - 10 : Math.floor(rand() * 18) - 16;
      const inHm = hmPlus(r.start, lateJitter);
      const otBase = hardWorker > 0.7 ? 120 : hardWorker > 0.4 ? 45 : 10;
      const outJitter = Math.floor(rand() * otBase) - 5;
      const outHm = hmPlus(r.end, outJitter);
      const outDayOffset = e.pattern === 'NIGHT' ? 1 : 0;
      const inAt = localDateTimeToUtc(d, inHm, TZ);
      const outAt = localDateTimeToUtc(addDays(d, outDayOffset), outHm, TZ);
      const src = rand() < 0.4 ? 'MOBILE' : 'WEB';
      const geoOk = rand() > 0.04;
      const lat = geoOk ? office.lat + (rand() - 0.5) * 0.002 : office.lat + 0.05;
      const lng = geoOk ? office.lng + (rand() - 0.5) * 0.002 : office.lng + 0.05;
      if (inAt.getTime() < nowMs) {
        punchBatch.push({ employeeId: id, punchType: 'IN', punchedAt: inAt, receivedAt: inAt, source: src, clientRequestId: mkUuid(), geofenceOk: src === 'MOBILE' ? geoOk : null, latitude: src === 'MOBILE' ? String(lat) : null, longitude: src === 'MOBILE' ? String(lng) : null });
      }
      if (r.breaks && inAt.getTime() < nowMs) {
        const bs = new Date(inAt.getTime() + 4 * 3600_000);
        const be = new Date(bs.getTime() + 60 * 60_000);
        if (be.getTime() < nowMs) {
          punchBatch.push({ employeeId: id, punchType: 'BREAK_START', punchedAt: bs, receivedAt: bs, source: src, clientRequestId: mkUuid() });
          punchBatch.push({ employeeId: id, punchType: 'BREAK_END', punchedAt: be, receivedAt: be, source: src, clientRequestId: mkUuid() });
        }
      }
      // 退勤打刻漏れ 2%
      if (outAt.getTime() < nowMs && rand() > 0.02) {
        punchBatch.push({ employeeId: id, punchType: 'OUT', punchedAt: outAt, receivedAt: outAt, source: src, clientRequestId: mkUuid(), geofenceOk: src === 'MOBILE' ? true : null, latitude: src === 'MOBILE' ? String(lat) : null, longitude: src === 'MOBILE' ? String(lng) : null });
      }
    }
  }
  for (let i = 0; i < punchBatch.length; i += 500) {
    await db.insert(timePunches).values(punchBatch.slice(i, i + 500));
  }
  log(`inserted ${punchBatch.length} punches`);

  // ── 申請（承認済み休暇 / 承認待ち各種） ─────────────────────
  log('seeding requests');
  const reqCore = new RequestCore(db);
  const hrId = empByCode[emps.find((e) => e.roles.includes('HR'))!.code].id;
  let approvedLeaves = 0;
  for (const l of leaveDays) {
    const empId = empByCode[l.emp.code].id;
    const input: CreateRequestInput = {
      requestType: 'LEAVE',
      reason: pick(['私用のため', '通院のため', '家族の用事', 'リフレッシュ休暇', '引越しのため']),
      payload: { dateFrom: l.date, dateTo: l.date, leaveType: rand() < 0.9 ? 'PAID' : 'SPECIAL', unit: rand() < 0.8 ? 'FULL' : rand() < 0.5 ? 'AM' : 'PM' },
    };
    const created = await reqCore.createRequest({ companyId, employeeId: empId, input, now: localDateTimeToUtc(addDays(l.date, -3), '10:00', TZ) });
    if (created.status === 'APPROVED') {
      approvedLeaves++;
      continue;
    }
    // 承認者（管理者 → HR）で順に承認
    const mgrId = await reqCore.departmentManagerOf(empId);
    if (l.date <= today) {
      const t = localDateTimeToUtc(addDays(l.date, -2), '11:00', TZ);
      let res = await reqCore.decide({ requestId: created.id, approverId: mgrId ?? hrId, decision: 'APPROVED', now: t });
      if (res.status === 'PENDING') res = await reqCore.decide({ requestId: created.id, approverId: hrId, decision: 'APPROVED', now: t });
      approvedLeaves++;
    }
  }
  log(`approved ${approvedLeaves} leave requests`);

  // 承認待ちの申請を生成（デモ用）
  const pendingTargets = emps.filter((e) => e.roles.includes('EMPLOYEE')).slice(0, 14);
  const yesterday = addDays(today, -1);
  const fixtures: CreateRequestInput[] = [
    { requestType: 'CORRECTION', reason: '退勤打刻を忘れました', payload: { date: addDays(today, -3), clockOutAt: localDateTimeToUtc(addDays(today, -3), '18:30', TZ).toISOString() } },
    { requestType: 'OVERTIME', reason: 'リリース対応のため', payload: { date: today, plannedMinutes: 120 } },
    { requestType: 'LEAVE', reason: '私用のため', payload: { dateFrom: addDays(today, 7), dateTo: addDays(today, 8), leaveType: 'PAID', unit: 'FULL' } },
    { requestType: 'HOLIDAY_WORK', reason: '月末の棚卸対応', payload: { date: addDays(today, 9), plannedStart: '09:00', plannedEnd: '15:00', compensatory: true } },
    { requestType: 'LATE_EARLY', reason: '電車遅延のため', payload: { date: yesterday, kind: 'LATE', minutes: 25 } },
    { requestType: 'LEAVE', reason: '通院のため', payload: { dateFrom: addDays(today, 3), dateTo: addDays(today, 3), leaveType: 'PAID', unit: 'AM' } },
    { requestType: 'CORRECTION', reason: '出勤打刻が二重になっていたため修正', payload: { date: addDays(today, -5), clockInAt: localDateTimeToUtc(addDays(today, -5), '08:55', TZ).toISOString() } },
  ];
  for (let i = 0; i < pendingTargets.length; i++) {
    const f = fixtures[i % fixtures.length];
    await reqCore.createRequest({ companyId, employeeId: empByCode[pendingTargets[i].code].id, input: f, now: new Date(nowMs - (i + 1) * 3600_000) });
  }
  // デモ社員 (employee@example.com) の申請もいくつか
  const demoEmp = empByCode['E0004'].id;
  const demoReq = await reqCore.createRequest({ companyId, employeeId: demoEmp, input: fixtures[0], now: new Date(nowMs - 2 * 86400_000) });
  await reqCore.createRequest({ companyId, employeeId: demoEmp, input: fixtures[2], now: new Date(nowMs - 86400_000) });
  const rejected = await reqCore.createRequest({ companyId, employeeId: demoEmp, input: { requestType: 'OVERTIME', reason: '作業遅延のため', payload: { date: addDays(today, -10), plannedMinutes: 180 } }, now: new Date(nowMs - 10 * 86400_000) });
  if (rejected.status === 'PENDING') {
    const mgrId = await reqCore.departmentManagerOf(demoEmp);
    await reqCore.decide({ requestId: rejected.id, approverId: mgrId ?? hrId, decision: 'REJECTED', comment: '事前申請をお願いします', now: new Date(nowMs - 9 * 86400_000) });
  }
  void demoReq;

  // ── 再計算 & 先々月の締め ───────────────────────────────
  log('recalculating attendance');
  const attendance = new AttendanceCore(db);
  await attendance.recalcCompanyRange(companyId, from, today, now);

  const twoMonthsAgo = addDays(today, -62).slice(0, 7);
  if (twoMonthsAgo >= from.slice(0, 7)) {
    log(`locking month ${twoMonthsAgo}`);
    const adminId = empByCode['E0001'].id;
    for (const e of empRows) await attendance.lockMonth(companyId, e.id, twoMonthsAgo, adminId, now);
  }
  log('seed completed');
  return { companyId };
}
