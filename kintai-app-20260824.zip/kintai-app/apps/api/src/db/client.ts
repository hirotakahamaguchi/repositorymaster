/**
 * DB クライアント生成
 *  - DATABASE_URL が設定されていれば node-postgres (本番: Aurora/RDS PostgreSQL)
 *  - 未設定なら PGlite (WASM 版 PostgreSQL) をファイル永続化で起動（ローカル開発・テスト）
 * どちらも同じ SQL / 同じ Drizzle スキーマで動く。
 */
import { drizzle as drizzlePg, NodePgDatabase } from 'drizzle-orm/node-postgres';
import { drizzle as drizzlePglite, PgliteDatabase } from 'drizzle-orm/pglite';
import { Pool } from 'pg';
import { PGlite, type Extension } from '@electric-sql/pglite';

// contrib サブパスは exports の types が ESM 向けのため CJS からは require で読み込む
// eslint-disable-next-line @typescript-eslint/no-require-imports
const { btree_gist } = require('@electric-sql/pglite/contrib/btree_gist') as { btree_gist: Extension };
import * as path from 'node:path';
import { schema, Schema } from './schema';

export type Db = NodePgDatabase<Schema> | PgliteDatabase<Schema>;

export interface DbHandle {
  db: Db;
  kind: 'pg' | 'pglite';
  /** 複数ステートメントを含む生 SQL を simple query protocol で実行（マイグレーション用） */
  execRaw(sqlText: string): Promise<void>;
  close(): Promise<void>;
}

export async function createDb(opts?: { databaseUrl?: string; pgliteDir?: string | 'memory' }): Promise<DbHandle> {
  const url = opts?.databaseUrl ?? process.env.DATABASE_URL;
  if (url) {
    const pool = new Pool({
      connectionString: url,
      max: Number(process.env.DB_POOL_MAX ?? 10),
      ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : undefined,
    });
    const db = drizzlePg(pool, { schema });
    return {
      db,
      kind: 'pg',
      execRaw: async (t) => {
        await pool.query(t);
      },
      close: () => pool.end(),
    };
  }
  const dir = opts?.pgliteDir ?? process.env.PGLITE_DIR ?? path.resolve(process.cwd(), '.pgdata');
  const client =
    dir === 'memory'
      ? new PGlite({ extensions: { btree_gist } })
      : new PGlite(dir, { extensions: { btree_gist } });
  await client.waitReady;
  const db = drizzlePglite(client, { schema });
  return {
    db,
    kind: 'pglite',
    execRaw: async (t) => {
      await client.exec(t);
    },
    close: () => client.close(),
  };
}
