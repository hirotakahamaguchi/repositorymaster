import { Global, Inject, Logger, Module, OnApplicationShutdown, OnModuleInit } from '@nestjs/common';
import { createDb, Db, DbHandle } from './client';
import { runMigrations } from './migrate';
import { seedIfEmpty } from './seed';

export const DB = Symbol('DB');
export const DB_HANDLE = Symbol('DB_HANDLE');

@Global()
@Module({
  providers: [
    {
      provide: DB_HANDLE,
      useFactory: async (): Promise<DbHandle> => createDb(),
    },
    {
      provide: DB,
      useFactory: (h: DbHandle): Db => h.db,
      inject: [DB_HANDLE],
    },
  ],
  exports: [DB, DB_HANDLE],
})
export class DbModule implements OnModuleInit, OnApplicationShutdown {
  private readonly logger = new Logger('DB');
  constructor(@Inject(DB_HANDLE) private readonly handle: DbHandle) {}

  async onModuleInit() {
    this.logger.log(`using ${this.handle.kind === 'pg' ? 'PostgreSQL (DATABASE_URL)' : 'PGlite (embedded PostgreSQL)'}`);
    const applied = await runMigrations(this.handle, (m) => this.logger.log(m));
    if (applied.length) this.logger.log(`applied ${applied.length} migration(s)`);
    if (process.env.SEED_ON_EMPTY !== 'false') {
      const seeded = await seedIfEmpty(this.handle.db, (m) => this.logger.log(m));
      if (seeded) this.logger.log('demo data seeded');
    }
  }

  async onApplicationShutdown() {
    await this.handle.close();
  }
}
