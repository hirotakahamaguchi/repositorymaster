import { Controller, Get, Module } from '@nestjs/common';
import { DbModule } from './db/db.module';
import { AuthModule } from './modules/auth/auth.module';
import { AuditModule } from './modules/audit/audit.module';
import { CompanyModule } from './modules/company/company.module';
import { EmployeesModule } from './modules/employees/employees.module';
import { WorkPatternsModule } from './modules/work-patterns/work-patterns.module';
import { HolidaysModule } from './modules/holidays/holidays.module';
import { PunchesModule } from './modules/punches/punches.module';
import { AttendanceModule } from './modules/attendance/attendance.module';
import { RequestsModule } from './modules/requests/requests.module';
import { LeavesModule } from './modules/leaves/leaves.module';
import { ClosingsModule } from './modules/closings/closings.module';
import { DashboardModule } from './modules/dashboard/dashboard.module';
import { JobsModule } from './modules/jobs/jobs.module';
import { Public } from './common/decorators';

@Controller()
export class HealthController {
  @Public()
  @Get('health')
  health() {
    return { status: 'ok', time: new Date().toISOString() };
  }
}

@Module({
  imports: [
    DbModule,
    AuditModule,
    AuthModule,
    CompanyModule,
    EmployeesModule,
    WorkPatternsModule,
    HolidaysModule,
    PunchesModule,
    AttendanceModule,
    RequestsModule,
    LeavesModule,
    ClosingsModule,
    DashboardModule,
    JobsModule,
  ],
  controllers: [HealthController],
})
export class AppModule {}
