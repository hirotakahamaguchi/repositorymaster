import { Inject, Injectable, UnauthorizedException, BadRequestException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import { and, eq, sql } from 'drizzle-orm';
import type { Permission, RoleCode } from '@kintai/shared';
import { DB } from '../../db/db.module';
import type { Db } from '../../db/client';
import { companies, departments, employeeRoles, employees, rolePermissions, roles } from '../../db/schema';
import type { AuthUser } from '../../common/auth-user';
import { parseSettings } from '../attendance/core';

@Injectable()
export class AuthService {
  constructor(
    @Inject(DB) private readonly db: Db,
    private readonly jwt: JwtService,
  ) {}

  async login(email: string, password: string): Promise<{ token: string; user: AuthUser }> {
    const [emp] = await this.db.select().from(employees).where(eq(employees.email, email.toLowerCase())).limit(1);
    if (!emp || !emp.passwordHash) throw new UnauthorizedException('メールアドレスまたはパスワードが正しくありません');
    if (emp.retiredAt && emp.retiredAt < new Date().toISOString().slice(0, 10)) throw new UnauthorizedException('このアカウントは無効です');
    const ok = await bcrypt.compare(password, emp.passwordHash);
    if (!ok) throw new UnauthorizedException('メールアドレスまたはパスワードが正しくありません');
    const user = await this.loadUser(emp.id);
    if (!user) throw new UnauthorizedException();
    const token = await this.jwt.signAsync({ sub: emp.id, email: emp.email });
    return { token, user };
  }

  async changePassword(userId: string, currentPassword: string, newPassword: string) {
    const [emp] = await this.db.select().from(employees).where(eq(employees.id, userId)).limit(1);
    if (!emp?.passwordHash || !(await bcrypt.compare(currentPassword, emp.passwordHash)))
      throw new BadRequestException('現在のパスワードが正しくありません');
    await this.db.update(employees).set({ passwordHash: await bcrypt.hash(newPassword, 10) }).where(eq(employees.id, userId));
  }

  /** JWT の subject からユーザ情報・権限・管理部署を組み立てる（毎リクエスト。キャッシュ可） */
  async loadUser(employeeId: string): Promise<AuthUser | null> {
    const rows = await this.db
      .select({
        id: employees.id,
        employeeCode: employees.employeeCode,
        name: employees.name,
        email: employees.email,
        companyId: employees.companyId,
        companyName: companies.name,
        timezone: companies.timezone,
        settings: companies.settings,
        departmentId: employees.departmentId,
        departmentName: departments.name,
        retiredAt: employees.retiredAt,
      })
      .from(employees)
      .innerJoin(companies, eq(companies.id, employees.companyId))
      .leftJoin(departments, eq(departments.id, employees.departmentId))
      .where(eq(employees.id, employeeId))
      .limit(1);
    const e = rows[0];
    if (!e) return null;

    const today = new Date().toISOString().slice(0, 10);
    const roleRows = await this.db
      .select({ code: roles.code, scopeType: employeeRoles.scopeType, scopeId: employeeRoles.scopeId, roleId: roles.id })
      .from(employeeRoles)
      .innerJoin(roles, eq(roles.id, employeeRoles.roleId))
      .where(
        and(
          eq(employeeRoles.employeeId, employeeId),
          sql`${employeeRoles.validFrom} <= ${today}`,
          sql`(${employeeRoles.validTo} is null or ${employeeRoles.validTo} >= ${today})`,
        ),
      );
    const roleIds = roleRows.map((r) => r.roleId);
    const permRows = roleIds.length
      ? await this.db
          .select({ code: rolePermissions.permissionCode })
          .from(rolePermissions)
          .where(sql`${rolePermissions.roleId} in ${roleIds}`)
      : [];
    const managed = await this.db
      .select({ id: departments.id })
      .from(departments)
      .where(eq(departments.managerId, employeeId));
    const managedDepartmentIds = new Set<string>([
      ...managed.map((m) => m.id),
      ...roleRows.filter((r) => r.scopeType === 'DEPARTMENT' && r.scopeId).map((r) => r.scopeId as string),
    ]);
    // 管理部署の子部署も管理対象に含める
    if (managedDepartmentIds.size > 0) {
      const children = await this.db
        .select({ id: departments.id, parentId: departments.parentId })
        .from(departments)
        .where(eq(departments.companyId, e.companyId));
      let changed = true;
      while (changed) {
        changed = false;
        for (const c of children) {
          if (c.parentId && managedDepartmentIds.has(c.parentId) && !managedDepartmentIds.has(c.id)) {
            managedDepartmentIds.add(c.id);
            changed = true;
          }
        }
      }
    }
    return {
      id: e.id,
      employeeCode: e.employeeCode,
      name: e.name,
      email: e.email,
      companyId: e.companyId,
      companyName: e.companyName,
      timezone: e.timezone,
      settings: parseSettings(e.settings),
      departmentId: e.departmentId,
      departmentName: e.departmentName,
      roles: [...new Set(roleRows.map((r) => r.code as RoleCode))],
      permissions: [...new Set(permRows.map((p) => p.code as Permission))],
      managedDepartmentIds: [...managedDepartmentIds],
    };
  }
}
