import { Global, Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { APP_GUARD } from '@nestjs/core';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { AccessService } from './access.service';
import { AuthGuard, PermissionsGuard } from '../../common/guards';
import { AuditModule } from '../audit/audit.module';

@Global()
@Module({
  imports: [
    JwtModule.register({
      secret: process.env.JWT_SECRET ?? 'dev-only-secret-change-me',
      signOptions: { expiresIn: '12h' },
    }),
    AuditModule,
  ],
  providers: [
    AuthService,
    AccessService,
    { provide: APP_GUARD, useClass: AuthGuard },
    { provide: APP_GUARD, useClass: PermissionsGuard },
  ],
  controllers: [AuthController],
  exports: [AuthService, AccessService, JwtModule],
})
export class AuthModule {}
