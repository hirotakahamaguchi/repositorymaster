import { Body, Controller, Get, HttpCode, Post, Res } from '@nestjs/common';
import type { Response } from 'express';
import { ChangePasswordSchema, LoginSchema, type ChangePasswordInput, type LoginInput, type CurrentUser as CurrentUserDto } from '@kintai/shared';
import { AuthService } from './auth.service';
import { CurrentUser, Public, ClientIp } from '../../common/decorators';
import { zodBody } from '../../common/zod.pipe';
import { AUTH_COOKIE } from '../../common/guards';
import type { AuthUser } from '../../common/auth-user';
import { AuditService } from '../audit/audit.service';

function toDto(u: AuthUser): CurrentUserDto {
  return {
    id: u.id,
    employeeCode: u.employeeCode,
    name: u.name,
    email: u.email,
    companyId: u.companyId,
    companyName: u.companyName,
    departmentId: u.departmentId,
    departmentName: u.departmentName,
    roles: u.roles,
    permissions: u.permissions,
    managedDepartmentIds: u.managedDepartmentIds,
    settings: u.settings,
  };
}

@Controller('auth')
export class AuthController {
  constructor(
    private readonly auth: AuthService,
    private readonly audit: AuditService,
  ) {}

  @Public()
  @Post('login')
  @HttpCode(200)
  async login(@Body(zodBody(LoginSchema)) body: LoginInput, @Res({ passthrough: true }) res: Response, @ClientIp() ip: string | null) {
    const { token, user } = await this.auth.login(body.email, body.password);
    res.cookie(AUTH_COOKIE, token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.COOKIE_SECURE === 'true',
      maxAge: 12 * 3600_000,
      path: '/',
    });
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'auth.login', targetType: 'employee', targetId: user.id, ip });
    return { token, user: toDto(user) };
  }

  @Post('logout')
  @HttpCode(204)
  logout(@Res({ passthrough: true }) res: Response) {
    res.clearCookie(AUTH_COOKIE, { path: '/' });
  }

  @Get('me')
  me(@CurrentUser() user: AuthUser): CurrentUserDto {
    return toDto(user);
  }

  @Post('password')
  @HttpCode(204)
  async changePassword(@CurrentUser() user: AuthUser, @Body(zodBody(ChangePasswordSchema)) body: ChangePasswordInput) {
    await this.auth.changePassword(user.id, body.currentPassword, body.newPassword);
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'auth.password_changed', targetType: 'employee', targetId: user.id });
  }
}
