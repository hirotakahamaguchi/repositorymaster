import { ForbiddenException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { and, eq, inArray } from 'drizzle-orm';
import { DB } from '../../db/db.module';
import type { Db } from '../../db/client';
import { employees } from '../../db/schema';
import { hasPermission, type AuthUser } from '../../common/auth-user';

/**
 * スコープ付きアクセス制御
 *  - self: 自分自身
 *  - department: 管理対象部署に所属する従業員
 *  - company: 同一会社の全従業員
 */
@Injectable()
export class AccessService {
  constructor(@Inject(DB) private readonly db: Db) {}

  async employeeDepartment(employeeId: string): Promise<{ companyId: string; departmentId: string | null }> {
    const [e] = await this.db
      .select({ companyId: employees.companyId, departmentId: employees.departmentId })
      .from(employees)
      .where(eq(employees.id, employeeId))
      .limit(1);
    if (!e) throw new NotFoundException('従業員が見つかりません');
    return e;
  }

  /** 指定従業員の勤怠を閲覧できるか */
  async assertCanReadEmployee(user: AuthUser, employeeId: string): Promise<void> {
    if (user.id === employeeId && hasPermission(user, 'attendance:read:self')) return;
    const target = await this.employeeDepartment(employeeId);
    if (target.companyId !== user.companyId) throw new ForbiddenException();
    if (hasPermission(user, 'attendance:read:company', 'employee:read:company')) return;
    if (hasPermission(user, 'attendance:read:department') && target.departmentId && user.managedDepartmentIds.includes(target.departmentId)) return;
    throw new ForbiddenException('この従業員の情報を閲覧する権限がありません');
  }

  /** 指定従業員の勤怠を修正できるか */
  async assertCanWriteAttendance(user: AuthUser, employeeId: string): Promise<void> {
    const target = await this.employeeDepartment(employeeId);
    if (target.companyId !== user.companyId) throw new ForbiddenException();
    if (hasPermission(user, 'attendance:write:company')) return;
    if (hasPermission(user, 'attendance:write:department') && target.departmentId && user.managedDepartmentIds.includes(target.departmentId)) return;
    throw new ForbiddenException('勤怠を修正する権限がありません');
  }

  /** 閲覧可能な従業員IDの集合を返す（null = 会社全体） */
  async readableEmployeeIds(user: AuthUser): Promise<string[] | null> {
    if (hasPermission(user, 'attendance:read:company', 'employee:read:company')) return null;
    const ids = new Set<string>([user.id]);
    if (hasPermission(user, 'attendance:read:department') && user.managedDepartmentIds.length > 0) {
      const rows = await this.db
        .select({ id: employees.id })
        .from(employees)
        .where(and(eq(employees.companyId, user.companyId), inArray(employees.departmentId, user.managedDepartmentIds)));
      rows.forEach((r) => ids.add(r.id));
    }
    return [...ids];
  }
}
