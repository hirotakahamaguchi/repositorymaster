import { Body, Controller, Delete, Get, HttpCode, Inject, Module, Param, Post, Query } from '@nestjs/common';
import { and, desc, eq } from 'drizzle-orm';
import { GrantLeaveSchema, type GrantLeaveInput, type LeaveBalanceDto, type LeaveType } from '@kintai/shared';
import { DB } from '../../db/db.module';
import type { Db } from '../../db/client';
import { employees, leaveGrants, leaveUsages } from '../../db/schema';
import { CurrentUser, RequirePermissions } from '../../common/decorators';
import { zodBody } from '../../common/zod.pipe';
import type { AuthUser } from '../../common/auth-user';
import { AuditService } from '../audit/audit.service';
import { AuditModule } from '../audit/audit.module';
import { AccessService } from '../auth/access.service';
import { RequestCore } from '../requests/core';
import { nowLocalDate } from '../../domain/time';

@Controller('leaves')
export class LeavesController {
  constructor(
    @Inject(DB) private readonly db: Db,
    private readonly audit: AuditService,
    private readonly access: AccessService,
  ) {}

  @Get('balances')
  async balances(@CurrentUser() user: AuthUser, @Query('employeeId') employeeId?: string): Promise<LeaveBalanceDto[]> {
    const target = employeeId ?? user.id;
    await this.access.assertCanReadEmployee(user, target);
    const rows = await new RequestCore(this.db).leaveBalances(target, nowLocalDate(user.timezone));
    return rows.map((r) => ({ ...r, leaveType: r.leaveType as LeaveType }));
  }

  @Get('grants')
  async grants(@CurrentUser() user: AuthUser, @Query('employeeId') employeeId?: string) {
    const target = employeeId ?? user.id;
    await this.access.assertCanReadEmployee(user, target);
    return this.db.select().from(leaveGrants).where(eq(leaveGrants.employeeId, target)).orderBy(desc(leaveGrants.grantedAt));
  }

  @Get('usages')
  async usages(@CurrentUser() user: AuthUser, @Query('employeeId') employeeId?: string) {
    const target = employeeId ?? user.id;
    await this.access.assertCanReadEmployee(user, target);
    return this.db.select().from(leaveUsages).where(eq(leaveUsages.employeeId, target)).orderBy(desc(leaveUsages.date));
  }

  @Post('grants')
  @RequirePermissions('employee:write:company')
  async grant(@CurrentUser() user: AuthUser, @Body(zodBody(GrantLeaveSchema)) body: GrantLeaveInput) {
    const [emp] = await this.db.select({ id: employees.id }).from(employees).where(and(eq(employees.id, body.employeeId), eq(employees.companyId, user.companyId)));
    if (!emp) throw new Error('employee not found');
    const [row] = await this.db
      .insert(leaveGrants)
      .values({ employeeId: body.employeeId, leaveType: body.leaveType, days: String(body.days), grantedAt: body.grantedAt, expiresAt: body.expiresAt, note: body.note ?? null, createdBy: user.id })
      .returning();
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'leave.granted', targetType: 'employee', targetId: body.employeeId, detail: body as unknown as Record<string, unknown> });
    return row;
  }

  @Delete('grants/:id')
  @RequirePermissions('employee:write:company')
  @HttpCode(204)
  async revoke(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    const [row] = await this.db.delete(leaveGrants).where(eq(leaveGrants.id, id)).returning();
    if (row) await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'leave.grant_revoked', targetType: 'employee', targetId: row.employeeId, detail: { grantId: id } });
  }
}

@Module({ imports: [AuditModule], controllers: [LeavesController] })
export class LeavesModule {}
