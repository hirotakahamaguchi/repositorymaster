import {
  BadRequestException,
  Body,
  Controller,
  ForbiddenException,
  Get,
  Inject,
  Injectable,
  Module,
  NotFoundException,
  Param,
  Post,
  Query,
} from '@nestjs/common';
import { and, desc, eq, inArray, or, sql } from 'drizzle-orm';
import {
  CreateRequestSchema,
  DecideRequestSchema,
  type ApprovalDecision,
  type CreateRequestInput,
  type DecideRequestInput,
  type Paginated,
  type RequestDto,
  type RequestStatus,
  type RequestType,
} from '@kintai/shared';
import { DB } from '../../db/db.module';
import type { Db } from '../../db/client';
import { departments, employees, requestApprovals, requests } from '../../db/schema';
import { CurrentUser, RequirePermissions } from '../../common/decorators';
import { zodBody } from '../../common/zod.pipe';
import { hasPermission, type AuthUser } from '../../common/auth-user';
import { AuditService } from '../audit/audit.service';
import { AuditModule } from '../audit/audit.module';
import { AccessService } from '../auth/access.service';
import { RequestCore } from './core';
import { AttendanceCore } from '../attendance/core';

@Injectable()
export class RequestsService {
  readonly core: RequestCore;
  constructor(
    @Inject(DB) private readonly db: Db,
    private readonly audit: AuditService,
  ) {
    this.core = new RequestCore(db);
  }

  private async hydrate(rows: (typeof requests.$inferSelect)[], user?: AuthUser): Promise<RequestDto[]> {
    if (rows.length === 0) return [];
    const ids = rows.map((r) => r.id);
    const empIds = [...new Set(rows.map((r) => r.employeeId))];
    const [emps, approvals] = await Promise.all([
      this.db
        .select({ id: employees.id, name: employees.name, code: employees.employeeCode, departmentName: departments.name, departmentId: employees.departmentId })
        .from(employees)
        .leftJoin(departments, eq(departments.id, employees.departmentId))
        .where(inArray(employees.id, empIds)),
      this.db
        .select({ a: requestApprovals, approverName: employees.name })
        .from(requestApprovals)
        .leftJoin(employees, eq(employees.id, requestApprovals.approverId))
        .where(inArray(requestApprovals.requestId, ids))
        .orderBy(requestApprovals.stepNo),
    ]);
    const empMap = new Map(emps.map((e) => [e.id, e]));
    return rows.map((r) => {
      const e = empMap.get(r.employeeId);
      const steps = approvals.filter((a) => a.a.requestId === r.id);
      const dto: RequestDto = {
        id: r.id,
        requestType: r.requestType as RequestType,
        employeeId: r.employeeId,
        employeeName: e?.name ?? '',
        employeeCode: e?.code ?? '',
        departmentName: e?.departmentName ?? null,
        payload: r.payload,
        reason: r.reason,
        status: r.status as RequestStatus,
        targetDateFrom: r.targetDateFrom,
        targetDateTo: r.targetDateTo,
        currentStep: r.currentStep,
        approvals: steps.map((s) => ({
          stepNo: s.a.stepNo,
          approverType: s.a.approverType,
          approverId: s.a.approverId,
          approverName: s.approverName,
          decision: s.a.decision as ApprovalDecision,
          comment: s.a.comment,
          decidedAt: s.a.decidedAt?.toISOString() ?? null,
        })),
        createdAt: r.createdAt.toISOString(),
        updatedAt: r.updatedAt.toISOString(),
      };
      if (user) dto.canDecide = this.canDecide(user, dto, e?.departmentId ?? null);
      return dto;
    });
  }

  /** 現在ステップの承認者か判定 */
  canDecide(user: AuthUser, req: RequestDto, employeeDepartmentId: string | null): boolean {
    if (req.status !== 'PENDING') return false;
    if (req.employeeId === user.id) return false;
    const step = req.approvals.find((a) => a.stepNo === req.currentStep);
    if (!step || step.decision !== 'PENDING') return false;
    switch (step.approverType) {
      case 'HR':
        // 労務ステップ: 会社承認権限者のみ
        return hasPermission(user, 'request:approve:company');
      case 'EMPLOYEE':
        return step.approverId === user.id || hasPermission(user, 'request:approve:company');
      case 'DEPARTMENT_MANAGER':
      default:
        if (step.approverId && step.approverId === user.id) return true;
        // 指名された管理者が不在/異動の場合: 管理部署の承認権限者 or 会社承認権限者が代理承認
        if (hasPermission(user, 'request:approve:company')) return true;
        if (hasPermission(user, 'request:approve:department') && employeeDepartmentId && user.managedDepartmentIds.includes(employeeDepartmentId)) return true;
        return false;
    }
  }

  async mine(user: AuthUser, opts: { page: number; pageSize: number; status?: string }): Promise<Paginated<RequestDto>> {
    const conds = [eq(requests.employeeId, user.id)];
    if (opts.status) conds.push(eq(requests.status, opts.status));
    const where = and(...conds);
    const [{ n }] = await this.db.select({ n: sql<number>`count(*)::int` }).from(requests).where(where);
    const rows = await this.db.select().from(requests).where(where).orderBy(desc(requests.createdAt)).limit(opts.pageSize).offset((opts.page - 1) * opts.pageSize);
    return { items: await this.hydrate(rows, user), total: Number(n), page: opts.page, pageSize: opts.pageSize };
  }

  /** 承認者向け: 自分が承認できる申請（+ 閲覧可能な部署/会社の申請） */
  async inbox(user: AuthUser, opts: { page: number; pageSize: number; status?: string; requestType?: string; onlyMine?: boolean }): Promise<Paginated<RequestDto>> {
    const conds = [eq(requests.companyId, user.companyId)];
    if (opts.status) conds.push(eq(requests.status, opts.status));
    if (opts.requestType) conds.push(eq(requests.requestType, opts.requestType));
    if (!hasPermission(user, 'request:approve:company')) {
      // 部署承認者: 管理部署の従業員 or 自分が承認者に指定された申請
      const deptCond = user.managedDepartmentIds.length
        ? sql`${requests.employeeId} in (select id from employees where department_id in ${user.managedDepartmentIds})`
        : sql`false`;
      const approverCond = sql`${requests.id} in (select request_id from request_approvals where approver_id = ${user.id})`;
      conds.push(or(deptCond, approverCond)!);
    }
    const where = and(...conds);
    const [{ n }] = await this.db.select({ n: sql<number>`count(*)::int` }).from(requests).where(where);
    const rows = await this.db.select().from(requests).where(where).orderBy(desc(requests.createdAt)).limit(opts.pageSize).offset((opts.page - 1) * opts.pageSize);
    let items = await this.hydrate(rows, user);
    if (opts.onlyMine) items = items.filter((i) => i.canDecide);
    return { items, total: Number(n), page: opts.page, pageSize: opts.pageSize };
  }

  async get(user: AuthUser, id: string): Promise<RequestDto> {
    const [row] = await this.db.select().from(requests).where(and(eq(requests.id, id), eq(requests.companyId, user.companyId)));
    if (!row) throw new NotFoundException('申請が見つかりません');
    const [dto] = await this.hydrate([row], user);
    return dto;
  }

  async create(user: AuthUser, input: CreateRequestInput): Promise<RequestDto> {
    // 締め済み期間への申請は不可
    const attendance = new AttendanceCore(this.db);
    const from = input.requestType === 'LEAVE' ? input.payload.dateFrom : input.payload.date;
    if (await attendance.isLocked(user.id, from)) throw new BadRequestException('締め済みの期間には申請できません');
    if (input.requestType === 'LEAVE') {
      if (input.payload.dateTo < input.payload.dateFrom) throw new BadRequestException('終了日は開始日以降にしてください');
      const balances = await this.core.leaveBalances(user.id, from);
      const b = balances.find((x) => x.leaveType === input.payload.leaveType);
      const need = input.payload.unit === 'FULL' ? (new Date(input.payload.dateTo).getTime() - new Date(input.payload.dateFrom).getTime()) / 86400_000 + 1 : 0.5;
      if (input.payload.leaveType !== 'UNPAID' && (!b || b.remainingDays < need)) throw new BadRequestException(`休暇残日数が不足しています（残 ${b?.remainingDays ?? 0} 日）`);
    }
    const created = await this.core.createRequest({ companyId: user.companyId, employeeId: user.id, input });
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'request.created', targetType: 'request', targetId: created.id, detail: { requestType: input.requestType } });
    return this.get(user, created.id);
  }

  async decide(user: AuthUser, id: string, input: DecideRequestInput): Promise<RequestDto> {
    const dto = await this.get(user, id);
    if (!dto.canDecide) throw new ForbiddenException('この申請を承認/却下する権限がありません');
    try {
      await this.core.decide({ requestId: id, approverId: user.id, decision: input.decision, comment: input.comment });
    } catch (e) {
      const msg = (e as Error).message;
      if (msg === 'REQUEST_NOT_PENDING') throw new BadRequestException('この申請は既に処理済みです');
      throw e;
    }
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: `request.${input.decision.toLowerCase()}`, targetType: 'request', targetId: id, detail: { comment: input.comment } });
    return this.get(user, id);
  }

  async withdraw(user: AuthUser, id: string): Promise<RequestDto> {
    const ok = await this.core.withdraw(id, user.id);
    if (!ok) throw new BadRequestException('取下げできるのは承認待ちの自分の申請のみです');
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'request.withdrawn', targetType: 'request', targetId: id });
    return this.get(user, id);
  }

  async pendingCountForApprover(user: AuthUser): Promise<number> {
    const r = await this.inbox(user, { page: 1, pageSize: 500, status: 'PENDING', onlyMine: true });
    return r.items.length;
  }
}

@Controller('requests')
export class RequestsController {
  constructor(
    private readonly svc: RequestsService,
    private readonly access: AccessService,
  ) {}

  @Get('mine')
  mine(@CurrentUser() user: AuthUser, @Query('page') page?: string, @Query('pageSize') pageSize?: string, @Query('status') status?: string) {
    return this.svc.mine(user, { page: Math.max(1, Number(page ?? 1)), pageSize: Math.min(200, Number(pageSize ?? 50)), status });
  }

  @Get('inbox')
  @RequirePermissions('request:approve:department', 'request:approve:company')
  inbox(
    @CurrentUser() user: AuthUser,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
    @Query('status') status?: string,
    @Query('requestType') requestType?: string,
    @Query('onlyMine') onlyMine?: string,
  ) {
    return this.svc.inbox(user, { page: Math.max(1, Number(page ?? 1)), pageSize: Math.min(200, Number(pageSize ?? 50)), status, requestType, onlyMine: onlyMine === 'true' });
  }

  @Get(':id')
  async get(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    const dto = await this.svc.get(user, id);
    if (dto.employeeId !== user.id) await this.access.assertCanReadEmployee(user, dto.employeeId);
    return dto;
  }

  @Post()
  @RequirePermissions('request:create:self')
  create(@CurrentUser() user: AuthUser, @Body(zodBody(CreateRequestSchema)) body: CreateRequestInput) {
    return this.svc.create(user, body);
  }

  @Post(':id/decide')
  @RequirePermissions('request:approve:department', 'request:approve:company')
  decide(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body(zodBody(DecideRequestSchema)) body: DecideRequestInput) {
    return this.svc.decide(user, id, body);
  }

  @Post(':id/withdraw')
  withdraw(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.svc.withdraw(user, id);
  }
}

@Module({
  imports: [AuditModule],
  providers: [RequestsService],
  controllers: [RequestsController],
  exports: [RequestsService],
})
export class RequestsModule {}
