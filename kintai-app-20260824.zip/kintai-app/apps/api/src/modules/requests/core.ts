/**
 * 申請ワークフローのコア（Nest 非依存）
 *  - 承認ルートの解決
 *  - 最終承認時の勤怠への反映（attendance_days.approvals / manual + revisions + leave_usages）
 */
import { and, eq, gte, lte, sql } from 'drizzle-orm';
import type { CreateRequestInput } from '@kintai/shared';
import type { Db } from '../../db/client';
import {
  approvalRoutes,
  attendanceDayRevisions,
  attendanceDays,
  departments,
  employees,
  leaveGrants,
  leaveUsages,
  requestApprovals,
  requests,
  type AttendanceApprovals,
  type AttendanceManual,
} from '../../db/schema';
import { AttendanceCore } from '../attendance/core';
import { eachDate } from '../../domain/time';

export type ApproverType = 'DEPARTMENT_MANAGER' | 'HR' | 'EMPLOYEE';
export interface RouteStep {
  stepNo: number;
  approverType: ApproverType;
  approverId?: string;
}

/** 申請種別ごとの既定ルート（DB の approval_routes が無い場合のフォールバック） */
export const DEFAULT_ROUTES: Record<string, RouteStep[]> = {
  CORRECTION: [
    { stepNo: 1, approverType: 'DEPARTMENT_MANAGER' },
    { stepNo: 2, approverType: 'HR' },
  ],
  OVERTIME: [{ stepNo: 1, approverType: 'DEPARTMENT_MANAGER' }],
  LEAVE: [
    { stepNo: 1, approverType: 'DEPARTMENT_MANAGER' },
    { stepNo: 2, approverType: 'HR' },
  ],
  HOLIDAY_WORK: [
    { stepNo: 1, approverType: 'DEPARTMENT_MANAGER' },
    { stepNo: 2, approverType: 'HR' },
  ],
  LATE_EARLY: [{ stepNo: 1, approverType: 'DEPARTMENT_MANAGER' }],
};

export function targetRange(input: CreateRequestInput): { from: string; to: string } {
  switch (input.requestType) {
    case 'LEAVE':
      return { from: input.payload.dateFrom, to: input.payload.dateTo };
    default:
      return { from: input.payload.date, to: input.payload.date };
  }
}

export class RequestCore {
  private readonly attendance: AttendanceCore;
  constructor(private readonly db: Db) {
    this.attendance = new AttendanceCore(db);
  }

  async resolveRoute(companyId: string, requestType: string): Promise<RouteStep[]> {
    const r = await this.db
      .select()
      .from(approvalRoutes)
      .where(and(eq(approvalRoutes.companyId, companyId), eq(approvalRoutes.requestType, requestType)))
      .limit(1);
    return (r[0]?.steps as RouteStep[] | undefined) ?? DEFAULT_ROUTES[requestType] ?? [{ stepNo: 1, approverType: 'HR' }];
  }

  /** 申請者の部署の管理者（申請者自身が管理者なら null） */
  async departmentManagerOf(employeeId: string): Promise<string | null> {
    const rows = await this.db
      .select({ managerId: departments.managerId })
      .from(employees)
      .leftJoin(departments, eq(departments.id, employees.departmentId))
      .where(eq(employees.id, employeeId))
      .limit(1);
    const m = rows[0]?.managerId ?? null;
    return m && m !== employeeId ? m : null;
  }

  /**
   * 申請を作成し、承認ステップ行を生成する。
   * DEPARTMENT_MANAGER ステップで承認者が解決できない（管理者本人の申請など）場合は SKIPPED。
   */
  async createRequest(params: {
    companyId: string;
    employeeId: string;
    input: CreateRequestInput;
    status?: 'PENDING' | 'APPROVED' | 'REJECTED';
    now?: Date;
  }) {
    const { companyId, employeeId, input } = params;
    const now = params.now ?? new Date();
    const { from, to } = targetRange(input);
    const route = await this.resolveRoute(companyId, input.requestType);
    const managerId = await this.departmentManagerOf(employeeId);

    return this.db.transaction(async (tx) => {
      const [req] = await tx
        .insert(requests)
        .values({
          companyId,
          employeeId,
          requestType: input.requestType,
          payload: input.payload as Record<string, unknown>,
          reason: input.reason,
          status: 'PENDING',
          targetDateFrom: from,
          targetDateTo: to,
          currentStep: 1,
          createdAt: now,
          updatedAt: now,
        })
        .returning();
      let firstActive = 0;
      const stepRows = route.map((s) => {
        const approverId = s.approverType === 'DEPARTMENT_MANAGER' ? managerId : s.approverType === 'EMPLOYEE' ? s.approverId ?? null : null;
        const skipped = s.approverType === 'DEPARTMENT_MANAGER' && !managerId;
        if (!skipped && firstActive === 0) firstActive = s.stepNo;
        return {
          requestId: req.id,
          stepNo: s.stepNo,
          approverType: s.approverType,
          approverId,
          decision: skipped ? 'SKIPPED' : 'PENDING',
          decidedAt: skipped ? now : null,
        };
      });
      await tx.insert(requestApprovals).values(stepRows);
      if (firstActive === 0) {
        // 全ステップがスキップ → 自動承認
        await tx.update(requests).set({ status: 'APPROVED', currentStep: route.length }).where(eq(requests.id, req.id));
        await this.applyApproved(req.id, null, now, tx as unknown as Db);
        return { ...req, status: 'APPROVED' };
      }
      if (firstActive !== 1) await tx.update(requests).set({ currentStep: firstActive }).where(eq(requests.id, req.id));
      return { ...req, currentStep: firstActive };
    });
  }

  /**
   * 承認/却下。最終ステップ承認時に勤怠へ反映する。
   */
  async decide(params: { requestId: string; approverId: string; decision: 'APPROVED' | 'REJECTED'; comment?: string; now?: Date }) {
    const now = params.now ?? new Date();
    return this.db.transaction(async (tx) => {
      const [req] = await tx.select().from(requests).where(eq(requests.id, params.requestId)).limit(1);
      if (!req) throw new Error('REQUEST_NOT_FOUND');
      if (req.status !== 'PENDING') throw new Error('REQUEST_NOT_PENDING');
      const steps = await tx.select().from(requestApprovals).where(eq(requestApprovals.requestId, req.id)).orderBy(requestApprovals.stepNo);
      const current = steps.find((s) => s.stepNo === req.currentStep);
      if (!current) throw new Error('STEP_NOT_FOUND');

      await tx
        .update(requestApprovals)
        .set({ decision: params.decision, approverId: params.approverId, comment: params.comment ?? null, decidedAt: now })
        .where(eq(requestApprovals.id, current.id));

      if (params.decision === 'REJECTED') {
        await tx.update(requests).set({ status: 'REJECTED', updatedAt: now }).where(eq(requests.id, req.id));
        return { status: 'REJECTED' as const };
      }
      // 次の有効ステップを探す
      const next = steps.find((s) => s.stepNo > req.currentStep && s.decision === 'PENDING');
      if (next) {
        await tx.update(requests).set({ currentStep: next.stepNo, updatedAt: now }).where(eq(requests.id, req.id));
        return { status: 'PENDING' as const, currentStep: next.stepNo };
      }
      await tx.update(requests).set({ status: 'APPROVED', updatedAt: now }).where(eq(requests.id, req.id));
      await this.applyApproved(req.id, params.approverId, now, tx as unknown as Db);
      return { status: 'APPROVED' as const };
    });
  }

  /** 承認済み申請を勤怠に反映 */
  async applyApproved(requestId: string, actorId: string | null, now: Date, db: Db = this.db) {
    const [req] = await db.select().from(requests).where(eq(requests.id, requestId)).limit(1);
    if (!req) return;
    const attendance = new AttendanceCore(db);
    const payload = req.payload as Record<string, unknown>;
    const dates = eachDate(req.targetDateFrom, req.targetDateTo);

    const upsertDay = async (
      date: string,
      mutate: (cur: { manual: AttendanceManual; approvals: AttendanceApprovals }) => { manual: AttendanceManual; approvals: AttendanceApprovals },
    ) => {
      const [ex] = await db
        .select()
        .from(attendanceDays)
        .where(and(eq(attendanceDays.employeeId, req.employeeId), eq(attendanceDays.workDate, date)))
        .limit(1);
      if (ex?.status === 'LOCKED') return; // 締め済みは反映しない（運用で締め解除→再承認）
      const cur = { manual: ex?.manual ?? {}, approvals: ex?.approvals ?? {} };
      const nextVal = mutate({ manual: { ...cur.manual }, approvals: { ...cur.approvals } });
      if (ex) {
        const version = ex.version + 1;
        await db
          .update(attendanceDays)
          .set({ manual: nextVal.manual, approvals: nextVal.approvals, version })
          .where(eq(attendanceDays.id, ex.id));
        await db.insert(attendanceDayRevisions).values({
          attendanceDayId: ex.id,
          version,
          before: { manual: cur.manual, approvals: cur.approvals },
          after: { manual: nextVal.manual, approvals: nextVal.approvals },
          reason: `申請承認 (${req.requestType}): ${req.reason}`,
          changedBy: actorId,
          requestId: req.id,
          changedAt: now,
        });
      } else {
        const [row] = await db
          .insert(attendanceDays)
          .values({ employeeId: req.employeeId, workDate: date, manual: nextVal.manual, approvals: nextVal.approvals, version: 1 })
          .returning();
        await db.insert(attendanceDayRevisions).values({
          attendanceDayId: row.id,
          version: 1,
          before: null,
          after: { manual: nextVal.manual, approvals: nextVal.approvals },
          reason: `申請承認 (${req.requestType}): ${req.reason}`,
          changedBy: actorId,
          requestId: req.id,
          changedAt: now,
        });
      }
    };

    switch (req.requestType) {
      case 'CORRECTION': {
        await upsertDay(req.targetDateFrom, (c) => {
          if (payload.clockInAt !== undefined) c.manual.clockInAt = payload.clockInAt as string | null;
          if (payload.clockOutAt !== undefined) c.manual.clockOutAt = payload.clockOutAt as string | null;
          if (payload.breakMinutes !== undefined) c.manual.breakMinutes = payload.breakMinutes as number;
          return c;
        });
        break;
      }
      case 'OVERTIME': {
        await upsertDay(req.targetDateFrom, (c) => {
          c.approvals.overtimeMinutes = Math.max(c.approvals.overtimeMinutes ?? 0, payload.plannedMinutes as number);
          return c;
        });
        break;
      }
      case 'LATE_EARLY': {
        await upsertDay(req.targetDateFrom, (c) => {
          if (payload.kind === 'LATE') c.approvals.late = true;
          else c.approvals.early = true;
          return c;
        });
        break;
      }
      case 'HOLIDAY_WORK': {
        await upsertDay(req.targetDateFrom, (c) => {
          c.approvals.holidayWork = true;
          return c;
        });
        if (payload.compensatory) {
          const [emp] = await db.select({ id: employees.id }).from(employees).where(eq(employees.id, req.employeeId));
          if (emp) {
            const exp = new Date(`${req.targetDateFrom}T00:00:00Z`);
            exp.setUTCMonth(exp.getUTCMonth() + 2);
            await db.insert(leaveGrants).values({
              employeeId: req.employeeId,
              leaveType: 'COMPENSATORY',
              days: '1',
              grantedAt: req.targetDateFrom,
              expiresAt: exp.toISOString().slice(0, 10),
              note: `休日出勤 ${req.targetDateFrom} の代休`,
              createdBy: actorId,
            });
          }
        }
        break;
      }
      case 'LEAVE': {
        const leaveType = payload.leaveType as string;
        const unit = (payload.unit as 'FULL' | 'AM' | 'PM') ?? 'FULL';
        for (const d of dates) {
          // 休日には消化させない（所定労働日のみ）
          await upsertDay(d, (c) => {
            c.approvals.leave = { type: leaveType, unit };
            return c;
          });
          await db
            .insert(leaveUsages)
            .values({ employeeId: req.employeeId, leaveType, date: d, days: unit === 'FULL' ? '1' : '0.5', requestId: req.id })
            .onConflictDoNothing();
        }
        break;
      }
    }
    await attendance.recalcEmployeeRange(req.employeeId, req.targetDateFrom, req.targetDateTo, now);
  }

  /** 取下げ（申請者本人、PENDING のみ） */
  async withdraw(requestId: string, employeeId: string, now = new Date()) {
    const r = await this.db
      .update(requests)
      .set({ status: 'WITHDRAWN', updatedAt: now })
      .where(and(eq(requests.id, requestId), eq(requests.employeeId, employeeId), eq(requests.status, 'PENDING')))
      .returning();
    return r.length > 0;
  }

  /** 休暇残日数（付与 − 消化、付与は失効日でフィルタ） */
  async leaveBalances(employeeId: string, asOf: string) {
    const grants = await this.db
      .select()
      .from(leaveGrants)
      .where(and(eq(leaveGrants.employeeId, employeeId), lte(leaveGrants.grantedAt, asOf), gte(leaveGrants.expiresAt, asOf)));
    const usages = await this.db
      .select({ leaveType: leaveUsages.leaveType, days: sql<string>`coalesce(sum(${leaveUsages.days}), 0)` })
      .from(leaveUsages)
      .where(eq(leaveUsages.employeeId, employeeId))
      .groupBy(leaveUsages.leaveType);
    const types = new Set([...grants.map((g) => g.leaveType), ...usages.map((u) => u.leaveType)]);
    return [...types].map((t) => {
      const granted = grants.filter((g) => g.leaveType === t).reduce((s, g) => s + Number(g.days), 0);
      const used = Number(usages.find((u) => u.leaveType === t)?.days ?? 0);
      const next = grants
        .filter((g) => g.leaveType === t && Number(g.days) > 0)
        .sort((a, b) => a.expiresAt.localeCompare(b.expiresAt))[0];
      return {
        leaveType: t,
        grantedDays: granted,
        usedDays: used,
        remainingDays: Math.max(0, granted - used),
        nextExpiry: next ? { days: Number(next.days), expiresAt: next.expiresAt } : null,
      };
    });
  }
}
