import { Inject, Injectable, Logger, Module } from '@nestjs/common';
import { Cron, CronExpression, ScheduleModule } from '@nestjs/schedule';
import { DB } from '../../db/db.module';
import type { Db } from '../../db/client';
import { ensurePunchPartitions } from '../../db/migrate';
import { AttendanceCore } from '../attendance/core';
import { companies } from '../../db/schema';
import { addDays, nowLocalDate } from '../../domain/time';

/**
 * 定期ジョブ（本番では EventBridge + Lambda / ECS Scheduled Task に置き換え可能）
 *  - 毎日 深夜: 前日分の再計算（退勤漏れフラグ確定など）
 *  - 毎月 1日: 打刻テーブルのパーティション作成
 */
@Injectable()
export class JobsService {
  private readonly logger = new Logger('Jobs');
  constructor(@Inject(DB) private readonly db: Db) {}

  @Cron('0 30 5 * * *', { timeZone: 'Asia/Tokyo' })
  async nightlyRecalc() {
    const core = new AttendanceCore(this.db);
    const cs = await this.db.select({ id: companies.id, timezone: companies.timezone }).from(companies);
    for (const c of cs) {
      const today = nowLocalDate(c.timezone);
      const n = await core.recalcCompanyRange(c.id, addDays(today, -2), today);
      this.logger.log(`nightly recalc company=${c.id} rows=${n}`);
    }
  }

  @Cron(CronExpression.EVERY_1ST_DAY_OF_MONTH_AT_MIDNIGHT)
  async monthlyPartitions() {
    await ensurePunchPartitions(this.db, (m) => this.logger.log(m), { pastMonths: 1, futureMonths: 12 });
  }
}

@Module({
  imports: [ScheduleModule.forRoot()],
  providers: [JobsService],
})
export class JobsModule {}
