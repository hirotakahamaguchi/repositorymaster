import { Body, Controller, Delete, Get, HttpCode, Inject, Module, NotFoundException, Param, Post, Put, Query } from '@nestjs/common';
import { and, asc, desc, eq, sql } from 'drizzle-orm';
import {
  AssignWorkPatternSchema,
  UpsertWorkPatternSchema,
  WorkPatternRulesSchema,
  type AssignWorkPatternInput,
  type UpsertWorkPatternInput,
  type WorkPatternAssignmentDto,
  type WorkPatternDto,
  type WorkPatternType,
} from '@kintai/shared';
import { DB } from '../../db/db.module';
import type { Db } from '../../db/client';
import { employeeWorkPatternAssignments, workPatterns } from '../../db/schema';
import { CurrentUser, RequirePermissions } from '../../common/decorators';
import { zodBody } from '../../common/zod.pipe';
import type { AuthUser } from '../../common/auth-user';
import { AuditService } from '../audit/audit.service';
import { AuditModule } from '../audit/audit.module';
import { AccessService } from '../auth/access.service';
import { AttendanceCore } from '../attendance/core';
import { addDays, nowLocalDate } from '../../domain/time';

@Controller('work-patterns')
export class WorkPatternsController {
  constructor(
    @Inject(DB) private readonly db: Db,
    private readonly audit: AuditService,
    private readonly access: AccessService,
  ) {}

  private toDto(r: typeof workPatterns.$inferSelect, assignedCount = 0): WorkPatternDto {
    return {
      id: r.id,
      code: r.code,
      name: r.name,
      patternType: r.patternType as WorkPatternType,
      rules: WorkPatternRulesSchema.parse(r.rules),
      validFrom: r.validFrom,
      validTo: r.validTo,
      assignedCount,
    };
  }

  @Get()
  async list(@CurrentUser() user: AuthUser): Promise<WorkPatternDto[]> {
    const today = nowLocalDate(user.timezone);
    const rows = await this.db.select().from(workPatterns).where(eq(workPatterns.companyId, user.companyId)).orderBy(asc(workPatterns.code));
    const counts = await this.db
      .select({ id: employeeWorkPatternAssignments.workPatternId, n: sql<number>`count(*)::int` })
      .from(employeeWorkPatternAssignments)
      .where(and(sql`${employeeWorkPatternAssignments.validFrom} <= ${today}`, sql`(${employeeWorkPatternAssignments.validTo} is null or ${employeeWorkPatternAssignments.validTo} >= ${today})`))
      .groupBy(employeeWorkPatternAssignments.workPatternId);
    const cmap = new Map(counts.map((c) => [c.id, Number(c.n)]));
    return rows.map((r) => this.toDto(r, cmap.get(r.id) ?? 0));
  }

  @Post()
  @RequirePermissions('master:write:company')
  async create(@CurrentUser() user: AuthUser, @Body(zodBody(UpsertWorkPatternSchema)) body: UpsertWorkPatternInput): Promise<WorkPatternDto> {
    const [row] = await this.db
      .insert(workPatterns)
      .values({ companyId: user.companyId, code: body.code, name: body.name, patternType: body.patternType, rules: body.rules, validFrom: body.validFrom, validTo: body.validTo ?? null })
      .returning();
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'work_pattern.created', targetType: 'work_pattern', targetId: row.id, detail: body as unknown as Record<string, unknown> });
    return this.toDto(row);
  }

  @Put(':id')
  @RequirePermissions('master:write:company')
  async update(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body(zodBody(UpsertWorkPatternSchema)) body: UpsertWorkPatternInput): Promise<WorkPatternDto> {
    const [before] = await this.db.select().from(workPatterns).where(and(eq(workPatterns.id, id), eq(workPatterns.companyId, user.companyId)));
    if (!before) throw new NotFoundException();
    const [row] = await this.db
      .update(workPatterns)
      .set({ code: body.code, name: body.name, patternType: body.patternType, rules: body.rules, validFrom: body.validFrom, validTo: body.validTo ?? null })
      .where(eq(workPatterns.id, id))
      .returning();
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'work_pattern.updated', targetType: 'work_pattern', targetId: id, detail: { before: before.rules, after: body.rules } });
    // ルール変更は未締めの当月以降を再計算（非同期。本番では SQS/ジョブキューへ）
    const today = nowLocalDate(user.timezone);
    const from = `${today.slice(0, 7)}-01`;
    void new AttendanceCore(this.db).recalcCompanyRange(user.companyId, addDays(from, -31), today).catch(() => undefined);
    return this.toDto(row);
  }

  @Delete(':id')
  @RequirePermissions('master:write:company')
  @HttpCode(204)
  async remove(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    await this.db.delete(workPatterns).where(and(eq(workPatterns.id, id), eq(workPatterns.companyId, user.companyId)));
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'work_pattern.deleted', targetType: 'work_pattern', targetId: id });
  }

  // ── 割当 ───────────────────────────────────────────────
  @Get('assignments')
  async assignments(@CurrentUser() user: AuthUser, @Query('employeeId') employeeId: string): Promise<WorkPatternAssignmentDto[]> {
    await this.access.assertCanReadEmployee(user, employeeId);
    const rows = await this.db
      .select({
        id: employeeWorkPatternAssignments.id,
        employeeId: employeeWorkPatternAssignments.employeeId,
        workPatternId: employeeWorkPatternAssignments.workPatternId,
        workPatternName: workPatterns.name,
        validFrom: employeeWorkPatternAssignments.validFrom,
        validTo: employeeWorkPatternAssignments.validTo,
      })
      .from(employeeWorkPatternAssignments)
      .innerJoin(workPatterns, eq(workPatterns.id, employeeWorkPatternAssignments.workPatternId))
      .where(eq(employeeWorkPatternAssignments.employeeId, employeeId))
      .orderBy(desc(employeeWorkPatternAssignments.validFrom));
    return rows;
  }

  @Post('assignments')
  @RequirePermissions('employee:write:company')
  async assign(@CurrentUser() user: AuthUser, @Body(zodBody(AssignWorkPatternSchema)) body: AssignWorkPatternInput): Promise<WorkPatternAssignmentDto[]> {
    // 重なる既存割当を validFrom 前日で終了（期間重複は DB の EXCLUDE 制約でも防止）
    const prevDay = addDays(body.validFrom, -1);
    await this.db
      .update(employeeWorkPatternAssignments)
      .set({ validTo: prevDay })
      .where(
        and(
          eq(employeeWorkPatternAssignments.employeeId, body.employeeId),
          sql`${employeeWorkPatternAssignments.validFrom} < ${body.validFrom}`,
          sql`(${employeeWorkPatternAssignments.validTo} is null or ${employeeWorkPatternAssignments.validTo} >= ${body.validFrom})`,
        ),
      );
    await this.db
      .delete(employeeWorkPatternAssignments)
      .where(and(eq(employeeWorkPatternAssignments.employeeId, body.employeeId), sql`${employeeWorkPatternAssignments.validFrom} >= ${body.validFrom}`));
    await this.db.insert(employeeWorkPatternAssignments).values({ employeeId: body.employeeId, workPatternId: body.workPatternId, validFrom: body.validFrom, validTo: body.validTo ?? null });
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'work_pattern.assigned', targetType: 'employee', targetId: body.employeeId, detail: body as unknown as Record<string, unknown> });
    const today = nowLocalDate(user.timezone);
    if (body.validFrom <= today) await new AttendanceCore(this.db).recalcEmployeeRange(body.employeeId, body.validFrom, today);
    return this.assignments(user, body.employeeId);
  }

  @Delete('assignments/:id')
  @RequirePermissions('employee:write:company')
  @HttpCode(204)
  async unassign(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    await this.db.delete(employeeWorkPatternAssignments).where(eq(employeeWorkPatternAssignments.id, id));
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'work_pattern.unassigned', targetType: 'assignment', targetId: id });
  }
}

@Module({ imports: [AuditModule], controllers: [WorkPatternsController] })
export class WorkPatternsModule {}
