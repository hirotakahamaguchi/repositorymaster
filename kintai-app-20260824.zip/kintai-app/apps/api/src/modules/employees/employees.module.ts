import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  Inject,
  Injectable,
  Module,
  NotFoundException,
  Param,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import * as bcrypt from 'bcryptjs';
import { and, asc, desc, eq, inArray, isNull, or, sql } from 'drizzle-orm';
import {
  UpsertDepartmentSchema,
  UpsertEmployeeSchema,
  type DepartmentDto,
  type EmployeeDto,
  type Paginated,
  type RoleCode,
  type UpsertDepartmentInput,
  type UpsertEmployeeInput,
} from '@kintai/shared';
import { DB } from '../../db/db.module';
import type { Db } from '../../db/client';
import { departments, employeeRoles, employees, employeeWorkPatternAssignments, roles, workPatterns } from '../../db/schema';
import { CurrentUser, RequirePermissions } from '../../common/decorators';
import { zodBody } from '../../common/zod.pipe';
import { hasPermission, type AuthUser } from '../../common/auth-user';
import { AuditService } from '../audit/audit.service';
import { AuditModule } from '../audit/audit.module';
import { AccessService } from '../auth/access.service';

@Injectable()
export class EmployeesService {
  constructor(
    @Inject(DB) private readonly db: Db,
    private readonly audit: AuditService,
  ) {}

  private async rolesOf(employeeIds: string[]): Promise<Map<string, RoleCode[]>> {
    if (employeeIds.length === 0) return new Map();
    const today = new Date().toISOString().slice(0, 10);
    const rows = await this.db
      .select({ employeeId: employeeRoles.employeeId, code: roles.code })
      .from(employeeRoles)
      .innerJoin(roles, eq(roles.id, employeeRoles.roleId))
      .where(and(inArray(employeeRoles.employeeId, employeeIds), sql`(${employeeRoles.validTo} is null or ${employeeRoles.validTo} >= ${today})`));
    const m = new Map<string, RoleCode[]>();
    for (const r of rows) {
      if (!m.has(r.employeeId)) m.set(r.employeeId, []);
      m.get(r.employeeId)!.push(r.code as RoleCode);
    }
    return m;
  }

  private async currentPatterns(employeeIds: string[]): Promise<Map<string, { id: string; code: string; name: string }>> {
    if (employeeIds.length === 0) return new Map();
    const today = new Date().toISOString().slice(0, 10);
    const rows = await this.db
      .select({ employeeId: employeeWorkPatternAssignments.employeeId, id: workPatterns.id, code: workPatterns.code, name: workPatterns.name })
      .from(employeeWorkPatternAssignments)
      .innerJoin(workPatterns, eq(workPatterns.id, employeeWorkPatternAssignments.workPatternId))
      .where(
        and(
          inArray(employeeWorkPatternAssignments.employeeId, employeeIds),
          sql`${employeeWorkPatternAssignments.validFrom} <= ${today}`,
          sql`(${employeeWorkPatternAssignments.validTo} is null or ${employeeWorkPatternAssignments.validTo} >= ${today})`,
        ),
      );
    return new Map(rows.map((r) => [r.employeeId, { id: r.id, code: r.code, name: r.name }]));
  }

  async list(
    companyId: string,
    opts: { page: number; pageSize: number; q?: string; departmentId?: string; includeRetired?: boolean; onlyIds?: string[] | null },
  ): Promise<Paginated<EmployeeDto>> {
    const today = new Date().toISOString().slice(0, 10);
    const conds = [eq(employees.companyId, companyId)];
    if (!opts.includeRetired) conds.push(or(isNull(employees.retiredAt), sql`${employees.retiredAt} >= ${today}`)!);
    if (opts.departmentId) conds.push(eq(employees.departmentId, opts.departmentId));
    if (opts.q) {
      const q = `%${opts.q}%`;
      conds.push(or(sql`${employees.name} ilike ${q}`, sql`${employees.employeeCode} ilike ${q}`, sql`${employees.email} ilike ${q}`, sql`${employees.nameKana} ilike ${q}`)!);
    }
    if (opts.onlyIds) {
      if (opts.onlyIds.length === 0) return { items: [], total: 0, page: opts.page, pageSize: opts.pageSize };
      conds.push(inArray(employees.id, opts.onlyIds));
    }
    const where = and(...conds);
    const [{ n }] = await this.db.select({ n: sql<number>`count(*)::int` }).from(employees).where(where);
    const rows = await this.db
      .select({
        id: employees.id,
        employeeCode: employees.employeeCode,
        name: employees.name,
        nameKana: employees.nameKana,
        email: employees.email,
        departmentId: employees.departmentId,
        departmentName: departments.name,
        hiredAt: employees.hiredAt,
        retiredAt: employees.retiredAt,
      })
      .from(employees)
      .leftJoin(departments, eq(departments.id, employees.departmentId))
      .where(where)
      .orderBy(asc(employees.employeeCode))
      .limit(opts.pageSize)
      .offset((opts.page - 1) * opts.pageSize);
    const ids = rows.map((r) => r.id);
    const [roleMap, patMap] = await Promise.all([this.rolesOf(ids), this.currentPatterns(ids)]);
    return {
      items: rows.map((r) => ({ ...r, roles: roleMap.get(r.id) ?? [], currentWorkPattern: patMap.get(r.id) ?? null })),
      total: Number(n),
      page: opts.page,
      pageSize: opts.pageSize,
    };
  }

  async get(companyId: string, id: string): Promise<EmployeeDto> {
    const r = await this.list(companyId, { page: 1, pageSize: 1, onlyIds: [id], includeRetired: true });
    if (!r.items[0]) throw new NotFoundException('従業員が見つかりません');
    return r.items[0];
  }

  async create(user: AuthUser, input: UpsertEmployeeInput): Promise<EmployeeDto> {
    const passwordHash = await bcrypt.hash(input.password ?? Math.random().toString(36).slice(2) + 'Aa1!', 10);
    const [row] = await this.db
      .insert(employees)
      .values({
        companyId: user.companyId,
        employeeCode: input.employeeCode,
        name: input.name,
        nameKana: input.nameKana ?? null,
        email: input.email.toLowerCase(),
        passwordHash,
        departmentId: input.departmentId ?? null,
        hiredAt: input.hiredAt,
        retiredAt: input.retiredAt ?? null,
      })
      .returning();
    await this.setRoles(user.companyId, row.id, input.roleCodes, input.hiredAt);
    if (input.workPatternId) {
      await this.db.insert(employeeWorkPatternAssignments).values({ employeeId: row.id, workPatternId: input.workPatternId, validFrom: input.hiredAt });
    }
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'employee.created', targetType: 'employee', targetId: row.id, detail: { employeeCode: input.employeeCode } });
    return this.get(user.companyId, row.id);
  }

  async update(user: AuthUser, id: string, input: UpsertEmployeeInput): Promise<EmployeeDto> {
    const existing = await this.get(user.companyId, id);
    const set: Partial<typeof employees.$inferInsert> = {
      employeeCode: input.employeeCode,
      name: input.name,
      nameKana: input.nameKana ?? null,
      email: input.email.toLowerCase(),
      departmentId: input.departmentId ?? null,
      hiredAt: input.hiredAt,
      retiredAt: input.retiredAt ?? null,
    };
    if (input.password) set.passwordHash = await bcrypt.hash(input.password, 10);
    await this.db.update(employees).set(set).where(and(eq(employees.id, id), eq(employees.companyId, user.companyId)));
    await this.setRoles(user.companyId, id, input.roleCodes, input.hiredAt);
    if (input.workPatternId && input.workPatternId !== existing.currentWorkPattern?.id) {
      const today = new Date().toISOString().slice(0, 10);
      const yesterday = new Date(Date.now() - 86400_000).toISOString().slice(0, 10);
      // 現在有効な割当を昨日で終了し、今日から新パターン
      await this.db
        .update(employeeWorkPatternAssignments)
        .set({ validTo: yesterday })
        .where(and(eq(employeeWorkPatternAssignments.employeeId, id), isNull(employeeWorkPatternAssignments.validTo), sql`${employeeWorkPatternAssignments.validFrom} < ${today}`));
      await this.db
        .delete(employeeWorkPatternAssignments)
        .where(and(eq(employeeWorkPatternAssignments.employeeId, id), sql`${employeeWorkPatternAssignments.validFrom} >= ${today}`));
      await this.db.insert(employeeWorkPatternAssignments).values({ employeeId: id, workPatternId: input.workPatternId, validFrom: today });
    }
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'employee.updated', targetType: 'employee', targetId: id, detail: { before: existing, after: input } });
    return this.get(user.companyId, id);
  }

  private async setRoles(companyId: string, employeeId: string, codes: RoleCode[], validFrom: string) {
    const roleRows = await this.db.select().from(roles).where(and(eq(roles.companyId, companyId), inArray(roles.code, codes)));
    const [emp] = await this.db.select({ departmentId: employees.departmentId }).from(employees).where(eq(employees.id, employeeId));
    await this.db.delete(employeeRoles).where(eq(employeeRoles.employeeId, employeeId));
    if (roleRows.length === 0) return;
    await this.db.insert(employeeRoles).values(
      roleRows.map((r) => ({
        employeeId,
        roleId: r.id,
        scopeType: r.code === 'MANAGER' ? 'DEPARTMENT' : 'COMPANY',
        scopeId: r.code === 'MANAGER' ? emp?.departmentId ?? null : null,
        validFrom,
      })),
    );
  }

  // ── 部署 ───────────────────────────────────────────────
  async listDepartments(companyId: string): Promise<DepartmentDto[]> {
    const rows = await this.db
      .select({
        id: departments.id,
        code: departments.code,
        name: departments.name,
        parentId: departments.parentId,
        managerId: departments.managerId,
        managerName: employees.name,
      })
      .from(departments)
      .leftJoin(employees, eq(employees.id, departments.managerId))
      .where(eq(departments.companyId, companyId))
      .orderBy(asc(departments.code));
    const counts = await this.db
      .select({ departmentId: employees.departmentId, n: sql<number>`count(*)::int` })
      .from(employees)
      .where(and(eq(employees.companyId, companyId), isNull(employees.retiredAt)))
      .groupBy(employees.departmentId);
    const cmap = new Map(counts.map((c) => [c.departmentId, Number(c.n)]));
    return rows.map((r) => ({ ...r, headcount: cmap.get(r.id) ?? 0 }));
  }

  async upsertDepartment(user: AuthUser, input: UpsertDepartmentInput, id?: string): Promise<DepartmentDto> {
    if (id) {
      await this.db
        .update(departments)
        .set({ code: input.code, name: input.name, parentId: input.parentId ?? null, managerId: input.managerId ?? null })
        .where(and(eq(departments.id, id), eq(departments.companyId, user.companyId)));
    } else {
      const [row] = await this.db
        .insert(departments)
        .values({ companyId: user.companyId, code: input.code, name: input.name, parentId: input.parentId ?? null, managerId: input.managerId ?? null })
        .returning();
      id = row.id;
    }
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'department.upserted', targetType: 'department', targetId: id, detail: input as Record<string, unknown> });
    const all = await this.listDepartments(user.companyId);
    return all.find((d) => d.id === id)!;
  }

  async deleteDepartment(user: AuthUser, id: string) {
    const [{ n }] = await this.db.select({ n: sql<number>`count(*)::int` }).from(employees).where(eq(employees.departmentId, id));
    if (Number(n) > 0) throw new BadRequestException('所属する従業員がいる部署は削除できません');
    await this.db.delete(departments).where(and(eq(departments.id, id), eq(departments.companyId, user.companyId)));
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'department.deleted', targetType: 'department', targetId: id });
  }

  async listRoles(companyId: string) {
    return this.db.select().from(roles).where(eq(roles.companyId, companyId)).orderBy(desc(roles.code));
  }
}

@Controller()
export class EmployeesController {
  constructor(
    private readonly svc: EmployeesService,
    private readonly access: AccessService,
  ) {}

  @Get('employees')
  async list(
    @CurrentUser() user: AuthUser,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
    @Query('q') q?: string,
    @Query('departmentId') departmentId?: string,
    @Query('includeRetired') includeRetired?: string,
  ) {
    // 会社全体の閲覧権限が無い場合は自分＋管理部署のみ
    const onlyIds = hasPermission(user, 'employee:read:company', 'attendance:read:company') ? null : await this.access.readableEmployeeIds(user);
    return this.svc.list(user.companyId, {
      page: Math.max(1, Number(page ?? 1)),
      pageSize: Math.min(500, Math.max(1, Number(pageSize ?? 50))),
      q,
      departmentId,
      includeRetired: includeRetired === 'true',
      onlyIds,
    });
  }

  @Get('employees/:id')
  async get(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    await this.access.assertCanReadEmployee(user, id);
    return this.svc.get(user.companyId, id);
  }

  @Post('employees')
  @RequirePermissions('employee:write:company')
  create(@CurrentUser() user: AuthUser, @Body(zodBody(UpsertEmployeeSchema)) body: UpsertEmployeeInput) {
    return this.svc.create(user, body);
  }

  @Put('employees/:id')
  @RequirePermissions('employee:write:company')
  update(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body(zodBody(UpsertEmployeeSchema)) body: UpsertEmployeeInput) {
    return this.svc.update(user, id, body);
  }

  @Get('departments')
  departments(@CurrentUser() user: AuthUser) {
    return this.svc.listDepartments(user.companyId);
  }

  @Post('departments')
  @RequirePermissions('master:write:company')
  createDepartment(@CurrentUser() user: AuthUser, @Body(zodBody(UpsertDepartmentSchema)) body: UpsertDepartmentInput) {
    return this.svc.upsertDepartment(user, body);
  }

  @Put('departments/:id')
  @RequirePermissions('master:write:company')
  updateDepartment(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body(zodBody(UpsertDepartmentSchema)) body: UpsertDepartmentInput) {
    return this.svc.upsertDepartment(user, body, id);
  }

  @Delete('departments/:id')
  @RequirePermissions('master:write:company')
  @HttpCode(204)
  deleteDepartment(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.svc.deleteDepartment(user, id);
  }

  @Get('roles')
  roles(@CurrentUser() user: AuthUser) {
    return this.svc.listRoles(user.companyId);
  }
}

@Module({
  imports: [AuditModule],
  providers: [EmployeesService],
  controllers: [EmployeesController],
  exports: [EmployeesService],
})
export class EmployeesModule {}
