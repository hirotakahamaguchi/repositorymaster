import { BadRequestException, Body, Controller, ForbiddenException, Get, Inject, Injectable, Module, Post, Query } from '@nestjs/common';
import { EventEmitter2, EventEmitterModule, OnEvent } from '@nestjs/event-emitter';
import { and, asc, desc, eq, gte, lte } from 'drizzle-orm';
import { CreatePunchSchema, haversineMeters, type CreatePunchInput, type PunchDto, type PunchType, type PunchSource } from '@kintai/shared';
import { DB } from '../../db/db.module';
import type { Db } from '../../db/client';
import { timePunches } from '../../db/schema';
import { CurrentUser, RequirePermissions, ClientIp } from '../../common/decorators';
import { zodBody } from '../../common/zod.pipe';
import { hasPermission, type AuthUser } from '../../common/auth-user';
import { AuditService } from '../audit/audit.service';
import { AuditModule } from '../audit/audit.module';
import { AccessService } from '../auth/access.service';
import { AttendanceCore } from '../attendance/core';
import { addDays, workDateOf } from '../../domain/time';
import { Logger } from '@nestjs/common';

export const PUNCH_CREATED = 'punch.created';
export interface PunchCreatedEvent {
  employeeId: string;
  workDate: string;
  timezone: string;
}

export function toPunchDto(r: typeof timePunches.$inferSelect): PunchDto {
  return {
    id: String(r.id),
    employeeId: r.employeeId,
    punchType: r.punchType as PunchType,
    punchedAt: r.punchedAt.toISOString(),
    receivedAt: r.receivedAt.toISOString(),
    source: r.source as PunchSource,
    latitude: r.latitude != null ? Number(r.latitude) : null,
    longitude: r.longitude != null ? Number(r.longitude) : null,
    accuracyM: r.accuracyM != null ? Number(r.accuracyM) : null,
    geofenceOk: r.geofenceOk,
    clockDriftSec: r.clockDriftSec,
  };
}

@Injectable()
export class PunchesService {
  private readonly logger = new Logger('Punches');
  constructor(
    @Inject(DB) private readonly db: Db,
    private readonly events: EventEmitter2,
    private readonly audit: AuditService,
  ) {}

  /**
   * 打刻登録（追記専用）
   *  - 冪等キー (clientRequestId) で二重送信を吸収
   *  - 端末時刻とサーバ時刻の乖離を記録（改ざん・時計ずれ検知）
   *  - ジオフェンス判定は「記録」のみ。打刻自体は拒否しない（現場を止めない）
   */
  async create(user: AuthUser, input: CreatePunchInput, ip: string | null): Promise<{ punch: PunchDto; duplicate: boolean }> {
    const employeeId = input.employeeId ?? user.id;
    const isProxy = employeeId !== user.id;
    if (isProxy && !hasPermission(user, 'punch:create:admin')) throw new ForbiddenException('代理打刻の権限がありません');

    const now = new Date();
    const punchedAt = input.punchedAt ? new Date(input.punchedAt) : now;
    const driftSec = Math.round((now.getTime() - punchedAt.getTime()) / 1000);
    // 未来時刻や 24h 以上前の打刻は拒否（オフライン再送は 24h 以内を想定）
    if (driftSec < -300) throw new BadRequestException('端末の時刻が進んでいます。時刻設定を確認してください');
    if (driftSec > 24 * 3600 && !isProxy) throw new BadRequestException('24時間以上前の打刻は登録できません。打刻修正申請をご利用ください');

    // 冪等: 同じ clientRequestId があればそれを返す
    const dup = await this.db.select().from(timePunches).where(eq(timePunches.clientRequestId, input.clientRequestId)).limit(1);
    if (dup[0]) return { punch: toPunchDto(dup[0]), duplicate: true };

    // 直前の打刻との整合（IN の連続など）は警告扱いにし、登録は通す
    let geofenceOk: boolean | null = null;
    const s = user.settings;
    if (input.latitude != null && input.longitude != null && s.officeLatitude != null && s.officeLongitude != null) {
      const dist = haversineMeters(input.latitude, input.longitude, s.officeLatitude, s.officeLongitude);
      geofenceOk = dist <= s.geofenceRadiusM + (input.accuracyM ?? 0);
    }

    const [row] = await this.db
      .insert(timePunches)
      .values({
        employeeId,
        punchType: input.punchType,
        punchedAt,
        receivedAt: now,
        source: isProxy ? 'ADMIN' : input.source,
        latitude: input.latitude != null ? String(input.latitude) : null,
        longitude: input.longitude != null ? String(input.longitude) : null,
        accuracyM: input.accuracyM != null ? String(input.accuracyM) : null,
        geofenceOk,
        clockDriftSec: driftSec,
        deviceInfo: input.deviceInfo ?? null,
        clientRequestId: input.clientRequestId,
        createdBy: user.id,
      })
      .returning();

    const workDate = workDateOf(punchedAt, user.timezone);
    this.events.emit(PUNCH_CREATED, { employeeId, workDate, timezone: user.timezone } satisfies PunchCreatedEvent);
    if (isProxy) {
      await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'punch.proxy_created', targetType: 'employee', targetId: employeeId, detail: { punchType: input.punchType, punchedAt: punchedAt.toISOString() }, ip });
    }
    return { punch: toPunchDto(row), duplicate: false };
  }

  async listForEmployee(employeeId: string, from: Date, to: Date): Promise<PunchDto[]> {
    const rows = await this.db
      .select()
      .from(timePunches)
      .where(and(eq(timePunches.employeeId, employeeId), gte(timePunches.punchedAt, from), lte(timePunches.punchedAt, to)))
      .orderBy(asc(timePunches.punchedAt));
    return rows.map(toPunchDto);
  }

  async last(employeeId: string): Promise<PunchDto | null> {
    const rows = await this.db.select().from(timePunches).where(eq(timePunches.employeeId, employeeId)).orderBy(desc(timePunches.punchedAt)).limit(1);
    return rows[0] ? toPunchDto(rows[0]) : null;
  }

  /** 打刻イベント → 当日の勤怠再計算（本番では SQS + ワーカーに置き換え可能） */
  @OnEvent(PUNCH_CREATED, { async: true })
  async onPunchCreated(e: PunchCreatedEvent) {
    try {
      const core = new AttendanceCore(this.db);
      // 日跨ぎを考慮して前日〜当日を再計算
      await core.recalcEmployeeRange(e.employeeId, addDays(e.workDate, -1), e.workDate);
    } catch (err) {
      this.logger.error(`recalc failed for ${e.employeeId} ${e.workDate}: ${(err as Error).message}`);
    }
  }
}

@Controller('punches')
export class PunchesController {
  constructor(
    private readonly svc: PunchesService,
    private readonly access: AccessService,
  ) {}

  @Post()
  @RequirePermissions('punch:create:self', 'punch:create:admin')
  create(@CurrentUser() user: AuthUser, @Body(zodBody(CreatePunchSchema)) body: CreatePunchInput, @ClientIp() ip: string | null) {
    return this.svc.create(user, body, ip);
  }

  @Get()
  async list(
    @CurrentUser() user: AuthUser,
    @Query('employeeId') employeeId?: string,
    @Query('from') from?: string,
    @Query('to') to?: string,
  ): Promise<PunchDto[]> {
    const target = employeeId ?? user.id;
    await this.access.assertCanReadEmployee(user, target);
    const f = from ? new Date(from) : new Date(Date.now() - 7 * 86400_000);
    const t = to ? new Date(to) : new Date(Date.now() + 86400_000);
    return this.svc.listForEmployee(target, f, t);
  }
}

@Module({
  imports: [EventEmitterModule.forRoot(), AuditModule],
  providers: [PunchesService],
  controllers: [PunchesController],
  exports: [PunchesService],
})
export class PunchesModule {}
