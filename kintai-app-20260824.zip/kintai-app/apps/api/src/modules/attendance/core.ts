/**
 * 勤怠の再計算・集計コア（Nest 非依存。seed / ジョブ / サービスから共用）
 */
import { and, asc, eq, gte, inArray, lte, sql } from 'drizzle-orm';
import {
  CompanySettingsSchema,
  WorkPatternRulesSchema,
  type CompanySettings,
  type WorkPatternRules,
  type WorkPatternType,
  type AttendanceMonthSummary,
  type PunchType,
  type DayType,
} from '@kintai/shared';
import type { Db } from '../../db/client';
import {
  attendanceDays,
  companies,
  employees,
  employeeWorkPatternAssignments,
  holidays,
  timePunches,
  workPatterns,
  monthlyClosings,
  type AttendanceApprovals,
  type AttendanceManual,
} from '../../db/schema';
import { calculateAttendance, CALC_VERSION, summarize, type CalcPunch } from '../../domain/attendance-calc';
import { addDays, eachDate, monthRange, nowLocalDate, workDateOf } from '../../domain/time';

export interface EffectivePattern {
  id: string;
  code: string;
  name: string;
  patternType: WorkPatternType;
  rules: WorkPatternRules;
}

export function parseSettings(raw: unknown): CompanySettings {
  const r = CompanySettingsSchema.safeParse({ name: 'company', ...(raw as object) });
  return r.success ? r.data : CompanySettingsSchema.parse({ name: 'company' });
}

export class AttendanceCore {
  constructor(private readonly db: Db) {}

  async companyOf(employeeId: string) {
    const rows = await this.db
      .select({
        companyId: employees.companyId,
        timezone: companies.timezone,
        settings: companies.settings,
      })
      .from(employees)
      .innerJoin(companies, eq(companies.id, employees.companyId))
      .where(eq(employees.id, employeeId))
      .limit(1);
    if (!rows[0]) throw new Error(`employee not found: ${employeeId}`);
    return { ...rows[0], settings: parseSettings(rows[0].settings) };
  }

  /** 期間内の各日に有効な勤務パターンを解決（割当が無い日は会社の既定パターン） */
  async resolvePatterns(employeeId: string, companyId: string, from: string, to: string): Promise<Map<string, EffectivePattern>> {
    const assigns = await this.db
      .select({
        validFrom: employeeWorkPatternAssignments.validFrom,
        validTo: employeeWorkPatternAssignments.validTo,
        id: workPatterns.id,
        code: workPatterns.code,
        name: workPatterns.name,
        patternType: workPatterns.patternType,
        rules: workPatterns.rules,
      })
      .from(employeeWorkPatternAssignments)
      .innerJoin(workPatterns, eq(workPatterns.id, employeeWorkPatternAssignments.workPatternId))
      .where(
        and(
          eq(employeeWorkPatternAssignments.employeeId, employeeId),
          lte(employeeWorkPatternAssignments.validFrom, to),
          sql`(${employeeWorkPatternAssignments.validTo} is null or ${employeeWorkPatternAssignments.validTo} >= ${from})`,
        ),
      );
    let fallback: EffectivePattern | null = null;
    const map = new Map<string, EffectivePattern>();
    for (const d of eachDate(from, to)) {
      const a = assigns.find((x) => x.validFrom <= d && (!x.validTo || x.validTo >= d));
      if (a) {
        map.set(d, { id: a.id, code: a.code, name: a.name, patternType: a.patternType as WorkPatternType, rules: WorkPatternRulesSchema.parse(a.rules) });
      } else {
        if (!fallback) {
          const wp = await this.db
            .select()
            .from(workPatterns)
            .where(eq(workPatterns.companyId, companyId))
            .orderBy(asc(workPatterns.code))
            .limit(1);
          if (wp[0]) fallback = { id: wp[0].id, code: wp[0].code, name: wp[0].name, patternType: wp[0].patternType as WorkPatternType, rules: WorkPatternRulesSchema.parse(wp[0].rules) };
        }
        if (fallback) map.set(d, fallback);
      }
    }
    return map;
  }

  async holidaysBetween(companyId: string, from: string, to: string): Promise<Map<string, 'NATIONAL' | 'COMPANY'>> {
    const rows = await this.db
      .select({ date: holidays.date, kind: holidays.kind })
      .from(holidays)
      .where(and(eq(holidays.companyId, companyId), gte(holidays.date, from), lte(holidays.date, to)));
    return new Map(rows.map((r) => [r.date, r.kind as 'NATIONAL' | 'COMPANY']));
  }

  /**
   * 従業員の指定期間を再計算して attendance_days に upsert。
   * LOCKED の日はスキップ。打刻ログは変更しない。
   */
  async recalcEmployeeRange(employeeId: string, from: string, to: string, now = new Date()): Promise<number> {
    const { companyId, timezone, settings } = await this.companyOf(employeeId);
    const patterns = await this.resolvePatterns(employeeId, companyId, from, to);
    const hol = await this.holidaysBetween(companyId, from, to);

    // 打刻は境界を跨ぐ可能性があるので前後に余裕をもって取得
    const winStart = new Date(new Date(`${addDays(from, -1)}T00:00:00Z`).getTime() - 24 * 3600_000);
    const winEnd = new Date(new Date(`${addDays(to, 2)}T00:00:00Z`).getTime() + 24 * 3600_000);
    const punchRows = await this.db
      .select({
        punchType: timePunches.punchType,
        punchedAt: timePunches.punchedAt,
        geofenceOk: timePunches.geofenceOk,
      })
      .from(timePunches)
      .where(and(eq(timePunches.employeeId, employeeId), gte(timePunches.punchedAt, winStart), lte(timePunches.punchedAt, winEnd)))
      .orderBy(asc(timePunches.punchedAt));

    const byDate = new Map<string, CalcPunch[]>();
    for (const p of punchRows) {
      // その打刻のローカル日付に有効なパターンの境界時刻で勤務日を決定
      const localDate = workDateOf(p.punchedAt, timezone, '00:00');
      const pat = patterns.get(localDate) ?? patterns.get(addDays(localDate, -1)) ?? patterns.get(from);
      const boundary = pat?.rules.dayBoundary ?? '05:00';
      const wd = workDateOf(p.punchedAt, timezone, boundary);
      if (!byDate.has(wd)) byDate.set(wd, []);
      byDate.get(wd)!.push({ punchType: p.punchType as PunchType, punchedAt: p.punchedAt, geofenceOk: p.geofenceOk });
    }

    const existing = await this.db
      .select()
      .from(attendanceDays)
      .where(and(eq(attendanceDays.employeeId, employeeId), gte(attendanceDays.workDate, from), lte(attendanceDays.workDate, to)));
    const existingByDate = new Map(existing.map((e) => [e.workDate, e]));

    let count = 0;
    for (const d of eachDate(from, to)) {
      const ex = existingByDate.get(d);
      if (ex?.status === 'LOCKED') continue;
      const pat = patterns.get(d);
      if (!pat) continue;
      const manual: AttendanceManual = ex?.manual ?? {};
      const approvals: AttendanceApprovals = ex?.approvals ?? {};
      const r = calculateAttendance({
        workDate: d,
        timezone,
        patternType: pat.patternType,
        rules: pat.rules,
        punches: byDate.get(d) ?? [],
        holidayKind: hol.get(d) ?? null,
        manual,
        approvals,
        now,
      });
      const values = {
        dayType: r.dayType,
        workPatternId: pat.id,
        clockInAt: r.clockInAt,
        clockOutAt: r.clockOutAt,
        breakMinutes: r.breakMinutes,
        workMinutes: r.workMinutes,
        scheduledMinutes: r.scheduledMinutes,
        overtimeMinutes: r.overtimeMinutes,
        legalOvertimeMinutes: r.legalOvertimeMinutes,
        lateNightMinutes: r.lateNightMinutes,
        holidayWorkMinutes: r.holidayWorkMinutes,
        lateMinutes: r.lateMinutes,
        earlyLeaveMinutes: r.earlyLeaveMinutes,
        flags: r.flags,
        calcVersion: CALC_VERSION,
      };
      // 打刻も手修正も承認も無い休日は行を作らない（テーブル肥大防止）。ただし既存行は更新する
      const meaningful =
        ex ||
        (byDate.get(d)?.length ?? 0) > 0 ||
        r.dayType === 'WORKDAY' ||
        Object.keys(manual).length > 0 ||
        Object.keys(approvals).length > 0;
      if (!meaningful) continue;
      if (ex) {
        await this.db.update(attendanceDays).set(values).where(eq(attendanceDays.id, ex.id));
      } else {
        await this.db.insert(attendanceDays).values({ employeeId, workDate: d, manual, approvals, ...values });
      }
      count++;
    }
    void settings;
    return count;
  }

  /** 会社全員の指定期間を再計算 */
  async recalcCompanyRange(companyId: string, from: string, to: string, now = new Date()): Promise<number> {
    const emps = await this.db
      .select({ id: employees.id })
      .from(employees)
      .where(and(eq(employees.companyId, companyId), sql`(${employees.retiredAt} is null or ${employees.retiredAt} >= ${from})`));
    let n = 0;
    for (const e of emps) n += await this.recalcEmployeeRange(e.id, from, to, now);
    return n;
  }

  /** 月次サマリ */
  async monthSummary(employeeId: string, yearMonth: string, now = new Date()): Promise<AttendanceMonthSummary> {
    const { timezone, settings } = await this.companyOf(employeeId);
    const { from, to } = monthRange(yearMonth);
    const rows = await this.db
      .select()
      .from(attendanceDays)
      .where(and(eq(attendanceDays.employeeId, employeeId), gte(attendanceDays.workDate, from), lte(attendanceDays.workDate, to)));
    const s = summarize(
      rows.map((r) => ({
        workDate: r.workDate,
        dayType: r.dayType as DayType,
        workMinutes: r.workMinutes,
        overtimeMinutes: r.overtimeMinutes,
        legalOvertimeMinutes: r.legalOvertimeMinutes,
        lateNightMinutes: r.lateNightMinutes,
        holidayWorkMinutes: r.holidayWorkMinutes,
        lateMinutes: r.lateMinutes,
        earlyLeaveMinutes: r.earlyLeaveMinutes,
        flags: r.flags,
        status: r.status,
      })),
      { overtimeAlertMinutes: settings.overtimeAlertMinutes, overtimeLimitMinutes: settings.overtimeLimitMinutes, today: nowLocalDate(timezone, now) },
    );
    return { yearMonth, employeeId, ...s };
  }

  /** 月次締め: 当月の勤怠を LOCKED にしてスナップショット保存 */
  async lockMonth(companyId: string, employeeId: string, yearMonth: string, lockedBy: string | null, now = new Date()) {
    const { from, to } = monthRange(yearMonth);
    // 未確定分を再計算してから凍結
    await this.recalcEmployeeRange(employeeId, from, to, now);
    await this.db
      .update(attendanceDays)
      .set({ status: 'LOCKED' })
      .where(and(eq(attendanceDays.employeeId, employeeId), gte(attendanceDays.workDate, from), lte(attendanceDays.workDate, to)));
    const summary = await this.monthSummary(employeeId, yearMonth, now);
    const [row] = await this.db
      .insert(monthlyClosings)
      .values({ companyId, employeeId, yearMonth, lockedBy, snapshot: summary as unknown as Record<string, unknown>, lockedAt: now })
      .onConflictDoUpdate({
        target: [monthlyClosings.employeeId, monthlyClosings.yearMonth],
        set: { lockedBy, snapshot: summary as unknown as Record<string, unknown>, lockedAt: now },
      })
      .returning();
    return { closing: row, summary };
  }

  /** 締め解除 */
  async unlockMonth(employeeId: string, yearMonth: string) {
    const { from, to } = monthRange(yearMonth);
    await this.db
      .update(attendanceDays)
      .set({ status: 'DRAFT' })
      .where(and(eq(attendanceDays.employeeId, employeeId), gte(attendanceDays.workDate, from), lte(attendanceDays.workDate, to), eq(attendanceDays.status, 'LOCKED')));
    await this.db.delete(monthlyClosings).where(and(eq(monthlyClosings.employeeId, employeeId), eq(monthlyClosings.yearMonth, yearMonth)));
  }

  async isLocked(employeeId: string, workDate: string): Promise<boolean> {
    const r = await this.db
      .select({ status: attendanceDays.status })
      .from(attendanceDays)
      .where(and(eq(attendanceDays.employeeId, employeeId), eq(attendanceDays.workDate, workDate)))
      .limit(1);
    return r[0]?.status === 'LOCKED';
  }

  async lockedEmployeesIn(employeeIds: string[], yearMonth: string): Promise<Set<string>> {
    if (employeeIds.length === 0) return new Set();
    const rows = await this.db
      .select({ employeeId: monthlyClosings.employeeId })
      .from(monthlyClosings)
      .where(and(inArray(monthlyClosings.employeeId, employeeIds), eq(monthlyClosings.yearMonth, yearMonth)));
    return new Set(rows.map((r) => r.employeeId));
  }
}
