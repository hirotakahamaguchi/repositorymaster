import {
  BadRequestException,
  Body,
  Controller,
  ConflictException,
  Get,
  Inject,
  Injectable,
  Module,
  NotFoundException,
  Param,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import { and, asc, desc, eq, gte, inArray, lte } from 'drizzle-orm';
import {
  CorrectAttendanceSchema,
  yearMonth as yearMonthSchema,
  type AttendanceDayDto,
  type AttendanceMonthSummary,
  type AttendanceRevisionDto,
  type AttendanceStatus,
  type CorrectAttendanceInput,
  type DayType,
} from '@kintai/shared';
import { DB } from '../../db/db.module';
import type { Db } from '../../db/client';
import { attendanceDayRevisions, attendanceDays, departments, employees, workPatterns } from '../../db/schema';
import { CurrentUser, RequirePermissions } from '../../common/decorators';
import { zodBody } from '../../common/zod.pipe';
import { hasPermission, type AuthUser } from '../../common/auth-user';
import { AuditService } from '../audit/audit.service';
import { AuditModule } from '../audit/audit.module';
import { AccessService } from '../auth/access.service';
import { AttendanceCore } from './core';
import { monthRange, nowLocalDate } from '../../domain/time';

export function toAttendanceDto(r: typeof attendanceDays.$inferSelect & { employeeCode?: string; employeeName?: string; departmentName?: string | null; workPatternName?: string | null }): AttendanceDayDto {
  return {
    id: r.id,
    employeeId: r.employeeId,
    employeeCode: r.employeeCode,
    employeeName: r.employeeName,
    departmentName: r.departmentName,
    workDate: r.workDate,
    dayType: r.dayType as DayType,
    workPatternId: r.workPatternId,
    workPatternName: r.workPatternName,
    clockInAt: r.clockInAt?.toISOString() ?? null,
    clockOutAt: r.clockOutAt?.toISOString() ?? null,
    breakMinutes: r.breakMinutes,
    workMinutes: r.workMinutes,
    scheduledMinutes: r.scheduledMinutes,
    overtimeMinutes: r.overtimeMinutes,
    legalOvertimeMinutes: r.legalOvertimeMinutes,
    lateNightMinutes: r.lateNightMinutes,
    holidayWorkMinutes: r.holidayWorkMinutes,
    lateMinutes: r.lateMinutes,
    earlyLeaveMinutes: r.earlyLeaveMinutes,
    status: r.status as AttendanceStatus,
    note: r.note,
    flags: r.flags,
    version: r.version,
    calcVersion: r.calcVersion,
    updatedAt: r.updatedAt.toISOString(),
  };
}

@Injectable()
export class AttendanceService {
  readonly core: AttendanceCore;
  constructor(
    @Inject(DB) private readonly db: Db,
    private readonly audit: AuditService,
  ) {
    this.core = new AttendanceCore(db);
  }

  async monthDays(employeeId: string, ym: string): Promise<AttendanceDayDto[]> {
    const { from, to } = monthRange(ym);
    const rows = await this.db
      .select({ day: attendanceDays, workPatternName: workPatterns.name })
      .from(attendanceDays)
      .leftJoin(workPatterns, eq(workPatterns.id, attendanceDays.workPatternId))
      .where(and(eq(attendanceDays.employeeId, employeeId), gte(attendanceDays.workDate, from), lte(attendanceDays.workDate, to)))
      .orderBy(asc(attendanceDays.workDate));
    return rows.map((r) => toAttendanceDto({ ...r.day, workPatternName: r.workPatternName }));
  }

  /** 会社/部署の月次一覧（管理者用） */
  async companyMonth(companyId: string, ym: string, opts: { employeeIds: string[] | null; departmentId?: string; date?: string; flagged?: boolean }) {
    const { from, to } = monthRange(ym);
    const conds = [eq(employees.companyId, companyId), gte(attendanceDays.workDate, opts.date ?? from), lte(attendanceDays.workDate, opts.date ?? to)];
    if (opts.employeeIds) {
      if (opts.employeeIds.length === 0) return [];
      conds.push(inArray(attendanceDays.employeeId, opts.employeeIds));
    }
    if (opts.departmentId) conds.push(eq(employees.departmentId, opts.departmentId));
    const rows = await this.db
      .select({
        day: attendanceDays,
        employeeCode: employees.employeeCode,
        employeeName: employees.name,
        departmentName: departments.name,
        workPatternName: workPatterns.name,
      })
      .from(attendanceDays)
      .innerJoin(employees, eq(employees.id, attendanceDays.employeeId))
      .leftJoin(departments, eq(departments.id, employees.departmentId))
      .leftJoin(workPatterns, eq(workPatterns.id, attendanceDays.workPatternId))
      .where(and(...conds))
      .orderBy(asc(employees.employeeCode), asc(attendanceDays.workDate));
    let list = rows.map((r) => toAttendanceDto({ ...r.day, employeeCode: r.employeeCode, employeeName: r.employeeName, departmentName: r.departmentName, workPatternName: r.workPatternName }));
    // 「要確認」: 管理者の対応が必要なフラグのみ（遅刻・早退などの通常フラグは月次サマリで確認）
    const ATTENTION = ['MISSING_IN', 'MISSING_OUT', 'NO_PUNCH', 'UNAPPROVED_OVERTIME', 'UNAPPROVED_HOLIDAY_WORK', 'WORK_ON_LEAVE', 'GEOFENCE_NG', 'OVER_12H'];
    if (opts.flagged) list = list.filter((d) => d.flags.some((f) => ATTENTION.includes(f)));
    return list;
  }

  /** 会社/部署の月次サマリ一覧 */
  async companyMonthSummaries(companyId: string, ym: string, employeeIds: string[] | null, departmentId?: string, now = new Date()): Promise<AttendanceMonthSummary[]> {
    const conds = [eq(employees.companyId, companyId)];
    if (employeeIds) {
      if (employeeIds.length === 0) return [];
      conds.push(inArray(employees.id, employeeIds));
    }
    if (departmentId) conds.push(eq(employees.departmentId, departmentId));
    const emps = await this.db
      .select({ id: employees.id, code: employees.employeeCode, name: employees.name, departmentName: departments.name, retiredAt: employees.retiredAt })
      .from(employees)
      .leftJoin(departments, eq(departments.id, employees.departmentId))
      .where(and(...conds))
      .orderBy(asc(employees.employeeCode));
    const out: AttendanceMonthSummary[] = [];
    const { from } = monthRange(ym);
    for (const e of emps) {
      if (e.retiredAt && e.retiredAt < from) continue;
      const s = await this.core.monthSummary(e.id, ym, now);
      out.push({ ...s, employeeCode: e.code, employeeName: e.name, departmentName: e.departmentName });
    }
    return out;
  }

  async revisions(attendanceDayId: string): Promise<AttendanceRevisionDto[]> {
    const rows = await this.db
      .select({ rev: attendanceDayRevisions, changedByName: employees.name })
      .from(attendanceDayRevisions)
      .leftJoin(employees, eq(employees.id, attendanceDayRevisions.changedBy))
      .where(eq(attendanceDayRevisions.attendanceDayId, attendanceDayId))
      .orderBy(desc(attendanceDayRevisions.version));
    return rows.map((r) => ({
      id: r.rev.id,
      attendanceDayId: r.rev.attendanceDayId,
      version: r.rev.version,
      before: r.rev.before as AttendanceRevisionDto['before'],
      after: r.rev.after as AttendanceRevisionDto['after'],
      reason: r.rev.reason,
      changedBy: r.rev.changedBy ? { id: r.rev.changedBy, name: r.changedByName ?? '' } : null,
      requestId: r.rev.requestId,
      changedAt: r.rev.changedAt.toISOString(),
    }));
  }

  /**
   * 管理者による勤怠修正
   *  - 楽観ロック (version)
   *  - 締め済みは修正不可
   *  - 修正内容は manual に保存し再計算。before/after を revisions に保存
   */
  async correct(user: AuthUser, attendanceDayId: string, input: CorrectAttendanceInput): Promise<AttendanceDayDto> {
    const [ex] = await this.db.select().from(attendanceDays).where(eq(attendanceDays.id, attendanceDayId)).limit(1);
    if (!ex) throw new NotFoundException('勤怠データが見つかりません');
    if (ex.status === 'LOCKED') throw new BadRequestException('締め済みの勤怠は修正できません。締め解除してください');
    if (ex.version !== input.version) throw new ConflictException('他のユーザによって更新されています。再読み込みしてください');

    const manual = { ...ex.manual };
    if (input.clockInAt !== undefined) manual.clockInAt = input.clockInAt;
    if (input.clockOutAt !== undefined) manual.clockOutAt = input.clockOutAt;
    if (input.breakMinutes !== undefined) manual.breakMinutes = input.breakMinutes;
    if (input.dayType !== undefined) manual.dayType = input.dayType;
    const version = ex.version + 1;
    const before = toAttendanceDto(ex);

    await this.db.transaction(async (tx) => {
      await tx
        .update(attendanceDays)
        .set({ manual, note: input.note ?? ex.note, version })
        .where(and(eq(attendanceDays.id, attendanceDayId), eq(attendanceDays.version, ex.version)));
      const core = new AttendanceCore(tx as unknown as Db);
      await core.recalcEmployeeRange(ex.employeeId, ex.workDate, ex.workDate);
      const [after] = await tx.select().from(attendanceDays).where(eq(attendanceDays.id, attendanceDayId));
      await tx.insert(attendanceDayRevisions).values({
        attendanceDayId,
        version,
        before: before as unknown as Record<string, unknown>,
        after: toAttendanceDto(after) as unknown as Record<string, unknown>,
        reason: input.reason,
        changedBy: user.id,
        requestId: null,
      });
    });
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'attendance.corrected', targetType: 'attendance_day', targetId: attendanceDayId, detail: { employeeId: ex.employeeId, workDate: ex.workDate, reason: input.reason } });
    const [row] = await this.db.select().from(attendanceDays).where(eq(attendanceDays.id, attendanceDayId));
    return toAttendanceDto(row);
  }

  /** 手修正を解除して打刻ベースに戻す */
  async resetManual(user: AuthUser, attendanceDayId: string, reason: string): Promise<AttendanceDayDto> {
    const [ex] = await this.db.select().from(attendanceDays).where(eq(attendanceDays.id, attendanceDayId)).limit(1);
    if (!ex) throw new NotFoundException();
    if (ex.status === 'LOCKED') throw new BadRequestException('締め済みの勤怠は修正できません');
    const version = ex.version + 1;
    await this.db.update(attendanceDays).set({ manual: {}, version }).where(eq(attendanceDays.id, attendanceDayId));
    await this.core.recalcEmployeeRange(ex.employeeId, ex.workDate, ex.workDate);
    const [after] = await this.db.select().from(attendanceDays).where(eq(attendanceDays.id, attendanceDayId));
    await this.db.insert(attendanceDayRevisions).values({ attendanceDayId, version, before: toAttendanceDto(ex) as unknown as Record<string, unknown>, after: toAttendanceDto(after) as unknown as Record<string, unknown>, reason: `手修正解除: ${reason}`, changedBy: user.id });
    return toAttendanceDto(after);
  }

  async confirmMonth(user: AuthUser, employeeId: string, ym: string) {
    const { from, to } = monthRange(ym);
    await this.db
      .update(attendanceDays)
      .set({ status: 'CONFIRMED' })
      .where(and(eq(attendanceDays.employeeId, employeeId), gte(attendanceDays.workDate, from), lte(attendanceDays.workDate, to), eq(attendanceDays.status, 'DRAFT')));
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'attendance.month_confirmed', targetType: 'employee', targetId: employeeId, detail: { yearMonth: ym } });
  }
}

@Controller('attendance')
export class AttendanceController {
  constructor(
    private readonly svc: AttendanceService,
    private readonly access: AccessService,
  ) {}

  private ym(user: AuthUser, v?: string) {
    if (!v) return nowLocalDate(user.timezone).slice(0, 7);
    const r = yearMonthSchema.safeParse(v);
    if (!r.success) throw new BadRequestException('month は YYYY-MM 形式で指定してください');
    return r.data;
  }

  @Get('me')
  async me(@CurrentUser() user: AuthUser, @Query('month') month?: string) {
    const ym = this.ym(user, month);
    const [days, summary] = await Promise.all([this.svc.monthDays(user.id, ym), this.svc.core.monthSummary(user.id, ym)]);
    return { yearMonth: ym, days, summary };
  }

  @Get('employees/:employeeId')
  async employee(@CurrentUser() user: AuthUser, @Param('employeeId') employeeId: string, @Query('month') month?: string) {
    await this.access.assertCanReadEmployee(user, employeeId);
    const ym = this.ym(user, month);
    const [days, summary] = await Promise.all([this.svc.monthDays(employeeId, ym), this.svc.core.monthSummary(employeeId, ym)]);
    return { yearMonth: ym, days, summary };
  }

  /** 管理者: 月次一覧（日別行） */
  @Get('company')
  @RequirePermissions('attendance:read:department', 'attendance:read:company')
  async company(
    @CurrentUser() user: AuthUser,
    @Query('month') month?: string,
    @Query('departmentId') departmentId?: string,
    @Query('date') date?: string,
    @Query('flagged') flagged?: string,
  ) {
    const ids = await this.access.readableEmployeeIds(user);
    return this.svc.companyMonth(user.companyId, this.ym(user, month), { employeeIds: ids, departmentId, date, flagged: flagged === 'true' });
  }

  /** 管理者: 月次サマリ一覧 */
  @Get('company/summary')
  @RequirePermissions('attendance:read:department', 'attendance:read:company')
  async companySummary(@CurrentUser() user: AuthUser, @Query('month') month?: string, @Query('departmentId') departmentId?: string) {
    const ids = await this.access.readableEmployeeIds(user);
    return this.svc.companyMonthSummaries(user.companyId, this.ym(user, month), ids, departmentId);
  }

  @Get('days/:id/revisions')
  async revisions(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    const revs = await this.svc.revisions(id);
    // 本人 or 閲覧権限者のみ
    const [day] = await this.svc['db'].select({ employeeId: attendanceDays.employeeId }).from(attendanceDays).where(eq(attendanceDays.id, id));
    if (!day) throw new NotFoundException();
    await this.access.assertCanReadEmployee(user, day.employeeId);
    return revs;
  }

  @Patch('days/:id')
  @RequirePermissions('attendance:write:department', 'attendance:write:company')
  async correct(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body(zodBody(CorrectAttendanceSchema)) body: CorrectAttendanceInput) {
    const [day] = await this.svc['db'].select({ employeeId: attendanceDays.employeeId }).from(attendanceDays).where(eq(attendanceDays.id, id));
    if (!day) throw new NotFoundException();
    await this.access.assertCanWriteAttendance(user, day.employeeId);
    return this.svc.correct(user, id, body);
  }

  @Post('days/:id/reset-manual')
  @RequirePermissions('attendance:write:department', 'attendance:write:company')
  async resetManual(@CurrentUser() user: AuthUser, @Param('id') id: string, @Body() body: { reason?: string }) {
    const [day] = await this.svc['db'].select({ employeeId: attendanceDays.employeeId }).from(attendanceDays).where(eq(attendanceDays.id, id));
    if (!day) throw new NotFoundException();
    await this.access.assertCanWriteAttendance(user, day.employeeId);
    return this.svc.resetManual(user, id, body?.reason ?? '');
  }

  /** 再計算（管理者・トラブルシュート用） */
  @Post('recalc')
  @RequirePermissions('attendance:write:company')
  async recalc(@CurrentUser() user: AuthUser, @Body() body: { employeeId?: string; from: string; to: string }) {
    if (!body?.from || !body?.to) throw new BadRequestException('from/to は必須です');
    const n = body.employeeId
      ? await this.svc.core.recalcEmployeeRange(body.employeeId, body.from, body.to)
      : await this.svc.core.recalcCompanyRange(user.companyId, body.from, body.to);
    return { recalculated: n };
  }

  @Post('employees/:employeeId/confirm')
  @RequirePermissions('attendance:write:department', 'attendance:write:company')
  async confirm(@CurrentUser() user: AuthUser, @Param('employeeId') employeeId: string, @Query('month') month?: string) {
    await this.access.assertCanWriteAttendance(user, employeeId);
    await this.svc.confirmMonth(user, employeeId, this.ym(user, month));
    return { ok: true };
  }

  /** 権限の確認用ヘルパ（フロントのメニュー出し分けに使用） */
  @Get('capabilities')
  capabilities(@CurrentUser() user: AuthUser) {
    return {
      canReadDepartment: hasPermission(user, 'attendance:read:department'),
      canReadCompany: hasPermission(user, 'attendance:read:company'),
      canWrite: hasPermission(user, 'attendance:write:department', 'attendance:write:company'),
    };
  }
}

@Module({
  imports: [AuditModule],
  providers: [AttendanceService],
  controllers: [AttendanceController],
  exports: [AttendanceService],
})
export class AttendanceModule {}
