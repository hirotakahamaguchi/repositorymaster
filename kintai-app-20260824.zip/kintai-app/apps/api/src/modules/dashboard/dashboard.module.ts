import { Controller, Get, Inject, Module } from '@nestjs/common';
import { and, eq, gte, lte, sql } from 'drizzle-orm';
import type { AdminDashboardDto, DashboardDto, LeaveType } from '@kintai/shared';
import { DB } from '../../db/db.module';
import type { Db } from '../../db/client';
import { attendanceDays, employees, monthlyClosings } from '../../db/schema';
import { CurrentUser, RequirePermissions } from '../../common/decorators';
import { hasPermission, type AuthUser } from '../../common/auth-user';
import { AttendanceModule, AttendanceService, toAttendanceDto } from '../attendance/attendance.module';
import { PunchesModule, PunchesService } from '../punches/punches.module';
import { RequestsModule, RequestsService } from '../requests/requests.module';
import { RequestCore } from '../requests/core';
import { AccessService } from '../auth/access.service';
import { addDays, nowLocalDate, workDateOf, workDateWindow } from '../../domain/time';
import { addMonths } from '@kintai/shared';

@Controller('dashboard')
export class DashboardController {
  constructor(
    @Inject(DB) private readonly db: Db,
    private readonly attendance: AttendanceService,
    private readonly punches: PunchesService,
    private readonly requests: RequestsService,
    private readonly access: AccessService,
  ) {}

  @Get('me')
  async me(@CurrentUser() user: AuthUser): Promise<DashboardDto> {
    const now = new Date();
    const calendarToday = nowLocalDate(user.timezone, now);
    // 勤務日は勤務パターンの日付境界（例 05:00）で決まる。深夜 0〜5 時は前日の勤務日として扱う
    const patterns = await this.attendance.core.resolvePatterns(user.id, user.companyId, calendarToday, calendarToday);
    const boundary = patterns.get(calendarToday)?.rules.dayBoundary ?? '05:00';
    const today = workDateOf(now, user.timezone, boundary);
    const ym = calendarToday.slice(0, 7);
    const win = workDateWindow(today, user.timezone, boundary);
    const [todayPunches, lastPunch, summary, myPending, approvals, balances, todayRows] = await Promise.all([
      this.punches.listForEmployee(user.id, win.start, win.end),
      this.punches.last(user.id),
      this.attendance.core.monthSummary(user.id, ym),
      this.requests.mine(user, { page: 1, pageSize: 1, status: 'PENDING' }),
      hasPermission(user, 'request:approve:department', 'request:approve:company') ? this.requests.pendingCountForApprover(user) : Promise.resolve(0),
      new RequestCore(this.db).leaveBalances(user.id, today),
      this.db.select().from(attendanceDays).where(and(eq(attendanceDays.employeeId, user.id), eq(attendanceDays.workDate, today))).limit(1),
    ]);
    const last = todayPunches[todayPunches.length - 1] ?? null;
    const working = !!last && last.punchType !== 'OUT';
    const onBreak = !!last && last.punchType === 'BREAK_START';
    const s = user.settings;
    return {
      today,
      todayAttendance: todayRows[0] ? toAttendanceDto(todayRows[0]) : null,
      todayPunches,
      lastPunch: lastPunch,
      working,
      onBreak,
      monthSummary: summary,
      pendingRequests: myPending.total,
      pendingApprovals: approvals,
      leaveBalances: balances.map((b) => ({ ...b, leaveType: b.leaveType as LeaveType })),
      geofence: s.officeLatitude != null && s.officeLongitude != null ? { latitude: s.officeLatitude, longitude: s.officeLongitude, radiusM: s.geofenceRadiusM } : null,
    };
  }

  @Get('admin')
  @RequirePermissions('attendance:read:department', 'attendance:read:company')
  async admin(@CurrentUser() user: AuthUser): Promise<AdminDashboardDto> {
    const today = nowLocalDate(user.timezone);
    const ym = today.slice(0, 7);
    const ids = await this.access.readableEmployeeIds(user);
    const empConds = [eq(employees.companyId, user.companyId), sql`(${employees.retiredAt} is null or ${employees.retiredAt} >= ${today})`];
    if (ids) empConds.push(sql`${employees.id} in ${ids.length ? ids : ['00000000-0000-0000-0000-000000000000']}`);
    const emps = await this.db.select({ id: employees.id, name: employees.name }).from(employees).where(and(...empConds));
    const empIds = emps.map((e) => e.id);
    const nameMap = new Map(emps.map((e) => [e.id, e.name]));

    const todayRows = empIds.length
      ? await this.db.select().from(attendanceDays).where(and(sql`${attendanceDays.employeeId} in ${empIds}`, eq(attendanceDays.workDate, today)))
      : [];
    let presentCount = 0;
    let leftCount = 0;
    let onLeaveCount = 0;
    for (const r of todayRows) {
      if (r.dayType === 'PAID_LEAVE' || r.dayType === 'SPECIAL_LEAVE') onLeaveCount++;
      else if (r.clockInAt && !r.clockOutAt) presentCount++;
      else if (r.clockInAt && r.clockOutAt) leftCount++;
    }
    const notYetCount = Math.max(0, empIds.length - presentCount - leftCount - onLeaveCount);

    // 今月の残業アラート
    const overtimeAlerts: AdminDashboardDto['overtimeAlerts'] = [];
    const missingPunches: AdminDashboardDto['missingPunches'] = [];
    if (empIds.length) {
      const from = `${ym}-01`;
      const agg = await this.db
        .select({
          employeeId: attendanceDays.employeeId,
          ot: sql<number>`sum(${attendanceDays.legalOvertimeMinutes} + ${attendanceDays.holidayWorkMinutes})::int`,
        })
        .from(attendanceDays)
        .where(and(sql`${attendanceDays.employeeId} in ${empIds}`, gte(attendanceDays.workDate, from), lte(attendanceDays.workDate, today)))
        .groupBy(attendanceDays.employeeId);
      for (const a of agg) {
        const ot = Number(a.ot);
        if (ot >= user.settings.overtimeLimitMinutes) overtimeAlerts.push({ employeeId: a.employeeId, name: nameMap.get(a.employeeId) ?? '', overtimeMinutes: ot, level: 'LIMIT' });
        else if (ot >= user.settings.overtimeAlertMinutes) overtimeAlerts.push({ employeeId: a.employeeId, name: nameMap.get(a.employeeId) ?? '', overtimeMinutes: ot, level: 'WARN' });
      }
      overtimeAlerts.sort((a, b) => b.overtimeMinutes - a.overtimeMinutes);
      const missing = await this.db
        .select({ employeeId: attendanceDays.employeeId, workDate: attendanceDays.workDate, flags: attendanceDays.flags })
        .from(attendanceDays)
        .where(
          and(
            sql`${attendanceDays.employeeId} in ${empIds}`,
            gte(attendanceDays.workDate, addDays(today, -14)),
            lte(attendanceDays.workDate, today),
            sql`(${attendanceDays.flags} ? 'MISSING_OUT' or ${attendanceDays.flags} ? 'MISSING_IN' or ${attendanceDays.flags} ? 'NO_PUNCH')`,
            sql`${attendanceDays.status} <> 'LOCKED'`,
          ),
        )
        .orderBy(sql`${attendanceDays.workDate} desc`)
        .limit(30);
      for (const m of missing) missingPunches.push({ employeeId: m.employeeId, name: nameMap.get(m.employeeId) ?? '', workDate: m.workDate, flags: m.flags });
    }

    // 未締め月（直近3か月で締め件数が従業員数未満）
    const unlockedMonths: string[] = [];
    for (let i = 1; i <= 3; i++) {
      const m = addMonths(ym, -i);
      const [{ n }] = await this.db.select({ n: sql<number>`count(*)::int` }).from(monthlyClosings).where(and(eq(monthlyClosings.companyId, user.companyId), eq(monthlyClosings.yearMonth, m)));
      if (Number(n) >= emps.length) continue;
      // 勤怠データが無い月（運用開始前など）は対象外
      const [{ d }] = await this.db
        .select({ d: sql<number>`count(*)::int` })
        .from(attendanceDays)
        .where(and(gte(attendanceDays.workDate, `${m}-01`), lte(attendanceDays.workDate, `${m}-31`), sql`${attendanceDays.status} <> 'LOCKED'`));
      if (Number(d) > 0) unlockedMonths.push(m);
    }

    const pendingApprovals = hasPermission(user, 'request:approve:department', 'request:approve:company') ? await this.requests.pendingCountForApprover(user) : 0;
    return { date: today, headcount: empIds.length, presentCount, leftCount, notYetCount, onLeaveCount, pendingApprovals, overtimeAlerts, missingPunches, unlockedMonths };
  }
}

@Module({
  imports: [AttendanceModule, PunchesModule, RequestsModule],
  controllers: [DashboardController],
})
export class DashboardModule {}
