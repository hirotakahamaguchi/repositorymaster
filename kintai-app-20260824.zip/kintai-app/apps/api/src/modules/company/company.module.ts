import { Body, Controller, Get, Inject, Module, Put } from '@nestjs/common';
import { eq } from 'drizzle-orm';
import { CompanySettingsSchema, type CompanySettings } from '@kintai/shared';
import { DB } from '../../db/db.module';
import type { Db } from '../../db/client';
import { companies } from '../../db/schema';
import { CurrentUser, RequirePermissions } from '../../common/decorators';
import { zodBody } from '../../common/zod.pipe';
import type { AuthUser } from '../../common/auth-user';
import { AuditService } from '../audit/audit.service';
import { AuditModule } from '../audit/audit.module';
import { parseSettings } from '../attendance/core';

@Controller('company')
export class CompanyController {
  constructor(
    @Inject(DB) private readonly db: Db,
    private readonly audit: AuditService,
  ) {}

  @Get('settings')
  async get(@CurrentUser() user: AuthUser): Promise<CompanySettings> {
    const [c] = await this.db.select().from(companies).where(eq(companies.id, user.companyId));
    return { ...parseSettings(c.settings), name: c.name, timezone: c.timezone };
  }

  @Put('settings')
  @RequirePermissions('master:write:company')
  async update(@CurrentUser() user: AuthUser, @Body(zodBody(CompanySettingsSchema)) body: CompanySettings): Promise<CompanySettings> {
    await this.db
      .update(companies)
      .set({ name: body.name, timezone: body.timezone, settings: body as unknown as Record<string, unknown> })
      .where(eq(companies.id, user.companyId));
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'company.settings_updated', targetType: 'company', targetId: user.companyId, detail: body as unknown as Record<string, unknown> });
    return body;
  }
}

@Module({ imports: [AuditModule], controllers: [CompanyController] })
export class CompanyModule {}
