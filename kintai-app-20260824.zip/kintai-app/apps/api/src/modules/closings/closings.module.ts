import { BadRequestException, Body, Controller, Get, Header, Inject, Injectable, Module, Param, Post, Query, Res } from '@nestjs/common';
import type { Response } from 'express';
import { and, asc, desc, eq, inArray, sql } from 'drizzle-orm';
import * as iconv from 'iconv-lite';
import { CloseMonthSchema, minutesToHm, yearMonth as yearMonthSchema, type AttendanceMonthSummary, type CloseMonthInput, type MonthlyClosingDto } from '@kintai/shared';
import { DB } from '../../db/db.module';
import type { Db } from '../../db/client';
import { csvExports, departments, employees, monthlyClosings } from '../../db/schema';
import { CurrentUser, RequirePermissions } from '../../common/decorators';
import { zodBody } from '../../common/zod.pipe';
import type { AuthUser } from '../../common/auth-user';
import { AuditService } from '../audit/audit.service';
import { AuditModule } from '../audit/audit.module';
import { AttendanceService } from '../attendance/attendance.module';
import { AttendanceModule } from '../attendance/attendance.module';
import { monthRange, nowLocalDate } from '../../domain/time';

/** 給与システム向け CSV の列定義（列の追加・並び替えはここだけ変更） */
export const PAYROLL_CSV_COLUMNS: { key: string; header: string; get: (s: AttendanceMonthSummary, extra: { code: string; name: string; dept: string }) => string | number }[] = [
  { key: 'yearMonth', header: '対象年月', get: (s) => s.yearMonth },
  { key: 'employeeCode', header: '社員番号', get: (_s, e) => e.code },
  { key: 'name', header: '氏名', get: (_s, e) => e.name },
  { key: 'department', header: '部署', get: (_s, e) => e.dept },
  { key: 'scheduledDays', header: '所定日数', get: (s) => s.scheduledDays },
  { key: 'actualWorkDays', header: '出勤日数', get: (s) => s.actualWorkDays },
  { key: 'absenceDays', header: '欠勤日数', get: (s) => s.absenceDays },
  { key: 'paidLeaveDays', header: '有給取得日数', get: (s) => s.paidLeaveDays },
  { key: 'workHours', header: '総労働時間', get: (s) => minutesToHm(s.workMinutes) },
  { key: 'workMinutes', header: '総労働時間(分)', get: (s) => s.workMinutes },
  { key: 'overtimeMinutes', header: '所定外労働(分)', get: (s) => s.overtimeMinutes },
  { key: 'legalOvertimeMinutes', header: '法定外労働(分)', get: (s) => s.legalOvertimeMinutes },
  { key: 'lateNightMinutes', header: '深夜労働(分)', get: (s) => s.lateNightMinutes },
  { key: 'holidayWorkMinutes', header: '法定休日労働(分)', get: (s) => s.holidayWorkMinutes },
  { key: 'lateCount', header: '遅刻回数', get: (s) => s.lateCount },
  { key: 'earlyLeaveCount', header: '早退回数', get: (s) => s.earlyLeaveCount },
  { key: 'status', header: '締め状態', get: (s) => s.status },
];

function csvEscape(v: string | number): string {
  const s = String(v ?? '');
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

@Injectable()
export class ClosingsService {
  constructor(
    @Inject(DB) private readonly db: Db,
    private readonly audit: AuditService,
    private readonly attendance: AttendanceService,
  ) {}

  async list(companyId: string, ym: string): Promise<MonthlyClosingDto[]> {
    const rows = await this.db
      .select({ c: monthlyClosings, employeeName: employees.name, employeeCode: employees.employeeCode })
      .from(monthlyClosings)
      .innerJoin(employees, eq(employees.id, monthlyClosings.employeeId))
      .where(and(eq(monthlyClosings.companyId, companyId), eq(monthlyClosings.yearMonth, ym)))
      .orderBy(asc(employees.employeeCode));
    const lockerIds = [...new Set(rows.map((r) => r.c.lockedBy).filter(Boolean))] as string[];
    const lockers = lockerIds.length ? await this.db.select({ id: employees.id, name: employees.name }).from(employees).where(inArray(employees.id, lockerIds)) : [];
    const lmap = new Map(lockers.map((l) => [l.id, l.name]));
    return rows.map((r) => ({
      id: r.c.id,
      yearMonth: r.c.yearMonth,
      employeeId: r.c.employeeId,
      employeeName: r.employeeName,
      employeeCode: r.employeeCode,
      lockedAt: r.c.lockedAt.toISOString(),
      lockedByName: r.c.lockedBy ? lmap.get(r.c.lockedBy) ?? '' : 'system',
      snapshot: r.c.snapshot as unknown as AttendanceMonthSummary,
    }));
  }

  /** 月次締め（指定従業員 or 全員）。締め前チェック: 打刻漏れ・未承認残業がある場合は force=true で強行 */
  async close(user: AuthUser, input: CloseMonthInput, force: boolean) {
    const today = nowLocalDate(user.timezone);
    if (input.yearMonth >= today.slice(0, 7)) throw new BadRequestException('当月以降は締められません（月が終了してから実行してください）');
    const { from } = monthRange(input.yearMonth);
    const targets = input.employeeIds?.length
      ? await this.db.select({ id: employees.id, name: employees.name }).from(employees).where(and(eq(employees.companyId, user.companyId), inArray(employees.id, input.employeeIds)))
      : await this.db.select({ id: employees.id, name: employees.name }).from(employees).where(and(eq(employees.companyId, user.companyId), sql`(${employees.retiredAt} is null or ${employees.retiredAt} >= ${from})`));

    const blocked: { employeeId: string; name: string; alerts: string[] }[] = [];
    const closed: string[] = [];
    for (const t of targets) {
      const summary = await this.attendance.core.monthSummary(t.id, input.yearMonth);
      const hard = summary.alerts.filter((a) => a === 'MISSING_PUNCH');
      if (hard.length && !force) {
        blocked.push({ employeeId: t.id, name: t.name, alerts: summary.alerts });
        continue;
      }
      await this.attendance.core.lockMonth(user.companyId, t.id, input.yearMonth, user.id);
      closed.push(t.id);
    }
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'closing.executed', targetType: 'month', targetId: input.yearMonth, detail: { closed: closed.length, blocked: blocked.length, force } });
    return { closed: closed.length, blocked };
  }

  async reopen(user: AuthUser, ym: string, employeeId: string) {
    await this.attendance.core.unlockMonth(employeeId, ym);
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'closing.reopened', targetType: 'employee', targetId: employeeId, detail: { yearMonth: ym } });
  }

  /** 給与 CSV 生成。締め済み従業員はスナップショット、未締めは現在値（preview） */
  async buildCsv(user: AuthUser, ym: string, opts: { encoding: 'utf8' | 'sjis'; departmentId?: string; lockedOnly: boolean }) {
    const { from } = monthRange(ym);
    const conds = [eq(employees.companyId, user.companyId), sql`(${employees.retiredAt} is null or ${employees.retiredAt} >= ${from})`];
    if (opts.departmentId) conds.push(eq(employees.departmentId, opts.departmentId));
    const emps = await this.db
      .select({ id: employees.id, code: employees.employeeCode, name: employees.name, dept: departments.name })
      .from(employees)
      .leftJoin(departments, eq(departments.id, employees.departmentId))
      .where(and(...conds))
      .orderBy(asc(employees.employeeCode));
    const snaps = await this.db
      .select()
      .from(monthlyClosings)
      .where(and(eq(monthlyClosings.companyId, user.companyId), eq(monthlyClosings.yearMonth, ym)));
    const snapMap = new Map(snaps.map((s) => [s.employeeId, s.snapshot as unknown as AttendanceMonthSummary]));

    const lines: string[] = [PAYROLL_CSV_COLUMNS.map((c) => csvEscape(c.header)).join(',')];
    let rowCount = 0;
    for (const e of emps) {
      let s = snapMap.get(e.id);
      if (!s) {
        if (opts.lockedOnly) continue;
        s = await this.attendance.core.monthSummary(e.id, ym);
      }
      lines.push(PAYROLL_CSV_COLUMNS.map((c) => csvEscape(c.get(s!, { code: e.code, name: e.name, dept: e.dept ?? '' }))).join(','));
      rowCount++;
    }
    const text = lines.join('\r\n') + '\r\n';
    const fileName = `payroll_${ym}${opts.lockedOnly ? '' : '_preview'}.csv`;
    const buffer = opts.encoding === 'sjis' ? iconv.encode(text, 'Shift_JIS') : Buffer.concat([Buffer.from('﻿', 'utf8'), Buffer.from(text, 'utf8')]);

    await this.db.insert(csvExports).values({ companyId: user.companyId, yearMonth: ym, format: opts.encoding, fileName, content: text, rowCount, createdBy: user.id });
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'export.csv', targetType: 'month', targetId: ym, detail: { rowCount, encoding: opts.encoding, lockedOnly: opts.lockedOnly } });
    return { buffer, fileName, rowCount };
  }

  async exportHistory(companyId: string) {
    const rows = await this.db
      .select({ id: csvExports.id, yearMonth: csvExports.yearMonth, format: csvExports.format, fileName: csvExports.fileName, rowCount: csvExports.rowCount, createdAt: csvExports.createdAt, createdByName: employees.name })
      .from(csvExports)
      .leftJoin(employees, eq(employees.id, csvExports.createdBy))
      .where(eq(csvExports.companyId, companyId))
      .orderBy(desc(csvExports.createdAt))
      .limit(50);
    return rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() }));
  }
}

@Controller('closings')
export class ClosingsController {
  constructor(private readonly svc: ClosingsService) {}

  private ym(v?: string) {
    const r = yearMonthSchema.safeParse(v);
    if (!r.success) throw new BadRequestException('month は YYYY-MM 形式で指定してください');
    return r.data;
  }

  @Get()
  @RequirePermissions('closing:execute:company', 'attendance:read:company')
  list(@CurrentUser() user: AuthUser, @Query('month') month?: string) {
    return this.svc.list(user.companyId, this.ym(month));
  }

  @Post()
  @RequirePermissions('closing:execute:company')
  close(@CurrentUser() user: AuthUser, @Body(zodBody(CloseMonthSchema)) body: CloseMonthInput, @Query('force') force?: string) {
    return this.svc.close(user, body, force === 'true');
  }

  @Post(':month/reopen/:employeeId')
  @RequirePermissions('closing:execute:company')
  async reopen(@CurrentUser() user: AuthUser, @Param('month') month: string, @Param('employeeId') employeeId: string) {
    await this.svc.reopen(user, this.ym(month), employeeId);
    return { ok: true };
  }

  @Get('exports')
  @RequirePermissions('export:csv:company')
  exports(@CurrentUser() user: AuthUser) {
    return this.svc.exportHistory(user.companyId);
  }

  @Get('csv')
  @RequirePermissions('export:csv:company')
  @Header('Cache-Control', 'no-store')
  async csv(
    @CurrentUser() user: AuthUser,
    @Res() res: Response,
    @Query('month') month?: string,
    @Query('encoding') encoding?: string,
    @Query('departmentId') departmentId?: string,
    @Query('lockedOnly') lockedOnly?: string,
  ) {
    const { buffer, fileName } = await this.svc.buildCsv(user, this.ym(month), {
      encoding: encoding === 'sjis' ? 'sjis' : 'utf8',
      departmentId,
      lockedOnly: lockedOnly === 'true',
    });
    res.setHeader('Content-Type', encoding === 'sjis' ? 'text/csv; charset=Shift_JIS' : 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"; filename*=UTF-8''${encodeURIComponent(fileName)}`);
    res.send(buffer);
  }
}

@Module({
  imports: [AuditModule, AttendanceModule],
  providers: [ClosingsService],
  controllers: [ClosingsController],
})
export class ClosingsModule {}
