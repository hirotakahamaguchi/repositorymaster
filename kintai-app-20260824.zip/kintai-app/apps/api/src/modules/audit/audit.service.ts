import { Inject, Injectable } from '@nestjs/common';
import { and, desc, eq, sql } from 'drizzle-orm';
import type { AuditLogDto, Paginated } from '@kintai/shared';
import { DB } from '../../db/db.module';
import type { Db } from '../../db/client';
import { auditLogs, employees } from '../../db/schema';

export interface AuditEntry {
  companyId: string;
  actorId: string | null;
  action: string;
  targetType: string;
  targetId?: string | null;
  detail?: Record<string, unknown> | null;
  ip?: string | null;
}

@Injectable()
export class AuditService {
  constructor(@Inject(DB) private readonly db: Db) {}

  async log(e: AuditEntry): Promise<void> {
    await this.db.insert(auditLogs).values({
      companyId: e.companyId,
      actorId: e.actorId,
      action: e.action,
      targetType: e.targetType,
      targetId: e.targetId ?? null,
      detail: e.detail ?? null,
      ip: e.ip ?? null,
    });
  }

  async list(companyId: string, opts: { page: number; pageSize: number; action?: string; actorId?: string }): Promise<Paginated<AuditLogDto>> {
    const conds = [eq(auditLogs.companyId, companyId)];
    if (opts.action) conds.push(sql`${auditLogs.action} like ${opts.action + '%'}`);
    if (opts.actorId) conds.push(eq(auditLogs.actorId, opts.actorId));
    const where = and(...conds);
    const [{ n }] = await this.db.select({ n: sql<number>`count(*)::int` }).from(auditLogs).where(where);
    const rows = await this.db
      .select({
        id: auditLogs.id,
        actorId: auditLogs.actorId,
        actorName: employees.name,
        action: auditLogs.action,
        targetType: auditLogs.targetType,
        targetId: auditLogs.targetId,
        detail: auditLogs.detail,
        ip: auditLogs.ip,
        createdAt: auditLogs.createdAt,
      })
      .from(auditLogs)
      .leftJoin(employees, eq(employees.id, auditLogs.actorId))
      .where(where)
      .orderBy(desc(auditLogs.createdAt))
      .limit(opts.pageSize)
      .offset((opts.page - 1) * opts.pageSize);
    return {
      items: rows.map((r) => ({ ...r, id: String(r.id), createdAt: r.createdAt.toISOString() })),
      total: Number(n),
      page: opts.page,
      pageSize: opts.pageSize,
    };
  }
}
