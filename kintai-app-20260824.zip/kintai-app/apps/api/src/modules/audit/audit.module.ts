import { Controller, Get, Module, Query } from '@nestjs/common';
import { AuditService } from './audit.service';
import { CurrentUser, RequirePermissions } from '../../common/decorators';
import type { AuthUser } from '../../common/auth-user';

@Controller('audit-logs')
export class AuditController {
  constructor(private readonly audit: AuditService) {}

  @Get()
  @RequirePermissions('audit:read:company')
  list(
    @CurrentUser() user: AuthUser,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
    @Query('action') action?: string,
    @Query('actorId') actorId?: string,
  ) {
    return this.audit.list(user.companyId, {
      page: Math.max(1, Number(page ?? 1)),
      pageSize: Math.min(200, Math.max(1, Number(pageSize ?? 50))),
      action,
      actorId,
    });
  }
}

@Module({
  providers: [AuditService],
  controllers: [AuditController],
  exports: [AuditService],
})
export class AuditModule {}
