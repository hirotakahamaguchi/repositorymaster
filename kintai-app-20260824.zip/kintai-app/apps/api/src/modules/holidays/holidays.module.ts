import { Body, Controller, Delete, Get, HttpCode, Inject, Module, Param, Post, Query } from '@nestjs/common';
import { and, asc, eq, gte, lte } from 'drizzle-orm';
import { UpsertHolidaySchema, type HolidayDto, type UpsertHolidayInput } from '@kintai/shared';
import { DB } from '../../db/db.module';
import type { Db } from '../../db/client';
import { holidays } from '../../db/schema';
import { CurrentUser, RequirePermissions } from '../../common/decorators';
import { zodBody } from '../../common/zod.pipe';
import type { AuthUser } from '../../common/auth-user';
import { AuditService } from '../audit/audit.service';
import { AuditModule } from '../audit/audit.module';
import { AttendanceCore } from '../attendance/core';
import { nowLocalDate } from '../../domain/time';

@Controller('holidays')
export class HolidaysController {
  constructor(
    @Inject(DB) private readonly db: Db,
    private readonly audit: AuditService,
  ) {}

  @Get()
  async list(@CurrentUser() user: AuthUser, @Query('year') year?: string): Promise<HolidayDto[]> {
    const y = year ?? nowLocalDate(user.timezone).slice(0, 4);
    const rows = await this.db
      .select()
      .from(holidays)
      .where(and(eq(holidays.companyId, user.companyId), gte(holidays.date, `${y}-01-01`), lte(holidays.date, `${y}-12-31`)))
      .orderBy(asc(holidays.date));
    return rows.map((r) => ({ id: r.id, date: r.date, name: r.name, kind: r.kind as 'NATIONAL' | 'COMPANY' }));
  }

  @Post()
  @RequirePermissions('master:write:company')
  async upsert(@CurrentUser() user: AuthUser, @Body(zodBody(UpsertHolidaySchema)) body: UpsertHolidayInput): Promise<HolidayDto> {
    const [row] = await this.db
      .insert(holidays)
      .values({ companyId: user.companyId, date: body.date, name: body.name, kind: body.kind })
      .onConflictDoUpdate({ target: [holidays.companyId, holidays.date], set: { name: body.name, kind: body.kind } })
      .returning();
    await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'holiday.upserted', targetType: 'holiday', targetId: row.id, detail: body });
    await this.recalcIfPast(user, body.date);
    return { id: row.id, date: row.date, name: row.name, kind: row.kind as 'NATIONAL' | 'COMPANY' };
  }

  @Delete(':id')
  @RequirePermissions('master:write:company')
  @HttpCode(204)
  async remove(@CurrentUser() user: AuthUser, @Param('id') id: string) {
    const [row] = await this.db.delete(holidays).where(and(eq(holidays.id, id), eq(holidays.companyId, user.companyId))).returning();
    if (row) {
      await this.audit.log({ companyId: user.companyId, actorId: user.id, action: 'holiday.deleted', targetType: 'holiday', targetId: id, detail: { date: row.date } });
      await this.recalcIfPast(user, row.date);
    }
  }

  private async recalcIfPast(user: AuthUser, date: string) {
    const today = nowLocalDate(user.timezone);
    if (date <= today) void new AttendanceCore(this.db).recalcCompanyRange(user.companyId, date, date).catch(() => undefined);
  }
}

@Module({ imports: [AuditModule], controllers: [HolidaysController] })
export class HolidaysModule {}
