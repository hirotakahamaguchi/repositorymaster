# Web フロントエンド 実装ガイド（ページ実装者向け）

## スタック / 規約
- Next.js 16 (App Router, `src/app`), React 19, TypeScript strict, Tailwind CSS v4, lucide-react アイコン。
- 全ページは **Client Component** (`"use client"`)。データ取得はクライアント側で `/api/*`（Next の rewrite で NestJS に転送、Cookie 認証）。
- 共有型・zod スキーマ・ラベルは `@kintai/shared` から import（`packages/shared/src/*.ts` を参照）。
  - 型: `AttendanceDayDto`, `AttendanceMonthSummary`, `RequestDto`, `EmployeeDto`, `DepartmentDto`, `WorkPatternDto`, `HolidayDto`, `MonthlyClosingDto`, `AuditLogDto`, `AdminDashboardDto`, `LeaveBalanceDto`, `Paginated<T>` など
  - ラベル: `REQUEST_TYPE_LABEL`, `REQUEST_STATUS_LABEL`, `DAY_TYPE_LABEL`, `LEAVE_TYPE_LABEL`, `ROLE_LABEL`, `WORK_PATTERN_TYPE_LABEL`, `PUNCH_TYPE_LABEL`
  - スキーマ: `CreateRequestSchema`, `CorrectAttendanceSchema`, `UpsertEmployeeSchema`, `UpsertWorkPatternSchema`, `WorkPatternRulesSchema`, `UpsertHolidaySchema`, `GrantLeaveSchema`, `CompanySettingsSchema`, `CloseMonthSchema`
- 既存ユーティリティ（必ずこれを使う。新規に同等のものを作らない）
  - `@/lib/api` : `api.get/post/put/patch/delete/blob`, `errorMessage(e)`, `ApiRequestError`
  - `@/lib/use-api` : `useApi<T>(path | null, query?)` → `{ data, error, loading, reload }`、`useAction(fn)` → `{ run, pending, error }`
  - `@/lib/auth` : `useAuth()` → `{ user, can(...perms), logout }`
  - `@/lib/format` : `fmtTime(iso)`, `fmtDateTime`, `fmtDate(YYYY-MM-DD)`, `fmtDateShort`, `fmtYearMonth`, `minutesToHm`, `todayLocal()`, `currentYearMonth()`, `localToIso(date, 'HH:mm')`, `isoToHm(iso)`, `weekdayOf`
  - `@/lib/utils` : `cn()`, `uuid()`
  - UI: `@/components/ui/button` (`Button` variant: primary|secondary|outline|ghost|danger|success, size: sm|md|lg|xl|icon, `loading`)、
    `@/components/ui/card` (`Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter`)、
    `@/components/ui/input` (`Input, Select, Textarea, Label, Field, Checkbox`)、
    `@/components/ui/badge` (`Badge tone=gray|blue|green|amber|red|violet|sky`, `RequestStatusBadge`, `AttendanceStatusBadge`, `DayTypeBadge`, `FlagBadges`, `FLAG_LABEL`)、
    `@/components/ui/dialog` (`Dialog open onClose title description footer size`, `ConfirmDialog`)、
    `@/components/ui/table` (`Table, THead, TBody, TR, TH, TD`)、
    `@/components/ui/misc` (`Loading, Spinner, PageHeader, EmptyState, Alert tone, Stat, MonthNav, Tabs, Pagination`)、
    `@/components/ui/toast` (`useToast()` → `success/error/toast`)
- レイアウトは `src/app/(app)/layout.tsx` が認証ガード + サイドバーを提供済み。ページは `src/app/(app)/<route>/page.tsx` に置く。
- 日時: API は UTC ISO 文字列。表示は `fmtTime` 等（Asia/Tokyo）。入力フォームでは `type="time"` + `localToIso(date, hm)` で変換。
- 日付文字列 `YYYY-MM-DD`、年月 `YYYY-MM`。
- エラーは `useToast().error(errorMessage(e))` で表示。成功は `success(...)`。
- 見た目: 白カード + slate 系、丸み大きめ（rounded-2xl）、モバイル幅でも崩れない（テーブルは `Table` が横スクロール）。
- 参考実装: `src/app/(app)/page.tsx`（ダッシュボード）, `src/components/punch-card.tsx`, `src/app/login/page.tsx`

## API 一覧（Nest, `/api` プレフィックスで呼ぶ。例: `api.get('/attendance/me', { month })`）
認証: `POST /auth/login`, `POST /auth/logout`, `GET /auth/me`, `POST /auth/password {currentPassword,newPassword}`
会社: `GET /company/settings`, `PUT /company/settings (CompanySettings)`
従業員: `GET /employees?page&pageSize&q&departmentId&includeRetired` → Paginated<EmployeeDto>, `GET /employees/:id`, `POST /employees (UpsertEmployeeInput)`, `PUT /employees/:id`
部署: `GET /departments` → DepartmentDto[], `POST /departments`, `PUT /departments/:id`, `DELETE /departments/:id`; `GET /roles`
勤務パターン: `GET /work-patterns` → WorkPatternDto[], `POST /work-patterns`, `PUT /work-patterns/:id`, `DELETE /work-patterns/:id`,
  `GET /work-patterns/assignments?employeeId` → WorkPatternAssignmentDto[], `POST /work-patterns/assignments {employeeId, workPatternId, validFrom, validTo?}`, `DELETE /work-patterns/assignments/:id`
休日: `GET /holidays?year` → HolidayDto[], `POST /holidays {date,name,kind}`, `DELETE /holidays/:id`
打刻: `POST /punches`, `GET /punches?employeeId&from(ISO)&to(ISO)` → PunchDto[]
勤怠: `GET /attendance/me?month` → {yearMonth, days: AttendanceDayDto[], summary: AttendanceMonthSummary}
  `GET /attendance/employees/:employeeId?month` → 同上（管理者）
  `GET /attendance/company?month&departmentId&date&flagged=true` → AttendanceDayDto[]（employeeName/employeeCode/departmentName 付き）
  `GET /attendance/company/summary?month&departmentId` → AttendanceMonthSummary[]（employeeName/employeeCode/departmentName 付き）
  `GET /attendance/days/:id/revisions` → AttendanceRevisionDto[]
  `PATCH /attendance/days/:id (CorrectAttendanceInput: clockInAt?, clockOutAt?, breakMinutes?, dayType?, note?, reason, version)` → AttendanceDayDto（409 = 競合）
  `POST /attendance/days/:id/reset-manual {reason}`; `POST /attendance/employees/:employeeId/confirm?month`; `POST /attendance/recalc {employeeId?, from, to}`
申請: `GET /requests/mine?page&pageSize&status` → Paginated<RequestDto>; `GET /requests/inbox?page&pageSize&status&requestType&onlyMine=true` → Paginated<RequestDto>（canDecide 付き）
  `GET /requests/:id`; `POST /requests (CreateRequestInput)`; `POST /requests/:id/decide {decision:'APPROVED'|'REJECTED', comment?}`; `POST /requests/:id/withdraw`
休暇: `GET /leaves/balances?employeeId` → LeaveBalanceDto[]; `GET /leaves/grants?employeeId`; `GET /leaves/usages?employeeId`; `POST /leaves/grants (GrantLeaveInput)`; `DELETE /leaves/grants/:id`
締め: `GET /closings?month` → MonthlyClosingDto[]; `POST /closings {yearMonth, employeeIds?}  (?force=true)` → {closed:number, blocked:[{employeeId,name,alerts}]}
  `POST /closings/:month/reopen/:employeeId`; `GET /closings/exports`; `GET /closings/csv?month&encoding=utf8|sjis&departmentId&lockedOnly=true` → CSV バイナリ（`api.blob` を使い、`URL.createObjectURL` でダウンロード）
ダッシュボード: `GET /dashboard/me` → DashboardDto; `GET /dashboard/admin` → AdminDashboardDto
監査: `GET /audit-logs?page&pageSize&action&actorId` → Paginated<AuditLogDto>

## 権限（`useAuth().can(...)`）
`attendance:read:self|department|company`, `attendance:write:department|company`, `punch:create:self|admin`, `request:create:self`, `request:approve:department|company`,
`employee:read:company`, `employee:write:company`, `master:write:company`, `closing:execute:company`, `export:csv:company`, `audit:read:company`
