"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Clock } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { errorMessage } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { Alert } from "@/components/ui/misc";

const DEMO_ACCOUNTS = [
  { email: "admin@example.com", label: "システム管理者" },
  { email: "hr@example.com", label: "労務担当" },
  { email: "manager@example.com", label: "管理職（開発1課）" },
  { email: "employee@example.com", label: "一般社員" },
];

function LoginForm() {
  const { login, user, loading } = useAuth();
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next") ?? "/";
  const [email, setEmail] = useState("employee@example.com");
  const [password, setPassword] = useState("password123");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  useEffect(() => {
    if (!loading && user) router.replace(next);
  }, [loading, user, next, router]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPending(true);
    setError(null);
    try {
      await login(email, password);
      router.replace(next);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setPending(false);
    }
  };

  return (
    <div className="w-full max-w-md">
      <div className="mb-8 flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-sky-500/20 ring-1 ring-sky-400/40">
          <Clock className="h-6 w-6 text-sky-300" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">勤怠管理</h1>
          <p className="text-sm text-slate-400">出退勤打刻・勤怠照会・申請承認</p>
        </div>
      </div>
      <form onSubmit={submit} className="space-y-4 rounded-2xl bg-white p-6 shadow-xl">
        <Field label="メールアドレス">
          <Input type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </Field>
        <Field label="パスワード">
          <Input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </Field>
        {error && <Alert tone="error">{error}</Alert>}
        <Button type="submit" className="w-full" size="lg" loading={pending}>
          ログイン
        </Button>
        <div className="rounded-xl bg-slate-50 p-3 text-xs text-slate-600">
          <p className="mb-2 font-medium">デモアカウント（パスワード: password123）</p>
          <div className="grid grid-cols-2 gap-1.5">
            {DEMO_ACCOUNTS.map((a) => (
              <button
                type="button"
                key={a.email}
                onClick={() => {
                  setEmail(a.email);
                  setPassword("password123");
                }}
                className="rounded-lg border bg-white px-2 py-1.5 text-left hover:border-brand-500 hover:bg-brand-50"
              >
                <span className="block font-medium text-slate-800">{a.label}</span>
                <span className="block truncate text-[10px] text-slate-500">{a.email}</span>
              </button>
            ))}
          </div>
        </div>
      </form>
      <p className="mt-6 text-center text-xs text-slate-500">本番環境では SSO (SAML/OIDC) によるログインに置き換えます</p>
    </div>
  );
}

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 via-slate-900 to-sky-950 px-4 py-10">
      <Suspense>
        <LoginForm />
      </Suspense>
    </div>
  );
}
