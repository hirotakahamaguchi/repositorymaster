"use client";

import { Suspense, useCallback } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { addMonths } from "@kintai/shared";
import { useAuth } from "@/lib/auth";
import { currentYearMonth } from "@/lib/format";
import { Alert, Loading, MonthNav, PageHeader } from "@/components/ui/misc";
import { ClosingsStatusSection } from "@/components/admin/closings-status";
import { ClosingsCsvSection } from "@/components/admin/closings-csv";

const YM_RE = /^\d{4}-(0[1-9]|1[0-2])$/;

function ClosingsPageInner() {
  const { can } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const sp = useSearchParams();

  const paramMonth = sp.get("month");
  const month = paramMonth && YM_RE.test(paramMonth) ? paramMonth : addMonths(currentYearMonth(), -1);

  const setMonth = useCallback(
    (ym: string) => {
      const next = new URLSearchParams(sp.toString());
      next.set("month", ym);
      router.replace(`${pathname}?${next.toString()}`);
    },
    [router, pathname, sp],
  );

  const canClose = can("closing:execute:company");
  const canExport = can("export:csv:company");

  return (
    <div className="space-y-6">
      <PageHeader title="月次締め・CSV出力" description="月次の勤怠を確定し、給与システム向けの CSV を出力します。" actions={<MonthNav value={month} onChange={setMonth} />} />

      {!canClose && !canExport && <Alert tone="warning">このページを閲覧する権限がありません。</Alert>}

      {canClose && <ClosingsStatusSection month={month} />}
      {canExport && <ClosingsCsvSection month={month} />}
    </div>
  );
}

export default function ClosingsPage() {
  return (
    <Suspense fallback={<Loading />}>
      <ClosingsPageInner />
    </Suspense>
  );
}
