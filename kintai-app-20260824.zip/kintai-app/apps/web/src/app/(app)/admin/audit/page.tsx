"use client";

import { Suspense, useMemo, useState } from "react";
import { ChevronDown, ChevronRight, RefreshCw, ScrollText, Search } from "lucide-react";
import type { AuditLogDto, Paginated } from "@kintai/shared";
import { useApi } from "@/lib/use-api";
import { fmtDateTimeFull } from "@/lib/format";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input, Select } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, EmptyState, Loading, PageHeader, Pagination } from "@/components/ui/misc";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";

const PAGE_SIZE = 50;

/** アクション接頭辞（カテゴリ）→ 表示名 */
const ACTION_PREFIXES: { value: string; label: string }[] = [
  { value: "", label: "すべてのアクション" },
  { value: "auth.", label: "認証" },
  { value: "punch.", label: "打刻" },
  { value: "attendance.", label: "勤怠" },
  { value: "request.", label: "申請" },
  { value: "closing.", label: "月次締め" },
  { value: "export.", label: "CSV出力" },
  { value: "employee.", label: "従業員" },
  { value: "work_pattern.", label: "勤務パターン" },
  { value: "holiday.", label: "休日" },
  { value: "leave.", label: "休暇" },
  { value: "company.", label: "会社設定" },
  { value: "department.", label: "部署" },
];

/** 既知アクションの日本語ラベル */
const ACTION_LABEL: Record<string, string> = {
  "auth.login": "ログイン",
  "auth.logout": "ログアウト",
  "auth.password_changed": "パスワード変更",
  "punch.created": "打刻",
  "punch.proxy_created": "代理打刻",
  "attendance.corrected": "勤怠修正",
  "attendance.reset_manual": "手修正リセット",
  "attendance.month_confirmed": "月次確認",
  "attendance.recalculated": "再計算",
  "request.created": "申請作成",
  "request.approved": "申請承認",
  "request.rejected": "申請却下",
  "request.withdrawn": "申請取下げ",
  "closing.executed": "月次締め実行",
  "closing.reopened": "締め解除",
  "export.csv": "CSV出力",
  "employee.created": "従業員登録",
  "employee.updated": "従業員更新",
  "work_pattern.created": "勤務パターン作成",
  "work_pattern.updated": "勤務パターン更新",
  "work_pattern.deleted": "勤務パターン削除",
  "work_pattern.assigned": "勤務パターン割当",
  "work_pattern.unassigned": "勤務パターン割当解除",
  "holiday.upserted": "休日登録",
  "holiday.deleted": "休日削除",
  "leave.granted": "休暇付与",
  "leave.grant_revoked": "休暇付与取消",
  "company.settings_updated": "会社設定更新",
  "department.upserted": "部署登録・更新",
  "department.deleted": "部署削除",
};

const TARGET_TYPE_LABEL: Record<string, string> = {
  employee: "従業員",
  attendance_day: "勤怠日",
  request: "申請",
  month: "対象月",
  punch: "打刻",
  work_pattern: "勤務パターン",
  holiday: "休日",
  leave_grant: "休暇付与",
  department: "部署",
  company: "会社",
};

type Tone = "gray" | "blue" | "green" | "amber" | "red" | "violet" | "sky";
function actionTone(action: string): Tone {
  if (action.startsWith("auth.")) return "sky";
  if (action.startsWith("punch.")) return "blue";
  if (action.startsWith("attendance.")) return "amber";
  if (action.startsWith("request.")) return action.endsWith("rejected") ? "red" : "green";
  if (action.startsWith("closing.") || action.startsWith("export.")) return "violet";
  if (action.endsWith(".deleted") || action.endsWith("revoked")) return "red";
  return "gray";
}

function truncate(s: string, n: number) {
  return s.length > n ? `${s.slice(0, n)}…` : s;
}

function compactJson(v: Record<string, unknown> | null): string {
  if (!v) return "";
  try {
    return JSON.stringify(v);
  } catch {
    return String(v);
  }
}

function AuditPageInner() {
  const [prefix, setPrefix] = useState("");
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());

  const { data, error, loading, reload } = useApi<Paginated<AuditLogDto>>("/audit-logs", {
    page,
    pageSize: PAGE_SIZE,
    action: prefix || undefined,
  });

  const items = useMemo(() => {
    const list = data?.items ?? [];
    const kw = q.trim().toLowerCase();
    if (!kw) return list;
    return list.filter((l) => {
      const hay = [l.actorName ?? "", l.action, ACTION_LABEL[l.action] ?? "", l.targetType, l.targetId ?? "", l.ip ?? "", compactJson(l.detail)].join(" ").toLowerCase();
      return hay.includes(kw);
    });
  }, [data, q]);

  const toggle = (id: string) =>
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  return (
    <div className="space-y-5">
      <PageHeader
        title="監査ログ"
        description="ログイン・打刻・勤怠修正・申請・締めなど、システム上の操作履歴です。"
        actions={
          <Button variant="outline" size="sm" onClick={() => void reload()} loading={loading}>
            {!loading && <RefreshCw className="h-3.5 w-3.5" />}
            更新
          </Button>
        }
      />

      <Card>
        <CardContent className="pt-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <Select
              className="sm:w-56"
              value={prefix}
              onChange={(e) => {
                setPrefix(e.target.value);
                setPage(1);
                setExpanded(new Set());
              }}
              aria-label="アクション種別"
            >
              {ACTION_PREFIXES.map((p) => (
                <option key={p.value} value={p.value}>
                  {p.label}
                  {p.value ? ` (${p.value}*)` : ""}
                </option>
              ))}
            </Select>
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <Input className="pl-9" placeholder="操作者・対象ID・詳細で絞り込み（表示中のページ内）" value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
          </div>
        </CardContent>
      </Card>

      {loading && !data ? (
        <Loading />
      ) : error && !data ? (
        <Alert tone="error">{error}</Alert>
      ) : !data || data.items.length === 0 ? (
        <EmptyState title="監査ログはありません" description={prefix ? "条件に一致するログがありません。" : undefined} />
      ) : (
        <Card>
          <CardContent className="px-0 pb-2 pt-0">
            <Table>
              <THead>
                <TR>
                  <TH className="w-8" />
                  <TH>日時</TH>
                  <TH>操作者</TH>
                  <TH>アクション</TH>
                  <TH>対象</TH>
                  <TH>詳細</TH>
                  <TH>IP</TH>
                </TR>
              </THead>
              <TBody>
                {items.length === 0 && (
                  <TR>
                    <TD colSpan={7} className="py-8 text-center text-xs text-slate-500">
                      「{q}」に一致するログはこのページにありません
                    </TD>
                  </TR>
                )}
                {items.map((l) => {
                  const json = compactJson(l.detail);
                  const isOpen = expanded.has(l.id);
                  const hasDetail = !!l.detail && Object.keys(l.detail).length > 0;
                  return (
                    <AuditRow key={l.id} log={l} json={json} open={isOpen} hasDetail={hasDetail} onToggle={() => toggle(l.id)} />
                  );
                })}
              </TBody>
            </Table>
            <div className="px-4">
              <Pagination page={data.page} pageSize={data.pageSize} total={data.total} onChange={(p) => { setPage(p); setExpanded(new Set()); }} />
            </div>
          </CardContent>
        </Card>
      )}

      {data && data.total > 0 && (
        <p className="flex items-center gap-1 text-xs text-slate-400">
          <ScrollText className="h-3 w-3" /> 全 {data.total} 件 · {PAGE_SIZE} 件ずつ表示
        </p>
      )}
    </div>
  );
}

function AuditRow({ log, json, open, hasDetail, onToggle }: { log: AuditLogDto; json: string; open: boolean; hasDetail: boolean; onToggle: () => void }) {
  const label = ACTION_LABEL[log.action];
  return (
    <>
      <TR className={cn(open && "bg-slate-50/60")}>
        <TD>
          {hasDetail && (
            <button type="button" onClick={onToggle} className="rounded p-0.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600" aria-label={open ? "詳細を閉じる" : "詳細を開く"} aria-expanded={open}>
              {open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            </button>
          )}
        </TD>
        <TD className="tabular whitespace-nowrap text-xs text-slate-600">{fmtDateTimeFull(log.createdAt)}</TD>
        <TD className="whitespace-nowrap text-slate-900">{log.actorName ?? <span className="text-slate-400">system</span>}</TD>
        <TD>
          <div className="flex flex-col gap-0.5">
            <span className="flex items-center gap-1.5">
              <Badge tone={actionTone(log.action)}>{label ?? log.action.split(".")[0]}</Badge>
            </span>
            <span className="font-mono text-[11px] text-slate-500">{log.action}</span>
          </div>
        </TD>
        <TD className="whitespace-nowrap">
          <span className="text-xs text-slate-600">{TARGET_TYPE_LABEL[log.targetType] ?? log.targetType}</span>
          {log.targetId && (
            <span className="ml-1 font-mono text-[11px] text-slate-500" title={log.targetId}>
              {truncate(log.targetId, 12)}
            </span>
          )}
        </TD>
        <TD className="max-w-[16rem]">
          {hasDetail ? (
            <button type="button" onClick={onToggle} className="block max-w-full truncate text-left font-mono text-[11px] text-slate-600 hover:text-brand-600" title="クリックで展開">
              {truncate(json, 80)}
            </button>
          ) : (
            <span className="text-xs text-slate-400">-</span>
          )}
        </TD>
        <TD className="tabular whitespace-nowrap text-xs text-slate-500">{log.ip ?? "-"}</TD>
      </TR>
      {open && hasDetail && (
        <TR className="bg-slate-50/60 hover:bg-slate-50/60">
          <TD />
          <TD colSpan={6} className="py-2">
            <pre className="max-h-72 overflow-auto whitespace-pre-wrap break-all rounded-lg border bg-white px-3 py-2 font-mono text-[11px] leading-relaxed text-slate-700">{JSON.stringify(log.detail, null, 2)}</pre>
          </TD>
        </TR>
      )}
    </>
  );
}

export default function AuditPage() {
  return (
    <Suspense fallback={<Loading />}>
      <AuditPageInner />
    </Suspense>
  );
}
