"use client";

import { useState } from "react";
import { Briefcase, Pencil, Plus, Trash2, Users } from "lucide-react";
import type { WorkPatternDto, WorkPatternType } from "@kintai/shared";
import { WEEKDAY_JA, WORK_PATTERN_TYPE_LABEL, minutesToHm } from "@kintai/shared";
import { useAuth } from "@/lib/auth";
import { api, errorMessage } from "@/lib/api";
import { useApi } from "@/lib/use-api";
import { fmtDate } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ConfirmDialog } from "@/components/ui/dialog";
import { Alert, EmptyState, Loading, PageHeader } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { ROUNDING_MODE_LABEL, WorkPatternDialog } from "@/components/admin/work-pattern-dialog";

function typeTone(t: WorkPatternType): "gray" | "blue" | "green" | "amber" | "violet" {
  switch (t) {
    case "FIXED":
      return "blue";
    case "SHIFT":
      return "amber";
    case "FLEX":
      return "green";
    case "DISCRETIONARY":
      return "violet";
    default:
      return "gray";
  }
}

function RuleRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 text-sm">
      <span className="shrink-0 text-xs text-slate-500">{label}</span>
      <span className="text-right text-slate-800">{children}</span>
    </div>
  );
}

function roundingText(r: { unitMinutes: number; mode: string }): string {
  if (r.mode === "NONE" || r.unitMinutes <= 1) return "なし";
  return `${r.unitMinutes}分 ${ROUNDING_MODE_LABEL[r.mode as keyof typeof ROUNDING_MODE_LABEL] ?? r.mode}`;
}

export default function WorkPatternsPage() {
  const { can } = useAuth();
  const canWrite = can("master:write:company");
  const toast = useToast();
  const { data, loading, error, reload } = useApi<WorkPatternDto[]>("/work-patterns");

  const [dialog, setDialog] = useState<{ open: boolean; pattern: WorkPatternDto | null }>({ open: false, pattern: null });
  const [deleting, setDeleting] = useState<WorkPatternDto | null>(null);
  const [deletePending, setDeletePending] = useState(false);

  const remove = async () => {
    if (!deleting) return;
    setDeletePending(true);
    try {
      await api.delete(`/work-patterns/${deleting.id}`);
      toast.success("勤務パターンを削除しました");
      setDeleting(null);
      await reload();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setDeletePending(false);
    }
  };

  return (
    <div>
      <PageHeader
        title="勤務パターン"
        description="所定時間・休憩・丸め・労働日などのルールを定義し、従業員へ割り当てます"
        actions={
          canWrite ? (
            <Button onClick={() => setDialog({ open: true, pattern: null })}>
              <Plus className="h-4 w-4" /> 新規作成
            </Button>
          ) : undefined
        }
      />

      {loading && !data ? (
        <Loading />
      ) : error && !data ? (
        <Alert tone="error">{error}</Alert>
      ) : !data || data.length === 0 ? (
        <EmptyState
          title="勤務パターンがありません"
          description="まず勤務パターンを作成し、従業員に割り当ててください"
          action={
            canWrite ? (
              <Button size="sm" onClick={() => setDialog({ open: true, pattern: null })}>
                <Plus className="h-4 w-4" /> 新規作成
              </Button>
            ) : undefined
          }
        />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {data.map((wp) => {
            const r = wp.rules;
            const timed = wp.patternType === "FIXED" || wp.patternType === "SHIFT";
            const flex = wp.patternType === "FLEX";
            const workdays = [...(r.workdays ?? [])].sort((a, b) => a - b).map((d) => WEEKDAY_JA[d]).join("");
            return (
              <Card key={wp.id} className="flex flex-col">
                <CardHeader className="items-start">
                  <div className="min-w-0">
                    <CardTitle className="flex items-center gap-2">
                      <Briefcase className="h-4 w-4 shrink-0 text-brand-600" />
                      <span className="truncate">{wp.name}</span>
                    </CardTitle>
                    <p className="mt-0.5 text-xs text-slate-500">{wp.code}</p>
                  </div>
                  <Badge tone={typeTone(wp.patternType)}>{WORK_PATTERN_TYPE_LABEL[wp.patternType]}</Badge>
                </CardHeader>
                <CardContent className="flex-1 space-y-1.5">
                  {timed && (
                    <RuleRow label="所定時間">
                      <span className="tabular">
                        {r.start ?? "--:--"} – {r.end ?? "--:--"}
                      </span>
                    </RuleRow>
                  )}
                  {flex && (
                    <>
                      <RuleRow label="コアタイム">
                        <span className="tabular">{r.coreStart && r.coreEnd ? `${r.coreStart} – ${r.coreEnd}` : "なし"}</span>
                      </RuleRow>
                      <RuleRow label="フレキシブル">
                        <span className="tabular">{r.flexStart && r.flexEnd ? `${r.flexStart} – ${r.flexEnd}` : "-"}</span>
                      </RuleRow>
                    </>
                  )}
                  <RuleRow label="所定労働">
                    <span className="tabular">{minutesToHm(r.scheduledMinutes)}</span>
                  </RuleRow>
                  <RuleRow label="休憩">
                    {r.breaks && r.breaks.length > 0 ? (
                      <span className="tabular">{r.breaks.map((b) => `${b.from}–${b.to}`).join(", ")}</span>
                    ) : (
                      <span className="text-slate-400">固定なし</span>
                    )}
                    {r.enforceLegalBreak && <span className="ml-1 text-[10px] text-slate-500">(法定休憩自動控除)</span>}
                  </RuleRow>
                  <RuleRow label="丸め(出/退)">
                    <span className="tabular">
                      {roundingText(r.roundingIn)} / {roundingText(r.roundingOut)}
                    </span>
                  </RuleRow>
                  <RuleRow label="所定労働日">
                    <span>{workdays || <span className="text-slate-400">なし</span>}</span>
                    <span className="ml-1 text-[10px] text-slate-500">(法定休日: {WEEKDAY_JA[r.legalHolidayWeekday ?? 0]})</span>
                  </RuleRow>
                  <RuleRow label="残業基準">{r.overtimeBasis === "SCHEDULED" ? "所定超" : "法定超(8h)"}</RuleRow>
                  <RuleRow label="日付境界">
                    <span className="tabular">{r.dayBoundary}</span>
                  </RuleRow>
                  <RuleRow label="有効期間">
                    <span className="tabular">
                      {fmtDate(wp.validFrom)} 〜 {wp.validTo ? fmtDate(wp.validTo) : ""}
                    </span>
                  </RuleRow>
                </CardContent>
                <CardFooter className="justify-between">
                  <span className="inline-flex items-center gap-1 text-xs text-slate-600">
                    <Users className="h-3.5 w-3.5" /> 割当 <b className="tabular">{wp.assignedCount}</b> 名
                  </span>
                  <div className="flex items-center gap-1">
                    <Button size="sm" variant="outline" onClick={() => setDialog({ open: true, pattern: wp })}>
                      <Pencil className="h-3.5 w-3.5" /> {canWrite ? "編集" : "詳細"}
                    </Button>
                    {canWrite && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-rose-600 hover:bg-rose-50"
                        disabled={wp.assignedCount > 0}
                        title={wp.assignedCount > 0 ? "割当中の従業員がいるため削除できません" : "削除"}
                        onClick={() => setDeleting(wp)}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    )}
                  </div>
                </CardFooter>
              </Card>
            );
          })}
        </div>
      )}

      <WorkPatternDialog open={dialog.open} onClose={() => setDialog((d) => ({ ...d, open: false }))} pattern={dialog.pattern} canWrite={canWrite} onSaved={() => void reload()} />

      <ConfirmDialog
        open={!!deleting}
        onClose={() => setDeleting(null)}
        onConfirm={() => void remove()}
        title="勤務パターンを削除"
        message={deleting ? `「${deleting.name}」（${deleting.code}）を削除します。この操作は取り消せません。` : ""}
        confirmLabel="削除"
        danger
        pending={deletePending}
      />
    </div>
  );
}
