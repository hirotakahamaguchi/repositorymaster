"use client";

import Link from "next/link";
import { ArrowRight, CalendarRange, CheckCircle2, ClipboardCheck, FileSpreadsheet, Flame, Lock, RefreshCw, Users } from "lucide-react";
import type { AdminDashboardDto } from "@kintai/shared";
import { useAuth } from "@/lib/auth";
import { useApi } from "@/lib/use-api";
import { fmtDate, fmtYearMonth, minutesToHm } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, Loading, PageHeader, Stat } from "@/components/ui/misc";
import { Badge, FlagBadges } from "@/components/ui/badge";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";

function EmptyOk({ message }: { message: string }) {
  return (
    <div className="flex items-center gap-2 rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
      <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />
      {message}
    </div>
  );
}

export default function AdminDashboardPage() {
  const { can } = useAuth();
  const { data, error, loading, reload } = useApi<AdminDashboardDto>("/dashboard/admin");

  if (loading && !data) return <Loading />;
  if (error && !data) return <Alert tone="error">{error}</Alert>;
  if (!data) return null;

  const quickLinks = [
    { href: "/admin/attendance", label: "勤怠管理", icon: CalendarRange, desc: "日次・月次の勤怠を確認・修正", show: true },
    { href: "/admin/employees", label: "従業員", icon: Users, desc: "従業員・勤務パターンの管理", show: can("employee:read:company") },
    { href: "/admin/closings", label: "月次締め・CSV", icon: FileSpreadsheet, desc: "締め処理と給与CSV出力", show: can("closing:execute:company", "export:csv:company") },
  ].filter((l) => l.show);

  return (
    <div className="space-y-6">
      <PageHeader
        title="管理ダッシュボード"
        description={`${fmtDate(data.date)} 時点の状況`}
        actions={
          <Button variant="outline" size="sm" onClick={() => void reload()} loading={loading}>
            {!loading && <RefreshCw className="h-3.5 w-3.5" />}
            更新
          </Button>
        }
      />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <Stat label="在籍" value={`${data.headcount}`} sub="名" />
        <Stat label="出勤中" value={`${data.presentCount}`} sub="名" tone="good" />
        <Stat label="退勤済" value={`${data.leftCount}`} sub="名" />
        <Stat label="未出勤" value={`${data.notYetCount}`} sub="名" tone={data.notYetCount > 0 ? "warn" : "default"} />
        <Stat label="休暇中" value={`${data.onLeaveCount}`} sub="名" />
        <Link href="/approvals" className="group block">
          <Stat
            label="承認待ち"
            value={`${data.pendingApprovals}`}
            sub={
              <span className="inline-flex items-center gap-1 text-brand-600 group-hover:underline">
                承認へ <ArrowRight className="h-3 w-3" />
              </span>
            }
            tone={data.pendingApprovals > 0 ? "warn" : "default"}
            className="h-full transition-colors group-hover:border-brand-300"
          />
        </Link>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Flame className="h-4 w-4 text-amber-500" /> 残業アラート（今月）
            </CardTitle>
            <span className="text-xs text-slate-500">{data.overtimeAlerts.length} 名</span>
          </CardHeader>
          <CardContent>
            {data.overtimeAlerts.length === 0 ? (
              <EmptyOk message="アラートはありません" />
            ) : (
              <Table>
                <THead>
                  <TR>
                    <TH>氏名</TH>
                    <TH className="text-right">法定外残業</TH>
                    <TH>レベル</TH>
                    <TH />
                  </TR>
                </THead>
                <TBody>
                  {data.overtimeAlerts.map((a) => (
                    <TR key={a.employeeId}>
                      <TD className="font-medium text-slate-900">
                        <Link href={`/admin/attendance/${a.employeeId}`} className="hover:underline">
                          {a.name}
                        </Link>
                      </TD>
                      <TD className={`tabular text-right font-semibold ${a.level === "LIMIT" ? "text-rose-600" : "text-amber-600"}`}>{minutesToHm(a.overtimeMinutes)}</TD>
                      <TD>{a.level === "LIMIT" ? <Badge tone="red">80h超</Badge> : <Badge tone="amber">45h超</Badge>}</TD>
                      <TD className="text-right">
                        <Link href={`/admin/attendance/${a.employeeId}`} className="inline-flex items-center gap-1 text-xs text-brand-600 hover:underline">
                          詳細 <ArrowRight className="h-3 w-3" />
                        </Link>
                      </TD>
                    </TR>
                  ))}
                </TBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ClipboardCheck className="h-4 w-4 text-rose-500" /> 打刻漏れ・要確認（直近14日）
            </CardTitle>
            <span className="text-xs text-slate-500">{data.missingPunches.length} 件</span>
          </CardHeader>
          <CardContent>
            {data.missingPunches.length === 0 ? (
              <EmptyOk message="要確認の勤怠はありません" />
            ) : (
              <ul className="divide-y text-sm">
                {data.missingPunches.map((m) => (
                  <li key={`${m.employeeId}-${m.workDate}`}>
                    <Link
                      href={`/admin/attendance/${m.employeeId}?month=${m.workDate.slice(0, 7)}`}
                      className="flex flex-wrap items-center justify-between gap-x-3 gap-y-1 py-2 hover:bg-slate-50/60"
                    >
                      <span className="flex items-center gap-3">
                        <span className="tabular text-xs text-slate-500">{fmtDate(m.workDate)}</span>
                        <span className="font-medium text-slate-900">{m.name}</span>
                      </span>
                      <FlagBadges flags={m.flags} />
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="h-4 w-4 text-violet-500" /> 未締めの月
          </CardTitle>
          {can("closing:execute:company") && (
            <Link href="/admin/closings" className="text-xs text-brand-600 hover:underline">
              月次締めへ →
            </Link>
          )}
        </CardHeader>
        <CardContent>
          {data.unlockedMonths.length === 0 ? (
            <EmptyOk message="未締めの月はありません" />
          ) : (
            <div className="flex flex-wrap gap-2">
              {data.unlockedMonths.map((ym) => (
                <Link
                  key={ym}
                  href={`/admin/closings?month=${ym}`}
                  className="inline-flex items-center gap-1.5 rounded-full border border-violet-200 bg-violet-50 px-3 py-1 text-sm font-medium text-violet-700 hover:bg-violet-100"
                >
                  {fmtYearMonth(ym)}
                  <ArrowRight className="h-3 w-3" />
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {quickLinks.length > 0 && (
        <section>
          <h2 className="mb-3 text-sm font-semibold text-slate-700">クイックリンク</h2>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            {quickLinks.map((l) => (
              <Link key={l.href} href={l.href} className="group">
                <Card className="h-full transition-colors group-hover:border-brand-300">
                  <CardContent className="flex items-center gap-3 pt-4">
                    <l.icon className="h-5 w-5 shrink-0 text-brand-600" />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-900">{l.label}</p>
                      <p className="truncate text-xs text-slate-500">{l.desc}</p>
                    </div>
                    <ArrowRight className="ml-auto h-4 w-4 shrink-0 text-slate-300 group-hover:text-brand-500" />
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
