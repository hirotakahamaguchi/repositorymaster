"use client";

import { useState } from "react";
import { Building2, Clock3, LocateFixed, MapPin, Save } from "lucide-react";
import type { CompanySettings } from "@kintai/shared";
import { CompanySettingsSchema } from "@kintai/shared";
import { useAuth } from "@/lib/auth";
import { api, errorMessage } from "@/lib/api";
import { useApi } from "@/lib/use-api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Field, Input, Select } from "@/components/ui/input";
import { Alert, Loading, PageHeader } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { zodFieldErrors } from "@/components/admin/form-utils";

const TIMEZONES = ["Asia/Tokyo", "Asia/Seoul", "Asia/Shanghai", "Asia/Singapore", "Asia/Bangkok", "Asia/Kolkata", "Europe/London", "Europe/Berlin", "America/New_York", "America/Los_Angeles", "UTC"];

interface SettingsForm {
  name: string;
  timezone: string;
  closingDay: number;
  officeLatitude: string;
  officeLongitude: string;
  geofenceRadiusM: string;
  overtimeAlertHours: string;
  overtimeLimitHours: string;
}

function toForm(s: CompanySettings): SettingsForm {
  return {
    name: s.name,
    timezone: s.timezone ?? "Asia/Tokyo",
    closingDay: s.closingDay ?? 31,
    officeLatitude: s.officeLatitude != null ? String(s.officeLatitude) : "",
    officeLongitude: s.officeLongitude != null ? String(s.officeLongitude) : "",
    geofenceRadiusM: String(s.geofenceRadiusM ?? 300),
    overtimeAlertHours: String(Math.round(((s.overtimeAlertMinutes ?? 45 * 60) / 60) * 10) / 10),
    overtimeLimitHours: String(Math.round(((s.overtimeLimitMinutes ?? 80 * 60) / 60) * 10) / 10),
  };
}

export default function CompanySettingsPage() {
  const { data, loading, error } = useApi<CompanySettings>("/company/settings");
  if (loading && !data) return <Loading />;
  if (error && !data) return <Alert tone="error">{error}</Alert>;
  if (!data) return null;
  return <SettingsFormView initial={data} />;
}

function SettingsFormView({ initial }: { initial: CompanySettings }) {
  const { can, refresh } = useAuth();
  const canWrite = can("master:write:company");
  const toast = useToast();

  const [form, setForm] = useState<SettingsForm>(() => toForm(initial));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);
  const [locating, setLocating] = useState(false);

  const set = <K extends keyof SettingsForm>(k: K, v: SettingsForm[K]) => setForm((f) => ({ ...f, [k]: v }));

  const locate = () => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      toast.error("この端末では位置情報を取得できません");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        set("officeLatitude", pos.coords.latitude.toFixed(6));
        set("officeLongitude", pos.coords.longitude.toFixed(6));
        setLocating(false);
        toast.success(`現在地を取得しました（精度 ±${Math.round(pos.coords.accuracy)}m）`);
      },
      (err) => {
        setLocating(false);
        toast.error(err.code === err.PERMISSION_DENIED ? "位置情報の利用が許可されていません" : "位置情報の取得に失敗しました");
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 },
    );
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canWrite) return;
    const num = (s: string) => (s.trim() === "" ? NaN : Number(s));
    const parsed = CompanySettingsSchema.safeParse({
      name: form.name.trim(),
      timezone: form.timezone,
      closingDay: form.closingDay,
      officeLatitude: form.officeLatitude.trim() === "" ? null : Number(form.officeLatitude),
      officeLongitude: form.officeLongitude.trim() === "" ? null : Number(form.officeLongitude),
      geofenceRadiusM: num(form.geofenceRadiusM),
      overtimeAlertMinutes: Math.round(num(form.overtimeAlertHours) * 60),
      overtimeLimitMinutes: Math.round(num(form.overtimeLimitHours) * 60),
    });
    if (!parsed.success) {
      setErrors(zodFieldErrors(parsed.error));
      toast.error("入力内容を確認してください");
      return;
    }
    if ((parsed.data.officeLatitude == null) !== (parsed.data.officeLongitude == null)) {
      setErrors({ officeLatitude: "緯度・経度は両方入力するか、両方空欄にしてください" });
      return;
    }
    setErrors({});
    setPending(true);
    try {
      const saved = await api.put<CompanySettings>("/company/settings", parsed.data);
      if (saved && typeof saved === "object") setForm(toForm(saved));
      toast.success("会社設定を保存しました");
      void refresh();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setPending(false);
    }
  };

  const geoEnabled = form.officeLatitude.trim() !== "" && form.officeLongitude.trim() !== "";

  return (
    <div>
      <PageHeader title="会社設定" description="会社名・締め日・ジオフェンス・残業アラートの基準を設定します" />

      <form onSubmit={submit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-brand-600" /> 基本
            </CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="会社名" error={errors.name} className="sm:col-span-2 lg:col-span-1">
              <Input value={form.name} onChange={(e) => set("name", e.target.value)} disabled={!canWrite} required maxLength={100} />
            </Field>
            <Field label="タイムゾーン" error={errors.timezone}>
              <Select value={form.timezone} onChange={(e) => set("timezone", e.target.value)} disabled={!canWrite}>
                {(TIMEZONES.includes(form.timezone) ? TIMEZONES : [form.timezone, ...TIMEZONES]).map((tz) => (
                  <option key={tz} value={tz}>
                    {tz}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="締め日" error={errors.closingDay} hint="給与計算の集計期間の末日">
              <Select value={form.closingDay} onChange={(e) => set("closingDay", Number(e.target.value))} disabled={!canWrite}>
                <option value={31}>月末</option>
                {Array.from({ length: 28 }, (_, i) => i + 1).map((d) => (
                  <option key={d} value={d}>
                    {d} 日
                  </option>
                ))}
              </Select>
            </Field>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex-col items-start gap-1">
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-brand-600" /> 勤務地・ジオフェンス
            </CardTitle>
            <CardDescription>打刻時の位置情報と勤務地の距離を判定します</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert tone="info" title="ジオフェンスは打刻を拒否しません">
              勤務地から半径外で打刻された場合も打刻は記録され、「勤務地外打刻」フラグが付与されるのみです。管理者は勤怠管理画面でフラグを確認できます。
            </Alert>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Field label="勤務地 緯度" error={errors.officeLatitude}>
                <Input type="number" step="any" min={-90} max={90} value={form.officeLatitude} onChange={(e) => set("officeLatitude", e.target.value)} disabled={!canWrite} placeholder="35.681236" />
              </Field>
              <Field label="勤務地 経度" error={errors.officeLongitude}>
                <Input type="number" step="any" min={-180} max={180} value={form.officeLongitude} onChange={(e) => set("officeLongitude", e.target.value)} disabled={!canWrite} placeholder="139.767125" />
              </Field>
              <Field label="許容半径 (m)" error={errors.geofenceRadiusM} hint="10〜100000">
                <Input type="number" min={10} max={100000} step={10} value={form.geofenceRadiusM} onChange={(e) => set("geofenceRadiusM", e.target.value)} disabled={!canWrite} required />
              </Field>
              <div className="flex items-end">
                {canWrite && (
                  <Button type="button" variant="outline" onClick={locate} loading={locating} className="w-full">
                    <LocateFixed className="h-4 w-4" /> 現在地を取得
                  </Button>
                )}
              </div>
            </div>
            <p className="text-xs text-slate-500">
              {geoEnabled ? "緯度・経度が設定されています。打刻時に勤務地との距離を判定します。" : "緯度・経度が未設定の場合、ジオフェンス判定は行われません。"}
              {canWrite && " 両方を空欄にして保存すると判定を無効化できます。"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex-col items-start gap-1">
            <CardTitle className="flex items-center gap-2">
              <Clock3 className="h-4 w-4 text-brand-600" /> 残業アラート（月間・法定時間外）
            </CardTitle>
            <CardDescription>月の法定時間外労働がこの時間を超えるとダッシュボードと勤怠管理に警告が表示されます</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <Field label="注意ライン（時間/月）" error={errors.overtimeAlertMinutes} hint="既定 45 時間（36協定の原則）">
              <Input type="number" min={0} max={744} step={0.5} value={form.overtimeAlertHours} onChange={(e) => set("overtimeAlertHours", e.target.value)} disabled={!canWrite} required />
            </Field>
            <Field label="上限ライン（時間/月）" error={errors.overtimeLimitMinutes} hint="既定 80 時間（特別条項・健康確保の目安）">
              <Input type="number" min={0} max={744} step={0.5} value={form.overtimeLimitHours} onChange={(e) => set("overtimeLimitHours", e.target.value)} disabled={!canWrite} required />
            </Field>
          </CardContent>
        </Card>

        {!canWrite ? (
          <Alert tone="info">会社設定の変更にはマスタ編集権限が必要です</Alert>
        ) : (
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setForm(toForm(initial))} disabled={pending}>
              元に戻す
            </Button>
            <Button type="submit" loading={pending}>
              <Save className="h-4 w-4" /> 保存
            </Button>
          </div>
        )}
      </form>
    </div>
  );
}
