"use client";

import { Suspense, useCallback, useState } from "react";
import Link from "next/link";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { ArrowLeft, CheckCircle2, Pencil, Undo2 } from "lucide-react";
import type { AttendanceDayDto, EmployeeDto, HolidayDto } from "@kintai/shared";
import { useAuth } from "@/lib/auth";
import { useApi } from "@/lib/use-api";
import { api, errorMessage } from "@/lib/api";
import { currentYearMonth, fmtDate, fmtYearMonth } from "@/lib/format";
import { useToast } from "@/components/ui/toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, Loading, MonthNav, PageHeader } from "@/components/ui/misc";
import { Button } from "@/components/ui/button";
import { ConfirmDialog } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/input";
import { AttendanceStatusBadge } from "@/components/ui/badge";
import { DayTable, type AttendanceMonthDto } from "@/components/attendance/day-table";
import { SummaryStats, AlertBadges } from "@/components/attendance/summary-stats";
import { DayDetailDialog } from "@/components/attendance/day-detail-dialog";
import { CorrectionDialog } from "@/components/attendance/correction-dialog";

const YM_RE = /^\d{4}-\d{2}$/;

export default function AdminEmployeeAttendancePage() {
  return (
    <Suspense fallback={<Loading />}>
      <EmployeeAttendance />
    </Suspense>
  );
}

function EmployeeAttendance() {
  const params = useParams<{ employeeId: string }>();
  const employeeId = params.employeeId;
  const searchParams = useSearchParams();
  const router = useRouter();
  const toast = useToast();
  const { can } = useAuth();
  const canWrite = can("attendance:write:department", "attendance:write:company");

  const monthParam = searchParams.get("month");
  const ym = monthParam && YM_RE.test(monthParam) ? monthParam : currentYearMonth();
  const setYm = (next: string) => router.replace(`/admin/attendance/${employeeId}?month=${next}`);

  const employee = useApi<EmployeeDto>(`/employees/${employeeId}`);
  const { data, error, loading, reload } = useApi<AttendanceMonthDto>(`/attendance/employees/${employeeId}`, { month: ym });
  const holidays = useApi<HolidayDto[]>("/holidays", { year: ym.slice(0, 4) });

  const [detailId, setDetailId] = useState<string | null>(null);
  const [editId, setEditId] = useState<string | null>(null);
  const [resetTarget, setResetTarget] = useState<AttendanceDayDto | null>(null);
  const [resetReason, setResetReason] = useState("");
  const [resetPending, setResetPending] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmPending, setConfirmPending] = useState(false);

  const findDay = useCallback((id: string | null) => (id ? (data?.days.find((d) => d.id === id) ?? null) : null), [data]);
  const detailDay = findDay(detailId);
  const editDay = findDay(editId);

  const locked = data?.summary.status === "LOCKED";

  const doResetManual = async () => {
    if (!resetTarget) return;
    if (!resetReason.trim()) {
      toast.error("解除理由を入力してください");
      return;
    }
    setResetPending(true);
    try {
      await api.post(`/attendance/days/${resetTarget.id}/reset-manual`, { reason: resetReason.trim() });
      toast.success(`${fmtDate(resetTarget.workDate)} の手修正を解除しました`);
      setResetTarget(null);
      setResetReason("");
      await reload();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setResetPending(false);
    }
  };

  const doConfirmMonth = async () => {
    setConfirmPending(true);
    try {
      await api.post(`/attendance/employees/${employeeId}/confirm`, undefined, { month: ym });
      toast.success(`${fmtYearMonth(ym)}の勤怠を確定しました`);
      setConfirmOpen(false);
      await reload();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setConfirmPending(false);
    }
  };

  const emp = employee.data;
  const title = emp ? `${emp.name}` : "従業員の勤怠";
  const descParts = [
    emp?.employeeCode ? `社員番号 ${emp.employeeCode}` : null,
    emp?.departmentName ?? null,
    emp?.currentWorkPattern ? `勤務パターン: ${emp.currentWorkPattern.name}` : emp ? "勤務パターン未設定" : null,
  ].filter(Boolean);

  return (
    <div className="space-y-5">
      <div>
        <Link href={`/admin/attendance?month=${ym}`} className="inline-flex items-center gap-1 text-xs text-slate-500 hover:text-brand-600">
          <ArrowLeft className="h-3.5 w-3.5" /> 勤怠管理へ戻る
        </Link>
      </div>
      <PageHeader
        title={title}
        description={descParts.length ? descParts.join(" · ") : undefined}
        actions={
          <>
            <MonthNav value={ym} onChange={setYm} />
            {canWrite && (
              <Button variant="success" size="md" onClick={() => setConfirmOpen(true)} disabled={!data || locked} title={locked ? "締め処理済みのため確定できません" : undefined}>
                <CheckCircle2 className="h-4 w-4" /> 月次確定
              </Button>
            )}
          </>
        }
      />

      {employee.error && !emp && <Alert tone="error">{employee.error}</Alert>}

      {loading && !data ? (
        <Loading />
      ) : error && !data ? (
        <Alert tone="error">{error}</Alert>
      ) : data ? (
        <>
          <div className="flex flex-wrap items-center gap-2 text-sm text-slate-600">
            <span>{fmtYearMonth(ym)}の状態:</span>
            <AttendanceStatusBadge status={data.summary.status} />
            {data.summary.alerts.length > 0 && <AlertBadges alerts={data.summary.alerts} />}
          </div>
          <SummaryStats summary={data.summary} />
          {locked && <Alert tone="info">この月は締め処理済みです。修正が必要な場合は「月次締め」から締め解除を行ってください。</Alert>}

          <Card>
            <CardHeader>
              <CardTitle>日次明細</CardTitle>
              <span className="text-xs text-slate-500">{canWrite ? "行クリックで詳細、「修正」で打刻・休憩・種別を直接修正できます" : "行をクリックすると詳細を表示します"}</span>
            </CardHeader>
            <CardContent className="px-0 pb-2">
              <DayTable
                days={data.days}
                yearMonth={ym}
                holidays={holidays.data}
                onRowClick={(d) => setDetailId(d.id)}
                renderActions={
                  canWrite
                    ? ({ day: d }) =>
                        d ? (
                          <>
                            {d.flags.includes("MANUAL") && (
                              <Button
                                variant="ghost"
                                size="sm"
                                disabled={d.status === "LOCKED"}
                                onClick={() => {
                                  setResetReason("");
                                  setResetTarget(d);
                                }}
                                title="手修正を解除して打刻から再計算"
                              >
                                <Undo2 className="h-3.5 w-3.5" /> 解除
                              </Button>
                            )}
                            <Button variant="outline" size="sm" disabled={d.status === "LOCKED"} onClick={() => setEditId(d.id)}>
                              <Pencil className="h-3.5 w-3.5" /> 修正
                            </Button>
                          </>
                        ) : (
                          <span className="text-xs text-slate-300">-</span>
                        )
                    : undefined
                }
              />
            </CardContent>
          </Card>
        </>
      ) : null}

      <DayDetailDialog
        day={detailDay}
        open={!!detailDay}
        onClose={() => setDetailId(null)}
        extraActions={
          canWrite && detailDay ? (
            <>
              {detailDay.flags.includes("MANUAL") && (
                <Button
                  variant="outline"
                  size="sm"
                  disabled={detailDay.status === "LOCKED"}
                  onClick={() => {
                    setResetReason("");
                    setResetTarget(detailDay);
                  }}
                >
                  <Undo2 className="h-3.5 w-3.5" /> 手修正を解除
                </Button>
              )}
              <Button
                size="sm"
                disabled={detailDay.status === "LOCKED"}
                onClick={() => {
                  setEditId(detailDay.id);
                  setDetailId(null);
                }}
              >
                <Pencil className="h-3.5 w-3.5" /> 修正する
              </Button>
            </>
          ) : undefined
        }
      />

      <CorrectionDialog
        day={editDay}
        open={!!editDay}
        onClose={() => setEditId(null)}
        onSaved={() => void reload()}
        onConflict={() => void reload()}
      />

      <ConfirmDialog
        open={!!resetTarget}
        onClose={() => {
          if (!resetPending) setResetTarget(null);
        }}
        onConfirm={() => void doResetManual()}
        title="手修正を解除"
        confirmLabel="解除する"
        danger
        pending={resetPending}
        message={
          <div className="space-y-3">
            <p>
              {resetTarget ? fmtDate(resetTarget.workDate) : ""} の手修正を解除し、打刻データから再計算します。修正した出勤・退勤・休憩は破棄されます。
            </p>
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-600">解除理由（必須）</label>
              <Textarea value={resetReason} onChange={(e) => setResetReason(e.target.value)} rows={2} maxLength={500} placeholder="例: 誤修正のため打刻値に戻す" />
            </div>
          </div>
        }
      />

      <ConfirmDialog
        open={confirmOpen}
        onClose={() => {
          if (!confirmPending) setConfirmOpen(false);
        }}
        onConfirm={() => void doConfirmMonth()}
        title="月次確定"
        confirmLabel="確定する"
        pending={confirmPending}
        message={
          <p>
            {emp?.name ?? "この従業員"} の {fmtYearMonth(ym)} の勤怠を確定します。
            {data && data.summary.alerts.length > 0 && <span className="mt-2 block text-amber-700">アラートが残っています: {data.summary.alerts.length} 件。内容を確認のうえ確定してください。</span>}
          </p>
        }
      />
    </div>
  );
}
