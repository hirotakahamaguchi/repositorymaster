"use client";

import { useEffect, useState } from "react";
import { Building2, Plus, Search, UserPlus } from "lucide-react";
import type { DepartmentDto, EmployeeDto, Paginated, WorkPatternDto } from "@kintai/shared";
import { ROLE_LABEL } from "@kintai/shared";
import { useAuth } from "@/lib/auth";
import { useApi } from "@/lib/use-api";
import { fmtDate } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox, Input, Select } from "@/components/ui/input";
import { Alert, EmptyState, Loading, PageHeader, Pagination } from "@/components/ui/misc";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { EmployeeDialog } from "@/components/admin/employee-dialog";
import { DepartmentsDialog } from "@/components/admin/departments-dialog";

const PAGE_SIZE = 50;

function roleTone(role: string): "gray" | "blue" | "green" | "amber" | "red" | "violet" | "sky" {
  switch (role) {
    case "ADMIN":
      return "violet";
    case "HR":
      return "blue";
    case "MANAGER":
      return "green";
    default:
      return "gray";
  }
}

export default function EmployeesPage() {
  const { can } = useAuth();
  const canWrite = can("employee:write:company");
  const canMaster = can("master:write:company");

  const [qInput, setQInput] = useState("");
  const [q, setQ] = useState("");
  const [departmentId, setDepartmentId] = useState("");
  const [includeRetired, setIncludeRetired] = useState(false);
  const [page, setPage] = useState(1);

  // 検索語はデバウンス
  useEffect(() => {
    const t = setTimeout(() => {
      setQ(qInput.trim());
      setPage(1);
    }, 300);
    return () => clearTimeout(t);
  }, [qInput]);

  const list = useApi<Paginated<EmployeeDto>>("/employees", { page, pageSize: PAGE_SIZE, q, departmentId, includeRetired: includeRetired ? true : undefined });
  const departments = useApi<DepartmentDto[]>("/departments");
  const workPatterns = useApi<WorkPatternDto[]>("/work-patterns");

  const [dialog, setDialog] = useState<{ open: boolean; employee: EmployeeDto | null }>({ open: false, employee: null });
  const [deptOpen, setDeptOpen] = useState(false);

  const openCreate = () => setDialog({ open: true, employee: null });
  const openEdit = (e: EmployeeDto) => setDialog({ open: true, employee: e });
  const closeDialog = () => setDialog((d) => ({ ...d, open: false }));

  const data = list.data;

  return (
    <div>
      <PageHeader
        title="従業員"
        description="従業員情報・勤務パターン・休暇付与を管理します"
        actions={
          <>
            <Button variant="outline" onClick={() => setDeptOpen(true)}>
              <Building2 className="h-4 w-4" /> 部署管理
            </Button>
            {canWrite && (
              <Button onClick={openCreate}>
                <UserPlus className="h-4 w-4" /> 新規登録
              </Button>
            )}
          </>
        }
      />

      <div className="mb-4 flex flex-col gap-3 rounded-2xl border bg-white p-4 shadow-sm sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <Input value={qInput} onChange={(e) => setQInput(e.target.value)} placeholder="氏名・社員番号・メールで検索" className="pl-9" />
        </div>
        <Select
          value={departmentId}
          onChange={(e) => {
            setDepartmentId(e.target.value);
            setPage(1);
          }}
          className="sm:w-56"
        >
          <option value="">すべての部署</option>
          {(departments.data ?? []).map((d) => (
            <option key={d.id} value={d.id}>
              {d.name}
            </option>
          ))}
        </Select>
        <Checkbox
          label="退職者を含む"
          checked={includeRetired}
          onChange={(e) => {
            setIncludeRetired(e.target.checked);
            setPage(1);
          }}
          className="whitespace-nowrap"
        />
      </div>

      {list.loading && !data ? (
        <Loading />
      ) : list.error && !data ? (
        <Alert tone="error">{list.error}</Alert>
      ) : !data || data.items.length === 0 ? (
        <EmptyState
          title="該当する従業員がいません"
          description={q || departmentId ? "検索条件を変更してください" : undefined}
          action={
            canWrite && !q && !departmentId ? (
              <Button size="sm" onClick={openCreate}>
                <Plus className="h-4 w-4" /> 従業員を登録
              </Button>
            ) : undefined
          }
        />
      ) : (
        <div className="rounded-2xl border bg-white shadow-sm">
          <Table>
            <THead>
              <TR>
                <TH>社員番号</TH>
                <TH>氏名</TH>
                <TH>メール</TH>
                <TH>部署</TH>
                <TH>ロール</TH>
                <TH>勤務パターン</TH>
                <TH>入社日</TH>
                <TH>退職日</TH>
              </TR>
            </THead>
            <TBody>
              {data.items.map((e) => (
                <TR key={e.id} onClick={() => openEdit(e)} className="cursor-pointer">
                  <TD className="tabular text-slate-600">{e.employeeCode}</TD>
                  <TD>
                    <div className="font-medium text-slate-900">{e.name}</div>
                    {e.nameKana && <div className="text-[11px] text-slate-500">{e.nameKana}</div>}
                  </TD>
                  <TD className="text-slate-600">{e.email}</TD>
                  <TD className="text-slate-700">{e.departmentName ?? <span className="text-slate-400">未所属</span>}</TD>
                  <TD>
                    <div className="flex flex-wrap gap-1">
                      {e.roles.map((r) => (
                        <Badge key={r} tone={roleTone(r)}>
                          {ROLE_LABEL[r] ?? r}
                        </Badge>
                      ))}
                    </div>
                  </TD>
                  <TD className="text-slate-700">{e.currentWorkPattern?.name ?? <span className="text-slate-400">未設定</span>}</TD>
                  <TD className="tabular text-slate-600">{fmtDate(e.hiredAt)}</TD>
                  <TD className="tabular text-slate-600">{e.retiredAt ? <span className="text-rose-600">{fmtDate(e.retiredAt)}</span> : <span className="text-slate-400">-</span>}</TD>
                </TR>
              ))}
            </TBody>
          </Table>
          <div className="px-4 pb-3">
            <Pagination page={data.page} pageSize={data.pageSize} total={data.total} onChange={setPage} />
          </div>
        </div>
      )}

      <EmployeeDialog
        open={dialog.open}
        onClose={closeDialog}
        employee={dialog.employee}
        departments={departments.data ?? []}
        workPatterns={workPatterns.data ?? []}
        canWrite={canWrite}
        onSaved={() => void list.reload()}
      />
      <DepartmentsDialog
        open={deptOpen}
        onClose={() => setDeptOpen(false)}
        canWrite={canMaster}
        onChanged={() => {
          void departments.reload();
          void list.reload();
        }}
      />
    </div>
  );
}
