"use client";

import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Plus, Trash2, Upload } from "lucide-react";
import type { HolidayDto } from "@kintai/shared";
import { UpsertHolidaySchema } from "@kintai/shared";
import { useAuth } from "@/lib/auth";
import { api, errorMessage } from "@/lib/api";
import { useApi } from "@/lib/use-api";
import { fmtDate, todayLocal } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ConfirmDialog } from "@/components/ui/dialog";
import { Field, Input, Select, Textarea } from "@/components/ui/input";
import { Alert, EmptyState, Loading, PageHeader } from "@/components/ui/misc";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { useToast } from "@/components/ui/toast";
import { zodFieldErrors } from "@/components/admin/form-utils";

type Kind = HolidayDto["kind"];
const KIND_LABEL: Record<Kind, string> = { NATIONAL: "祝日", COMPANY: "会社休日" };

function KindBadge({ kind }: { kind: Kind }) {
  return <Badge tone={kind === "NATIONAL" ? "blue" : "amber"}>{KIND_LABEL[kind]}</Badge>;
}

export default function HolidaysPage() {
  const { can } = useAuth();
  const canWrite = can("master:write:company");
  const toast = useToast();
  const [year, setYear] = useState(() => Number(todayLocal().slice(0, 4)));
  const { data, loading, error, reload } = useApi<HolidayDto[]>("/holidays", { year });

  // 単発追加
  const [date, setDate] = useState(`${year}-01-01`);
  const [name, setName] = useState("");
  const [kind, setKind] = useState<Kind>("COMPANY");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);

  // 一括登録
  const [bulkText, setBulkText] = useState("");
  const [bulkKind, setBulkKind] = useState<Kind>("NATIONAL");
  const [bulkPending, setBulkPending] = useState(false);
  const [bulkProgress, setBulkProgress] = useState<{ done: number; total: number; failed: string[] } | null>(null);

  const [deleting, setDeleting] = useState<HolidayDto | null>(null);
  const [deletePending, setDeletePending] = useState(false);

  const grouped = useMemo(() => {
    const map = new Map<number, HolidayDto[]>();
    for (const h of [...(data ?? [])].sort((a, b) => a.date.localeCompare(b.date))) {
      const m = Number(h.date.slice(5, 7));
      if (!map.has(m)) map.set(m, []);
      map.get(m)!.push(h);
    }
    return [...map.entries()].sort((a, b) => a[0] - b[0]);
  }, [data]);

  const changeYear = (d: number) => {
    const y = year + d;
    setYear(y);
    setDate(`${y}-01-01`);
  };

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = UpsertHolidaySchema.safeParse({ date, name: name.trim(), kind });
    if (!parsed.success) {
      setErrors(zodFieldErrors(parsed.error));
      return;
    }
    setErrors({});
    setPending(true);
    try {
      await api.post("/holidays", parsed.data);
      toast.success("休日を登録しました");
      setName("");
      if (!date.startsWith(String(year))) setYear(Number(date.slice(0, 4)));
      else await reload();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setPending(false);
    }
  };

  const bulk = async () => {
    const lines = bulkText
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);
    if (lines.length === 0) {
      toast.error("登録する行がありません");
      return;
    }
    const rows: { date: string; name: string; kind: Kind }[] = [];
    const invalid: string[] = [];
    for (const line of lines) {
      const [d, ...rest] = line.split(/[,\t、]/);
      const n = rest.join(",").trim();
      const parsed = UpsertHolidaySchema.safeParse({ date: d?.trim(), name: n, kind: bulkKind });
      if (parsed.success) rows.push(parsed.data);
      else invalid.push(line);
    }
    if (invalid.length > 0) {
      toast.error(`形式が不正な行があります: ${invalid.slice(0, 3).join(" / ")}${invalid.length > 3 ? " ほか" : ""}`);
      return;
    }
    setBulkPending(true);
    setBulkProgress({ done: 0, total: rows.length, failed: [] });
    const failed: string[] = [];
    for (let i = 0; i < rows.length; i++) {
      try {
        await api.post("/holidays", rows[i]);
      } catch (err) {
        failed.push(`${rows[i].date} ${rows[i].name}: ${errorMessage(err)}`);
      }
      setBulkProgress({ done: i + 1, total: rows.length, failed: [...failed] });
    }
    setBulkPending(false);
    if (failed.length === 0) {
      toast.success(`${rows.length} 件の休日を登録しました`);
      setBulkText("");
    } else {
      toast.error(`${failed.length} 件の登録に失敗しました`);
    }
    await reload();
  };

  const remove = async () => {
    if (!deleting) return;
    setDeletePending(true);
    try {
      await api.delete(`/holidays/${deleting.id}`);
      toast.success("休日を削除しました");
      setDeleting(null);
      await reload();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setDeletePending(false);
    }
  };

  const total = data?.length ?? 0;
  const nationalCount = data?.filter((h) => h.kind === "NATIONAL").length ?? 0;

  return (
    <div>
      <PageHeader
        title="休日カレンダー"
        description="祝日・会社休日を登録します。登録した日は所定休日として勤怠計算に反映されます"
        actions={
          <div className="inline-flex items-center rounded-lg border bg-white shadow-sm">
            <button onClick={() => changeYear(-1)} className="flex h-9 items-center px-3 text-slate-600 hover:bg-slate-50" aria-label="前年">
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="tabular min-w-[6rem] text-center text-sm font-semibold">{year}年</span>
            <button onClick={() => changeYear(1)} className="flex h-9 items-center px-3 text-slate-600 hover:bg-slate-50" aria-label="翌年">
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        }
      />

      <div className="grid gap-6 lg:grid-cols-5">
        <div className="space-y-4 lg:col-span-3">
          {loading && !data ? (
            <Loading />
          ) : error && !data ? (
            <Alert tone="error">{error}</Alert>
          ) : !data || data.length === 0 ? (
            <EmptyState title={`${year}年の休日は登録されていません`} description={canWrite ? "右のフォームから追加、または年間一括登録をご利用ください" : undefined} />
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>
                  {year}年の休日 <span className="ml-1 text-sm font-normal text-slate-500">（{total} 日 · 祝日 {nationalCount} / 会社休日 {total - nationalCount}）</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="px-0 pb-2">
                <Table>
                  <THead>
                    <TR>
                      <TH>日付</TH>
                      <TH>名称</TH>
                      <TH>種別</TH>
                      {canWrite && <TH className="w-12"></TH>}
                    </TR>
                  </THead>
                  <TBody>
                    {grouped.map(([m, items]) => (
                      <MonthGroup key={m} month={m} items={items} canWrite={canWrite} onDelete={setDeleting} />
                    ))}
                  </TBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </div>

        {canWrite && (
          <div className="space-y-4 lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>休日を追加</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={add} className="space-y-3">
                  <Field label="日付" error={errors.date}>
                    <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
                  </Field>
                  <Field label="名称" error={errors.name}>
                    <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="例: 創立記念日" required maxLength={100} />
                  </Field>
                  <Field label="種別" error={errors.kind}>
                    <Select value={kind} onChange={(e) => setKind(e.target.value as Kind)}>
                      <option value="COMPANY">会社休日</option>
                      <option value="NATIONAL">祝日</option>
                    </Select>
                  </Field>
                  <div className="flex justify-end">
                    <Button type="submit" loading={pending}>
                      <Plus className="h-4 w-4" /> 追加
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex-col items-start gap-1">
                <CardTitle>年間一括登録</CardTitle>
                <CardDescription>
                  1行に <code className="rounded bg-slate-100 px-1 text-xs">YYYY-MM-DD,名称</code> の形式で貼り付けてください。1件ずつ順に登録します。
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Textarea
                  value={bulkText}
                  onChange={(e) => setBulkText(e.target.value)}
                  rows={8}
                  placeholder={`${year}-01-01,元日\n${year}-01-12,成人の日\n${year}-02-11,建国記念の日`}
                  className="font-mono text-xs"
                  disabled={bulkPending}
                />
                <Field label="種別（全行に適用）">
                  <Select value={bulkKind} onChange={(e) => setBulkKind(e.target.value as Kind)} disabled={bulkPending}>
                    <option value="NATIONAL">祝日</option>
                    <option value="COMPANY">会社休日</option>
                  </Select>
                </Field>
                {bulkProgress && (
                  <div className="space-y-1 text-xs text-slate-600">
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
                      <div className="h-full bg-brand-600 transition-all" style={{ width: `${(bulkProgress.done / Math.max(1, bulkProgress.total)) * 100}%` }} />
                    </div>
                    <p className="tabular">
                      {bulkProgress.done} / {bulkProgress.total} 件
                    </p>
                    {bulkProgress.failed.length > 0 && (
                      <ul className="list-disc space-y-0.5 pl-4 text-rose-600">
                        {bulkProgress.failed.map((f, i) => (
                          <li key={i}>{f}</li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}
                <div className="flex justify-end">
                  <Button variant="secondary" onClick={() => void bulk()} loading={bulkPending} disabled={!bulkText.trim()}>
                    <Upload className="h-4 w-4" /> 一括登録
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      <ConfirmDialog
        open={!!deleting}
        onClose={() => setDeleting(null)}
        onConfirm={() => void remove()}
        title="休日を削除"
        message={deleting ? `${fmtDate(deleting.date)}「${deleting.name}」を削除します。よろしいですか？` : ""}
        confirmLabel="削除"
        danger
        pending={deletePending}
      />
    </div>
  );
}

function MonthGroup({ month, items, canWrite, onDelete }: { month: number; items: HolidayDto[]; canWrite: boolean; onDelete: (h: HolidayDto) => void }) {
  return (
    <>
      <TR className="bg-slate-50/80 hover:bg-slate-50/80">
        <TD colSpan={canWrite ? 4 : 3} className="py-1.5 text-xs font-semibold text-slate-600">
          {month}月 <span className="font-normal text-slate-400">（{items.length} 日）</span>
        </TD>
      </TR>
      {items.map((h) => (
        <TR key={h.id}>
          <TD className="tabular text-slate-700">{fmtDate(h.date)}</TD>
          <TD className="font-medium text-slate-900">{h.name}</TD>
          <TD>
            <KindBadge kind={h.kind} />
          </TD>
          {canWrite && (
            <TD>
              <button type="button" onClick={() => onDelete(h)} className="rounded-md p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600" aria-label="削除">
                <Trash2 className="h-4 w-4" />
              </button>
            </TD>
          )}
        </TR>
      ))}
    </>
  );
}
