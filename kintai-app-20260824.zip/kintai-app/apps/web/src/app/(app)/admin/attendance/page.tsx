"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Search } from "lucide-react";
import type { AttendanceDayDto, AttendanceMonthSummary, DepartmentDto } from "@kintai/shared";
import { useAuth } from "@/lib/auth";
import { useApi } from "@/lib/use-api";
import { cn } from "@/lib/utils";
import { currentYearMonth, fmtDateShort, fmtTime, fmtYearMonth, minutesToHm, weekdayOf } from "@/lib/format";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, EmptyState, Loading, MonthNav, PageHeader, Tabs } from "@/components/ui/misc";
import { Input, Select } from "@/components/ui/input";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { AttendanceStatusBadge, DayTypeBadge, FlagBadges } from "@/components/ui/badge";
import { AlertBadges } from "@/components/attendance/summary-stats";

type Tab = "summary" | "flagged";

function matches(q: string, ...fields: (string | null | undefined)[]) {
  if (!q) return true;
  const needle = q.toLowerCase();
  return fields.some((f) => (f ?? "").toLowerCase().includes(needle));
}

export default function AdminAttendancePage() {
  const router = useRouter();
  const { can } = useAuth();
  const canCompany = can("attendance:read:company");
  const [ym, setYm] = useState(currentYearMonth());
  const [departmentId, setDepartmentId] = useState("");
  const [tab, setTab] = useState<Tab>("summary");
  const [q, setQ] = useState("");

  const departments = useApi<DepartmentDto[]>(canCompany ? "/departments" : null);
  const summary = useApi<AttendanceMonthSummary[]>("/attendance/company/summary", { month: ym, departmentId: departmentId || undefined });
  const flagged = useApi<AttendanceDayDto[]>("/attendance/company", { month: ym, departmentId: departmentId || undefined, flagged: true });

  const summaryRows = useMemo(() => {
    const rows = (summary.data ?? []).filter((r) => matches(q, r.employeeName, r.employeeCode, r.departmentName));
    return [...rows].sort((a, b) => (a.employeeCode ?? "").localeCompare(b.employeeCode ?? ""));
  }, [summary.data, q]);

  const flaggedRows = useMemo(() => {
    const rows = (flagged.data ?? []).filter((r) => matches(q, r.employeeName, r.employeeCode, r.departmentName));
    return [...rows].sort((a, b) => a.workDate.localeCompare(b.workDate) || (a.employeeCode ?? "").localeCompare(b.employeeCode ?? ""));
  }, [flagged.data, q]);

  const totals = useMemo(
    () =>
      summaryRows.reduce(
        (t, r) => ({
          scheduledDays: t.scheduledDays + r.scheduledDays,
          actualWorkDays: t.actualWorkDays + r.actualWorkDays,
          workMinutes: t.workMinutes + r.workMinutes,
          overtimeMinutes: t.overtimeMinutes + r.overtimeMinutes,
          legalOvertimeMinutes: t.legalOvertimeMinutes + r.legalOvertimeMinutes,
          lateNightMinutes: t.lateNightMinutes + r.lateNightMinutes,
          holidayWorkMinutes: t.holidayWorkMinutes + r.holidayWorkMinutes,
          lateCount: t.lateCount + r.lateCount,
          earlyLeaveCount: t.earlyLeaveCount + r.earlyLeaveCount,
          paidLeaveDays: t.paidLeaveDays + r.paidLeaveDays,
          alerts: t.alerts + (r.alerts.length ? 1 : 0),
          confirmed: t.confirmed + (r.status !== "DRAFT" ? 1 : 0),
        }),
        { scheduledDays: 0, actualWorkDays: 0, workMinutes: 0, overtimeMinutes: 0, legalOvertimeMinutes: 0, lateNightMinutes: 0, holidayWorkMinutes: 0, lateCount: 0, earlyLeaveCount: 0, paidLeaveDays: 0, alerts: 0, confirmed: 0 },
      ),
    [summaryRows],
  );

  const goEmployee = (employeeId: string) => router.push(`/admin/attendance/${employeeId}?month=${ym}`);

  return (
    <div className="space-y-5">
      <PageHeader title="勤怠管理" description={`${fmtYearMonth(ym)}の部門・全社の勤怠状況`} actions={<MonthNav value={ym} onChange={setYm} />} />

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <Tabs<Tab>
          tabs={[
            { value: "summary", label: "月次サマリ", count: summary.data?.length },
            { value: "flagged", label: "要確認", count: flagged.data?.length },
          ]}
          value={tab}
          onChange={setTab}
        />
        <div className="flex flex-1 flex-wrap gap-2 sm:justify-end">
          {canCompany && (
            <Select value={departmentId} onChange={(e) => setDepartmentId(e.target.value)} className="w-full sm:w-48" aria-label="部署">
              <option value="">全部署</option>
              {(departments.data ?? []).map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </Select>
          )}
          <div className="relative w-full sm:w-60">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="氏名・社員番号で絞り込み" className="pl-9" />
          </div>
        </div>
      </div>

      {tab === "summary" ? (
        <Card>
          <CardContent className="px-0 pb-0 pt-0">
            {summary.loading && !summary.data ? (
              <Loading />
            ) : summary.error && !summary.data ? (
              <div className="p-4">
                <Alert tone="error">{summary.error}</Alert>
              </div>
            ) : summaryRows.length === 0 ? (
              <div className="p-4">
                <EmptyState title="対象の従業員がいません" description={q ? "検索条件を変更してください" : "この月の勤怠データはまだありません"} />
              </div>
            ) : (
              <Table>
                <THead>
                  <TR className="hover:bg-transparent">
                    <TH>社員番号</TH>
                    <TH>氏名</TH>
                    <TH>部署</TH>
                    <TH className="text-right">出勤/所定</TH>
                    <TH className="text-right">総労働</TH>
                    <TH className="text-right">所定外</TH>
                    <TH className="text-right">法定外</TH>
                    <TH className="text-right">深夜</TH>
                    <TH className="text-right">休日労働</TH>
                    <TH className="text-right">遅刻/早退</TH>
                    <TH className="text-right">有給</TH>
                    <TH>アラート</TH>
                    <TH>状態</TH>
                  </TR>
                </THead>
                <TBody>
                  {summaryRows.map((r) => {
                    const otTone = r.alerts.includes("OVERTIME_LIMIT") ? "font-semibold text-rose-600" : r.alerts.includes("OVERTIME_WARN") ? "font-semibold text-amber-600" : "";
                    return (
                      <TR key={r.employeeId} className="cursor-pointer" onClick={() => goEmployee(r.employeeId)}>
                        <TD className="tabular text-slate-600">{r.employeeCode ?? "-"}</TD>
                        <TD className="whitespace-nowrap font-medium text-slate-900">{r.employeeName ?? r.employeeId}</TD>
                        <TD className="whitespace-nowrap text-slate-600">{r.departmentName ?? "-"}</TD>
                        <TD className="tabular text-right">
                          {r.actualWorkDays}
                          <span className="text-slate-400"> / {r.scheduledDays}</span>
                        </TD>
                        <TD className="tabular text-right">{minutesToHm(r.workMinutes)}</TD>
                        <TD className="tabular text-right">{r.overtimeMinutes ? minutesToHm(r.overtimeMinutes) : <span className="text-slate-300">-</span>}</TD>
                        <TD className={cn("tabular text-right", otTone)}>{r.legalOvertimeMinutes ? minutesToHm(r.legalOvertimeMinutes) : <span className="text-slate-300">-</span>}</TD>
                        <TD className="tabular text-right">{r.lateNightMinutes ? minutesToHm(r.lateNightMinutes) : <span className="text-slate-300">-</span>}</TD>
                        <TD className="tabular text-right">{r.holidayWorkMinutes ? minutesToHm(r.holidayWorkMinutes) : <span className="text-slate-300">-</span>}</TD>
                        <TD className={cn("tabular text-right", r.lateCount + r.earlyLeaveCount > 0 && "text-amber-700")}>
                          {r.lateCount} / {r.earlyLeaveCount}
                        </TD>
                        <TD className="tabular text-right">{r.paidLeaveDays ? `${r.paidLeaveDays} 日` : <span className="text-slate-300">-</span>}</TD>
                        <TD>
                          <AlertBadges alerts={r.alerts} />
                        </TD>
                        <TD>
                          <AttendanceStatusBadge status={r.status} />
                        </TD>
                      </TR>
                    );
                  })}
                </TBody>
                <tfoot className="border-t-2 bg-slate-50 text-xs font-semibold text-slate-700">
                  <tr>
                    <TD colSpan={3}>合計（{summaryRows.length} 名）</TD>
                    <TD className="tabular text-right">
                      {totals.actualWorkDays}
                      <span className="font-normal text-slate-400"> / {totals.scheduledDays}</span>
                    </TD>
                    <TD className="tabular text-right">{minutesToHm(totals.workMinutes)}</TD>
                    <TD className="tabular text-right">{minutesToHm(totals.overtimeMinutes)}</TD>
                    <TD className="tabular text-right">{minutesToHm(totals.legalOvertimeMinutes)}</TD>
                    <TD className="tabular text-right">{minutesToHm(totals.lateNightMinutes)}</TD>
                    <TD className="tabular text-right">{minutesToHm(totals.holidayWorkMinutes)}</TD>
                    <TD className="tabular text-right">
                      {totals.lateCount} / {totals.earlyLeaveCount}
                    </TD>
                    <TD className="tabular text-right">{totals.paidLeaveDays} 日</TD>
                    <TD className="font-normal text-slate-500">{totals.alerts ? `${totals.alerts} 名に警告` : "-"}</TD>
                    <TD className="font-normal text-slate-500">確定 {totals.confirmed} 名</TD>
                  </tr>
                </tfoot>
              </Table>
            )}
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="px-0 pb-0 pt-0">
            {flagged.loading && !flagged.data ? (
              <Loading />
            ) : flagged.error && !flagged.data ? (
              <div className="p-4">
                <Alert tone="error">{flagged.error}</Alert>
              </div>
            ) : flaggedRows.length === 0 ? (
              <div className="p-4">
                <EmptyState title="要確認の勤怠はありません" description={q ? "検索条件を変更してください" : `${fmtYearMonth(ym)}にフラグ付きの日はありません`} />
              </div>
            ) : (
              <Table>
                <THead>
                  <TR className="hover:bg-transparent">
                    <TH>日付</TH>
                    <TH>氏名</TH>
                    <TH>部署</TH>
                    <TH>種別</TH>
                    <TH className="text-right">出勤</TH>
                    <TH className="text-right">退勤</TH>
                    <TH className="text-right">実労働</TH>
                    <TH>フラグ</TH>
                    <TH>状態</TH>
                  </TR>
                </THead>
                <TBody>
                  {flaggedRows.map((d) => {
                    const wd = weekdayOf(d.workDate);
                    return (
                      <TR key={d.id} className="cursor-pointer" onClick={() => goEmployee(d.employeeId)}>
                        <TD className={cn("tabular whitespace-nowrap font-medium", wd === 0 ? "text-rose-600" : wd === 6 ? "text-blue-600" : "text-slate-900")}>{fmtDateShort(d.workDate)}</TD>
                        <TD className="whitespace-nowrap">
                          <span className="font-medium text-slate-900">{d.employeeName ?? d.employeeId}</span>
                          {d.employeeCode && <span className="tabular ml-1.5 text-xs text-slate-500">{d.employeeCode}</span>}
                        </TD>
                        <TD className="whitespace-nowrap text-slate-600">{d.departmentName ?? "-"}</TD>
                        <TD>
                          <DayTypeBadge dayType={d.dayType} />
                        </TD>
                        <TD className="tabular text-right">{fmtTime(d.clockInAt)}</TD>
                        <TD className="tabular text-right">{fmtTime(d.clockOutAt)}</TD>
                        <TD className="tabular text-right">{d.workMinutes ? minutesToHm(d.workMinutes) : <span className="text-slate-300">-</span>}</TD>
                        <TD>
                          <FlagBadges flags={d.flags} max={6} />
                        </TD>
                        <TD>
                          <AttendanceStatusBadge status={d.status} />
                        </TD>
                      </TR>
                    );
                  })}
                </TBody>
              </Table>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
