"use client";

import { useMemo, useState } from "react";
import { CheckCheck, Search } from "lucide-react";
import type { Paginated, RequestDto, RequestType } from "@kintai/shared";
import { REQUEST_TYPES, REQUEST_TYPE_LABEL } from "@kintai/shared";
import { api, errorMessage } from "@/lib/api";
import { useApi } from "@/lib/use-api";
import { fmtDateShort, fmtDateTime } from "@/lib/format";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RequestStatusBadge } from "@/components/ui/badge";
import { Input, Select } from "@/components/ui/input";
import { ConfirmDialog } from "@/components/ui/dialog";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { Alert, EmptyState, Loading, PageHeader, Pagination, Tabs } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { PayloadSummary } from "@/components/requests/payload-summary";
import { RequestDetailDialog } from "@/components/requests/request-detail-dialog";

type Tab = "MINE" | "PENDING" | "DONE";
const PAGE_SIZE = 50;

function currentStepLabel(r: RequestDto): string {
  if (r.status !== "PENDING") return "-";
  const total = r.approvals.length;
  const cur = r.approvals.find((a) => a.stepNo === r.currentStep);
  const who = cur?.approverName ?? (cur ? (cur.stepNo <= 1 ? "部署管理者" : "労務担当") : null);
  return `${r.currentStep}/${total}${who ? ` ${who}` : ""}`;
}

function matchesQuery(r: RequestDto, q: string): boolean {
  if (!q) return true;
  const s = q.toLowerCase();
  return r.employeeName.toLowerCase().includes(s) || r.employeeCode.toLowerCase().includes(s) || (r.departmentName ?? "").toLowerCase().includes(s);
}

export default function ApprovalsPage() {
  const toast = useToast();
  const [tab, setTab] = useState<Tab>("MINE");
  const [page, setPage] = useState(1);
  const [requestType, setRequestType] = useState<RequestType | "">("");
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<RequestDto | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [checked, setChecked] = useState<Set<string>>(new Set());
  const [bulkOpen, setBulkOpen] = useState(false);
  const [bulkPending, setBulkPending] = useState(false);

  const query = useMemo(
    () => ({
      page,
      pageSize: PAGE_SIZE,
      status: tab === "DONE" ? undefined : "PENDING",
      onlyMine: tab === "MINE" ? "true" : undefined,
      requestType: requestType || undefined,
    }),
    [page, tab, requestType],
  );
  const list = useApi<Paginated<RequestDto>>("/requests/inbox", query);
  // 要対応件数（タブのバッジ用）
  const mine = useApi<Paginated<RequestDto>>("/requests/inbox", {
    page: 1,
    pageSize: 200,
    status: "PENDING",
    onlyMine: "true",
  });

  const reloadAll = () => {
    void list.reload();
    void mine.reload();
  };

  const rows = useMemo(() => {
    let items = list.data?.items ?? [];
    if (tab === "DONE") items = items.filter((r) => r.status !== "PENDING");
    return items.filter((r) => matchesQuery(r, q.trim()));
  }, [list.data, tab, q]);

  const decidable = useMemo(() => rows.filter((r) => r.canDecide && r.status === "PENDING"), [rows]);
  const allChecked = decidable.length > 0 && decidable.every((r) => checked.has(r.id));
  const checkedRows = decidable.filter((r) => checked.has(r.id));

  const toggleAll = () => {
    setChecked(allChecked ? new Set() : new Set(decidable.map((r) => r.id)));
  };
  const toggle = (id: string) => {
    setChecked((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });
  };

  const bulkApprove = async () => {
    if (bulkPending || checkedRows.length === 0) return;
    setBulkPending(true);
    let ok = 0;
    const failed: string[] = [];
    for (const r of checkedRows) {
      try {
        await api.post(`/requests/${r.id}/decide`, { decision: "APPROVED" });
        ok++;
      } catch (e) {
        failed.push(`${r.employeeName}（${REQUEST_TYPE_LABEL[r.requestType]}）: ${errorMessage(e)}`);
      }
    }
    setBulkPending(false);
    setBulkOpen(false);
    setChecked(new Set());
    if (failed.length === 0) toast.success(`${ok} 件を承認しました`);
    else if (ok === 0) toast.error(`承認に失敗しました（${failed.length} 件）: ${failed[0]}`);
    else toast.error(`${ok} 件を承認、${failed.length} 件が失敗しました: ${failed[0]}`);
    reloadAll();
  };

  // タブ/ページ/フィルタ変更時は選択をクリア
  const changePage = (p: number) => {
    setPage(p);
    setChecked(new Set());
  };
  const changeTab = (t: Tab) => {
    setTab(t);
    setPage(1);
    setChecked(new Set());
  };
  const changeRequestType = (t: RequestType | "") => {
    setRequestType(t);
    setPage(1);
    setChecked(new Set());
  };

  const mineCount = mine.data?.items.length;
  const tabs: { value: Tab; label: string; count?: number }[] = [
    { value: "MINE", label: "要対応", count: mineCount },
    { value: "PENDING", label: "承認待ち(すべて)" },
    { value: "DONE", label: "処理済" },
  ];

  return (
    <div className="space-y-5">
      <PageHeader
        title="承認"
        description="部署メンバーからの申請を確認し、承認・却下を行います。"
        actions={
          checkedRows.length > 0 ? (
            <Button variant="success" onClick={() => setBulkOpen(true)} disabled={bulkPending}>
              <CheckCheck className="h-4 w-4" /> 選択を一括承認（
              {checkedRows.length}）
            </Button>
          ) : undefined
        }
      />

      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <Tabs tabs={tabs} value={tab} onChange={changeTab} />
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <Select value={requestType} onChange={(e) => changeRequestType(e.target.value as RequestType | "")} className="sm:w-44" aria-label="種別で絞り込み">
            <option value="">すべての種別</option>
            {REQUEST_TYPES.map((t) => (
              <option key={t} value={t}>
                {REQUEST_TYPE_LABEL[t]}
              </option>
            ))}
          </Select>
          <div className="relative sm:w-56">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="氏名・社員番号・部署で検索" className="pl-9" aria-label="申請者検索" />
          </div>
        </div>
      </div>

      <Card>
        {list.loading && !list.data ? (
          <Loading />
        ) : list.error && !list.data ? (
          <div className="p-4">
            <Alert tone="error">{list.error}</Alert>
          </div>
        ) : rows.length === 0 ? (
          <div className="p-4">
            <EmptyState
              title={tab === "MINE" ? "対応が必要な申請はありません" : tab === "PENDING" ? "承認待ちの申請はありません" : "処理済の申請はありません"}
              description={q ? "検索条件に一致する申請がありません" : undefined}
            />
          </div>
        ) : (
          <Table>
            <THead>
              <TR>
                {tab !== "DONE" && (
                  <TH className="w-8">
                    <input
                      type="checkbox"
                      aria-label="すべて選択"
                      className="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500"
                      checked={allChecked}
                      disabled={decidable.length === 0}
                      onChange={toggleAll}
                    />
                  </TH>
                )}
                <TH>申請日</TH>
                <TH>申請者</TH>
                <TH>種別</TH>
                <TH>対象日</TH>
                <TH>内容</TH>
                <TH>理由</TH>
                <TH>状態</TH>
                <TH>現在ステップ</TH>
              </TR>
            </THead>
            <TBody>
              {rows.map((r) => {
                const can = !!r.canDecide && r.status === "PENDING";
                return (
                  <TR
                    key={r.id}
                    className="cursor-pointer"
                    onClick={() => {
                      setSelected(r);
                      setDetailOpen(true);
                    }}
                  >
                    {tab !== "DONE" && (
                      <TD onClick={(e) => e.stopPropagation()}>
                        {can ? (
                          <input
                            type="checkbox"
                            aria-label="選択"
                            className="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500"
                            checked={checked.has(r.id)}
                            onChange={() => toggle(r.id)}
                          />
                        ) : (
                          <span className="inline-block h-4 w-4" />
                        )}
                      </TD>
                    )}
                    <TD className="tabular whitespace-nowrap text-slate-600">{fmtDateTime(r.createdAt)}</TD>
                    <TD className="whitespace-nowrap">
                      <div className="font-medium text-slate-900">{r.employeeName}</div>
                      <div className="text-[11px] text-slate-500">
                        {r.employeeCode}
                        {r.departmentName && ` · ${r.departmentName}`}
                      </div>
                    </TD>
                    <TD className="whitespace-nowrap">{REQUEST_TYPE_LABEL[r.requestType]}</TD>
                    <TD className="tabular whitespace-nowrap">
                      {fmtDateShort(r.targetDateFrom)}
                      {r.targetDateTo !== r.targetDateFrom && <> – {fmtDateShort(r.targetDateTo)}</>}
                    </TD>
                    <TD className="max-w-[16rem] truncate">
                      <PayloadSummary request={r} />
                    </TD>
                    <TD className="max-w-[14rem] truncate text-slate-600" title={r.reason}>
                      {r.reason}
                    </TD>
                    <TD>
                      <RequestStatusBadge status={r.status} />
                    </TD>
                    <TD className="whitespace-nowrap text-xs text-slate-600">
                      {currentStepLabel(r)}
                      {can && <span className="ml-1 rounded bg-amber-50 px-1.5 text-[10px] text-amber-700 ring-1 ring-amber-200">要対応</span>}
                    </TD>
                  </TR>
                );
              })}
            </TBody>
          </Table>
        )}
        {list.data && (
          <div className="px-4 pb-3">
            <Pagination page={list.data.page} pageSize={list.data.pageSize} total={list.data.total} onChange={changePage} />
          </div>
        )}
      </Card>

      <RequestDetailDialog request={selected} open={detailOpen} onClose={() => setDetailOpen(false)} onChanged={reloadAll} />

      <ConfirmDialog
        open={bulkOpen}
        onClose={() => !bulkPending && setBulkOpen(false)}
        onConfirm={() => void bulkApprove()}
        title="選択した申請を一括承認しますか？"
        message={
          <div className="space-y-2">
            <p>{checkedRows.length} 件の申請を順に承認します。コメントは付与されません。</p>
            <ul className="max-h-40 list-disc space-y-0.5 overflow-y-auto pl-5 text-xs text-slate-600">
              {checkedRows.map((r) => (
                <li key={r.id}>
                  {r.employeeName} · {REQUEST_TYPE_LABEL[r.requestType]} · {fmtDateShort(r.targetDateFrom)}
                </li>
              ))}
            </ul>
          </div>
        }
        confirmLabel="一括承認"
        pending={bulkPending}
      />
    </div>
  );
}
