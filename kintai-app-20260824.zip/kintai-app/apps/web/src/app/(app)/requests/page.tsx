"use client";

import { Suspense, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Plus } from "lucide-react";
import type { LeaveBalanceDto, Paginated, RequestDto, RequestStatus, RequestType } from "@kintai/shared";
import { LEAVE_TYPE_LABEL, REQUEST_TYPES, REQUEST_TYPE_LABEL } from "@kintai/shared";
import { useApi } from "@/lib/use-api";
import { fmtDateShort, fmtDateTime } from "@/lib/format";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RequestStatusBadge } from "@/components/ui/badge";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { Alert, EmptyState, Loading, PageHeader, Pagination, Tabs } from "@/components/ui/misc";
import { PayloadSummary } from "@/components/requests/payload-summary";
import { RequestDetailDialog } from "@/components/requests/request-detail-dialog";
import { RequestFormDialog } from "@/components/requests/request-form-dialog";

type Tab = "ALL" | "PENDING" | "APPROVED" | "CLOSED";
const PAGE_SIZE = 50;

const TABS: { value: Tab; label: string }[] = [
  { value: "ALL", label: "すべて" },
  { value: "PENDING", label: "承認待ち" },
  { value: "APPROVED", label: "承認済" },
  { value: "CLOSED", label: "却下・取下げ" },
];

function statusParam(tab: Tab): RequestStatus | undefined {
  if (tab === "PENDING") return "PENDING";
  if (tab === "APPROVED") return "APPROVED";
  return undefined;
}

function approvalSummary(r: RequestDto): string {
  const total = r.approvals.length;
  if (total === 0) return "-";
  const approved = r.approvals.filter((a) => a.decision === "APPROVED").length;
  if (r.status === "REJECTED") {
    const rej = r.approvals.find((a) => a.decision === "REJECTED");
    return rej?.approverName ? `${rej.approverName} が却下` : "却下";
  }
  if (r.status === "WITHDRAWN") return "取下げ";
  if (r.status === "APPROVED") return `${approved}/${total} 承認済`;
  const current = r.approvals.find((a) => a.stepNo === r.currentStep);
  const who = current?.approverName ?? (current ? (current.stepNo <= 1 ? "部署管理者" : "労務担当") : null);
  return `${approved}/${total} 承認済${who ? `（${who} 待ち）` : ""}`;
}

function isRequestType(v: string | null): v is RequestType {
  return !!v && (REQUEST_TYPES as readonly string[]).includes(v);
}

interface Prefill {
  type?: RequestType;
  date?: string;
}

function RequestsPageInner({ urlPrefill, onClearUrl }: { urlPrefill: Prefill | null; onClearUrl: () => void }) {
  const [tab, setTab] = useState<Tab>("ALL");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<RequestDto | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  // URL プリフィル (?new=LEAVE&date=YYYY-MM-DD) がある場合はマウント時にダイアログを開く
  const [formOpen, setFormOpen] = useState(!!urlPrefill);
  const [prefill, setPrefill] = useState<Prefill>(urlPrefill ?? {});

  const balances = useApi<LeaveBalanceDto[]>("/leaves/balances");
  const list = useApi<Paginated<RequestDto>>("/requests/mine", {
    page,
    pageSize: PAGE_SIZE,
    status: statusParam(tab),
  });

  const closeForm = () => {
    setFormOpen(false);
    // 再読込時に再度開かないよう URL をクリーンにする
    if (urlPrefill) onClearUrl();
  };

  const rows = useMemo(() => {
    const items = list.data?.items ?? [];
    if (tab === "CLOSED") return items.filter((r) => r.status === "REJECTED" || r.status === "WITHDRAWN");
    return items;
  }, [list.data, tab]);

  const openDetail = (r: RequestDto) => {
    setSelected(r);
    setDetailOpen(true);
  };

  const changeTab = (t: Tab) => {
    setTab(t);
    setPage(1);
  };

  const openNew = () => {
    setPrefill({});
    setFormOpen(true);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="申請"
        description="打刻修正・残業・休暇などの申請と、その承認状況を確認できます。"
        actions={
          <Button onClick={openNew}>
            <Plus className="h-4 w-4" /> 新規申請
          </Button>
        }
      />

      {/* 休暇残日数 */}
      <section>
        <h2 className="mb-3 text-sm font-semibold text-slate-700">休暇残日数</h2>
        {balances.loading && !balances.data ? (
          <Loading label="残日数を取得中..." />
        ) : balances.error && !balances.data ? (
          <Alert tone="error">{balances.error}</Alert>
        ) : !balances.data || balances.data.length === 0 ? (
          <p className="text-sm text-slate-500">休暇の付与情報はありません</p>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {balances.data.map((b) => (
              <Card key={b.leaveType}>
                <CardContent className="pt-4">
                  <p className="text-xs text-slate-500">{LEAVE_TYPE_LABEL[b.leaveType]}</p>
                  <p className="tabular mt-1 text-2xl font-bold">
                    {b.remainingDays} <span className="text-sm font-normal text-slate-500">/ {b.grantedDays} 日</span>
                  </p>
                  <p className="mt-0.5 text-[11px] text-slate-500">
                    使用 {b.usedDays} 日{b.nextExpiry && ` · ${b.nextExpiry.expiresAt} に ${b.nextExpiry.days} 日失効`}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>

      {/* 申請一覧 */}
      <section className="space-y-3">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <h2 className="text-sm font-semibold text-slate-700">申請一覧</h2>
          <Tabs tabs={TABS} value={tab} onChange={changeTab} />
        </div>

        <Card>
          {list.loading && !list.data ? (
            <Loading />
          ) : list.error && !list.data ? (
            <div className="p-4">
              <Alert tone="error">{list.error}</Alert>
            </div>
          ) : rows.length === 0 ? (
            <div className="p-4">
              <EmptyState
                title="申請はありません"
                description={tab === "ALL" ? "「新規申請」から打刻修正や休暇などを申請できます。" : undefined}
                action={
                  tab === "ALL" ? (
                    <Button size="sm" variant="outline" onClick={openNew}>
                      <Plus className="h-4 w-4" /> 新規申請
                    </Button>
                  ) : undefined
                }
              />
            </div>
          ) : (
            <Table>
              <THead>
                <TR>
                  <TH>申請日</TH>
                  <TH>種別</TH>
                  <TH>対象日</TH>
                  <TH>内容</TH>
                  <TH>理由</TH>
                  <TH>状態</TH>
                  <TH>承認状況</TH>
                </TR>
              </THead>
              <TBody>
                {rows.map((r) => (
                  <TR key={r.id} className="cursor-pointer" onClick={() => openDetail(r)}>
                    <TD className="tabular whitespace-nowrap text-slate-600">{fmtDateTime(r.createdAt)}</TD>
                    <TD className="whitespace-nowrap font-medium text-slate-900">{REQUEST_TYPE_LABEL[r.requestType]}</TD>
                    <TD className="tabular whitespace-nowrap">
                      {fmtDateShort(r.targetDateFrom)}
                      {r.targetDateTo !== r.targetDateFrom && <> – {fmtDateShort(r.targetDateTo)}</>}
                    </TD>
                    <TD className="max-w-[16rem] truncate">
                      <PayloadSummary request={r} />
                    </TD>
                    <TD className="max-w-[14rem] truncate text-slate-600" title={r.reason}>
                      {r.reason}
                    </TD>
                    <TD>
                      <RequestStatusBadge status={r.status} />
                    </TD>
                    <TD className="whitespace-nowrap text-xs text-slate-600">{approvalSummary(r)}</TD>
                  </TR>
                ))}
              </TBody>
            </Table>
          )}
          {list.data && (
            <div className="px-4 pb-3">
              <Pagination page={list.data.page} pageSize={list.data.pageSize} total={list.data.total} onChange={setPage} />
            </div>
          )}
        </Card>
      </section>

      <RequestDetailDialog request={selected} open={detailOpen} onClose={() => setDetailOpen(false)} onChanged={() => void list.reload()} />

      <RequestFormDialog
        open={formOpen}
        onClose={closeForm}
        balances={balances.data}
        initialType={prefill.type}
        initialDate={prefill.date}
        onCreated={() => {
          void list.reload();
          void balances.reload();
        }}
      />
    </div>
  );
}

/** useSearchParams を読むためのブリッジ。URL が変わると key によって本体を再マウントしプリフィルを反映する */
function RequestsRoute() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const t = searchParams.get("new");
  const d = searchParams.get("date");
  const urlPrefill: Prefill | null =
    t !== null || d !== null
      ? {
          type: isRequestType(t) ? t : undefined,
          date: d && /^\d{4}-\d{2}-\d{2}$/.test(d) ? d : undefined,
        }
      : null;
  return <RequestsPageInner key={searchParams.toString()} urlPrefill={urlPrefill} onClearUrl={() => router.replace("/requests")} />;
}

export default function RequestsPage() {
  return (
    <Suspense fallback={<Loading />}>
      <RequestsRoute />
    </Suspense>
  );
}
