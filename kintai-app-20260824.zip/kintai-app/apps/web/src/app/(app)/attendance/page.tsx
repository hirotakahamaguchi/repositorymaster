"use client";

import { useState } from "react";
import Link from "next/link";
import { ClipboardList } from "lucide-react";
import type { AttendanceDayDto, HolidayDto, LeaveBalanceDto } from "@kintai/shared";
import { useAuth } from "@/lib/auth";
import { useApi } from "@/lib/use-api";
import { currentYearMonth, fmtYearMonth } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, Loading, MonthNav, PageHeader } from "@/components/ui/misc";
import { DayTable, type AttendanceMonthDto } from "@/components/attendance/day-table";
import { SummaryStats } from "@/components/attendance/summary-stats";
import { DayDetailDialog } from "@/components/attendance/day-detail-dialog";

export default function AttendancePage() {
  const { user } = useAuth();
  const [ym, setYm] = useState(currentYearMonth());
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const { data, error, loading } = useApi<AttendanceMonthDto>("/attendance/me", { month: ym });
  const holidays = useApi<HolidayDto[]>("/holidays", { year: ym.slice(0, 4) });
  const balances = useApi<LeaveBalanceDto[]>("/leaves/balances");

  const selectedDay: AttendanceDayDto | null = data?.days.find((d) => d.id === selectedId) ?? null;
  const paidRemaining = balances.data?.find((b) => b.leaveType === "PAID")?.remainingDays ?? null;
  const flaggedCount = data?.days.filter((d) => d.flags.some((f) => f === "MISSING_IN" || f === "MISSING_OUT" || f === "NO_PUNCH")).length ?? 0;

  return (
    <div className="space-y-5">
      <PageHeader
        title="勤怠照会"
        description={`${user?.name ?? ""}${user?.departmentName ? ` · ${user.departmentName}` : ""} の月次勤怠`}
        actions={
          <>
            <MonthNav value={ym} onChange={setYm} />
            <Link href="/requests" className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 text-xs font-medium text-slate-800 hover:bg-slate-50">
              <ClipboardList className="h-3.5 w-3.5" /> 申請一覧
            </Link>
          </>
        }
      />

      {loading && !data ? (
        <Loading />
      ) : error && !data ? (
        <Alert tone="error">{error}</Alert>
      ) : data ? (
        <>
          <SummaryStats summary={data.summary} paidLeaveRemaining={paidRemaining} />

          {flaggedCount > 0 && (
            <Alert tone="warning" title={`打刻漏れが ${flaggedCount} 日あります`}>
              該当日をクリックして内容を確認し、「打刻修正を申請」から修正申請を行ってください。
            </Alert>
          )}
          {data.summary.status === "LOCKED" && <Alert tone="info">{fmtYearMonth(ym)}は締め処理済みのため、内容は変更できません。</Alert>}

          <Card>
            <CardHeader>
              <CardTitle>{fmtYearMonth(ym)}の日次明細</CardTitle>
              <span className="text-xs text-slate-500">行をクリックすると詳細・打刻・改定履歴を表示します</span>
            </CardHeader>
            <CardContent className="px-0 pb-2">
              <DayTable days={data.days} yearMonth={ym} holidays={holidays.data} onRowClick={(d) => setSelectedId(d.id)} />
            </CardContent>
          </Card>
        </>
      ) : null}

      <DayDetailDialog day={selectedDay} open={!!selectedDay} onClose={() => setSelectedId(null)} showRequestLinks />
    </div>
  );
}
