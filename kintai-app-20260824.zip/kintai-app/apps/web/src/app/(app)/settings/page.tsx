"use client";

import { useState } from "react";
import { KeyRound, Smartphone, UserCircle2 } from "lucide-react";
import { ChangePasswordSchema, ROLE_LABEL } from "@kintai/shared";
import { useAuth } from "@/lib/auth";
import { api, errorMessage } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Field, Input } from "@/components/ui/input";
import { Alert, PageHeader } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { zodFieldErrors } from "@/components/admin/form-utils";

export default function SettingsPage() {
  const { user } = useAuth();
  const toast = useToast();

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = ChangePasswordSchema.safeParse({ currentPassword, newPassword });
    if (!parsed.success) {
      setErrors(zodFieldErrors(parsed.error));
      return;
    }
    if (newPassword !== confirm) {
      setErrors({ confirm: "新しいパスワードが一致しません" });
      return;
    }
    if (newPassword === currentPassword) {
      setErrors({ newPassword: "現在のパスワードと異なるものを設定してください" });
      return;
    }
    setErrors({});
    setPending(true);
    try {
      await api.post("/auth/password", parsed.data);
      toast.success("パスワードを変更しました");
      setCurrentPassword("");
      setNewPassword("");
      setConfirm("");
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setPending(false);
    }
  };

  return (
    <div>
      <PageHeader title="設定" description="アカウント情報の確認とパスワードの変更" />

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserCircle2 className="h-4 w-4 text-brand-600" /> プロフィール
              </CardTitle>
            </CardHeader>
            <CardContent>
              {user ? (
                <dl className="divide-y text-sm">
                  <Row label="氏名">{user.name}</Row>
                  <Row label="社員番号">
                    <span className="tabular">{user.employeeCode}</span>
                  </Row>
                  <Row label="メールアドレス">{user.email}</Row>
                  <Row label="会社">{user.companyName}</Row>
                  <Row label="部署">{user.departmentName ?? <span className="text-slate-400">未所属</span>}</Row>
                  <Row label="ロール">
                    <span className="flex flex-wrap justify-end gap-1">
                      {user.roles.map((r) => (
                        <Badge key={r} tone={r === "ADMIN" ? "violet" : r === "HR" ? "blue" : r === "MANAGER" ? "green" : "gray"}>
                          {ROLE_LABEL[r] ?? r}
                        </Badge>
                      ))}
                    </span>
                  </Row>
                </dl>
              ) : (
                <p className="text-sm text-slate-500">読み込み中...</p>
              )}
              <p className="mt-3 text-xs text-slate-500">氏名・部署などの変更は労務担当者へご依頼ください。</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex-col items-start gap-1">
              <CardTitle className="flex items-center gap-2">
                <Smartphone className="h-4 w-4 text-brand-600" /> スマートフォンで使う（PWA）
              </CardTitle>
              <CardDescription>ホーム画面に追加すると、打刻アプリとしてすぐに起動できます</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-slate-700">
              <div className="rounded-xl bg-slate-50 p-3">
                <p className="font-medium text-slate-800">iPhone (Safari)</p>
                <p className="text-xs text-slate-600">共有ボタン → 「ホーム画面に追加」</p>
              </div>
              <div className="rounded-xl bg-slate-50 p-3">
                <p className="font-medium text-slate-800">Android (Chrome)</p>
                <p className="text-xs text-slate-600">メニュー（⋮）→ 「ホーム画面に追加」または「アプリをインストール」</p>
              </div>
              <p className="text-xs text-slate-500">オフライン時の打刻は端末に保存され、オンライン復帰後に自動送信されます。</p>
            </CardContent>
          </Card>
        </div>

        <Card className="self-start">
          <CardHeader className="flex-col items-start gap-1">
            <CardTitle className="flex items-center gap-2">
              <KeyRound className="h-4 w-4 text-brand-600" /> パスワード変更
            </CardTitle>
            <CardDescription>8文字以上で設定してください</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={submit} className="space-y-4">
              <Field label="現在のパスワード" error={errors.currentPassword}>
                <Input type="password" autoComplete="current-password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required />
              </Field>
              <Field label="新しいパスワード" error={errors.newPassword}>
                <Input type="password" autoComplete="new-password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required minLength={8} maxLength={72} />
              </Field>
              <Field label="新しいパスワード（確認）" error={errors.confirm}>
                <Input type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required minLength={8} maxLength={72} />
              </Field>
              {newPassword && confirm && newPassword !== confirm && <Alert tone="warning">新しいパスワードが一致していません</Alert>}
              <Button type="submit" loading={pending} className="w-full sm:w-auto">
                パスワードを変更
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 py-2">
      <dt className="shrink-0 text-xs text-slate-500">{label}</dt>
      <dd className="text-right text-slate-900">{children}</dd>
    </div>
  );
}
