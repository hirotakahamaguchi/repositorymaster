"use client";

import Link from "next/link";
import { ArrowRight, CalendarDays, ClipboardCheck, ClipboardList, Palmtree } from "lucide-react";
import type { DashboardDto } from "@kintai/shared";
import { LEAVE_TYPE_LABEL, PUNCH_TYPE_LABEL } from "@kintai/shared";
import { useAuth } from "@/lib/auth";
import { useApi } from "@/lib/use-api";
import { fmtTime, fmtYearMonth, minutesToHm } from "@/lib/format";
import { PunchCard } from "@/components/punch-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, Loading, Stat } from "@/components/ui/misc";
import { FlagBadges } from "@/components/ui/badge";

export default function HomePage() {
  const { user, can } = useAuth();
  const { data, error, loading, reload } = useApi<DashboardDto>("/dashboard/me");

  if (loading && !data) return <Loading />;
  if (error && !data) return <Alert tone="error">{error}</Alert>;
  if (!data) return null;

  const s = data.monthSummary;
  const today = data.todayAttendance;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-900 sm:text-2xl">こんにちは、{user?.name} さん</h1>
        <p className="text-sm text-slate-500">
          {user?.departmentName ?? ""} · {fmtYearMonth(s.yearMonth)}の勤怠サマリ
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <PunchCard dashboard={data} onPunched={() => void reload()} />
        </div>
        <div className="space-y-4 lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>本日の打刻</CardTitle>
              <Link href="/attendance" className="text-xs text-brand-600 hover:underline">
                勤怠照会 →
              </Link>
            </CardHeader>
            <CardContent>
              {data.todayPunches.length === 0 ? (
                <p className="text-sm text-slate-500">まだ打刻がありません</p>
              ) : (
                <ul className="divide-y text-sm">
                  {data.todayPunches.map((p) => (
                    <li key={p.id} className="flex items-center justify-between py-1.5">
                      <span className="text-slate-700">{PUNCH_TYPE_LABEL[p.punchType]}</span>
                      <span className="tabular flex items-center gap-2 text-slate-900">
                        {fmtTime(p.punchedAt)}
                        {p.geofenceOk === false && <span className="rounded bg-amber-50 px-1.5 text-[10px] text-amber-700 ring-1 ring-amber-200">エリア外</span>}
                        <span className="text-[10px] text-slate-400">{p.source}</span>
                      </span>
                    </li>
                  ))}
                </ul>
              )}
              {today && (
                <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 rounded-xl bg-slate-50 px-3 py-2 text-xs text-slate-600">
                  <span>
                    実労働 <b className="tabular text-slate-900">{minutesToHm(today.workMinutes)}</b>
                  </span>
                  <span>
                    休憩 <b className="tabular text-slate-900">{minutesToHm(today.breakMinutes)}</b>
                  </span>
                  {today.overtimeMinutes > 0 && (
                    <span>
                      残業 <b className="tabular text-amber-700">{minutesToHm(today.overtimeMinutes)}</b>
                    </span>
                  )}
                  <FlagBadges flags={today.flags} />
                </div>
              )}
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 gap-3">
            <Link href="/requests" className="group">
              <Card className="h-full transition-colors group-hover:border-brand-300">
                <CardContent className="flex items-center gap-3 pt-4">
                  <ClipboardList className="h-5 w-5 text-brand-600" />
                  <div>
                    <p className="text-xs text-slate-500">承認待ちの申請</p>
                    <p className="tabular text-lg font-bold">{data.pendingRequests} 件</p>
                  </div>
                </CardContent>
              </Card>
            </Link>
            {can("request:approve:department", "request:approve:company") ? (
              <Link href="/approvals" className="group">
                <Card className="h-full transition-colors group-hover:border-brand-300">
                  <CardContent className="flex items-center gap-3 pt-4">
                    <ClipboardCheck className="h-5 w-5 text-emerald-600" />
                    <div>
                      <p className="text-xs text-slate-500">あなたの承認待ち</p>
                      <p className="tabular text-lg font-bold">{data.pendingApprovals} 件</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ) : (
              <Card className="h-full">
                <CardContent className="flex items-center gap-3 pt-4">
                  <Palmtree className="h-5 w-5 text-sky-600" />
                  <div>
                    <p className="text-xs text-slate-500">有給残</p>
                    <p className="tabular text-lg font-bold">{data.leaveBalances.find((b) => b.leaveType === "PAID")?.remainingDays ?? 0} 日</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-sm font-semibold text-slate-700">
            <CalendarDays className="h-4 w-4" /> {fmtYearMonth(s.yearMonth)}の実績
          </h2>
          <Link href="/attendance" className="inline-flex items-center gap-1 text-xs text-brand-600 hover:underline">
            詳細を見る <ArrowRight className="h-3 w-3" />
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <Stat label="出勤日数" value={`${s.actualWorkDays}`} sub={`所定 ${s.scheduledDays} 日`} />
          <Stat label="総労働時間" value={minutesToHm(s.workMinutes)} />
          <Stat label="残業（法定外）" value={minutesToHm(s.legalOvertimeMinutes)} tone={s.alerts.includes("OVERTIME_LIMIT") ? "danger" : s.alerts.includes("OVERTIME_WARN") ? "warn" : "default"} sub={s.alerts.includes("OVERTIME_WARN") ? "45h 超過注意" : undefined} />
          <Stat label="深夜労働" value={minutesToHm(s.lateNightMinutes)} />
          <Stat label="遅刻 / 早退" value={`${s.lateCount} / ${s.earlyLeaveCount}`} tone={s.lateCount + s.earlyLeaveCount > 0 ? "warn" : "default"} />
          <Stat label="有給取得" value={`${s.paidLeaveDays} 日`} sub={`残 ${data.leaveBalances.find((b) => b.leaveType === "PAID")?.remainingDays ?? 0} 日`} />
        </div>
        {s.alerts.includes("MISSING_PUNCH") && (
          <Alert tone="warning" className="mt-3" title="打刻漏れがあります">
            勤怠照会から該当日を確認し、打刻修正申請を行ってください。
          </Alert>
        )}
      </section>

      {data.leaveBalances.length > 0 && (
        <section>
          <h2 className="mb-3 text-sm font-semibold text-slate-700">休暇残日数</h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {data.leaveBalances.map((b) => (
              <Card key={b.leaveType}>
                <CardContent className="pt-4">
                  <p className="text-xs text-slate-500">{LEAVE_TYPE_LABEL[b.leaveType]}</p>
                  <p className="tabular mt-1 text-2xl font-bold">
                    {b.remainingDays} <span className="text-sm font-normal text-slate-500">/ {b.grantedDays} 日</span>
                  </p>
                  {b.nextExpiry && <p className="mt-0.5 text-[11px] text-slate-500">{b.nextExpiry.expiresAt} に {b.nextExpiry.days} 日失効</p>}
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
