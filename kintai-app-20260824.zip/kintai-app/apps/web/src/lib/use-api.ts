"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api, errorMessage } from "./api";

type Query = Record<string, string | number | boolean | undefined | null>;

/** 軽量データ取得フック（SWR 風）。path が null のときは取得しない */
export function useApi<T>(path: string | null, query?: Query, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(!!path);
  const seq = useRef(0);
  const queryKey = JSON.stringify(query ?? {});
  const depsKey = JSON.stringify(deps);

  const reload = useCallback(async () => {
    if (!path) {
      setData(null);
      setLoading(false);
      return;
    }
    const my = ++seq.current;
    setLoading(true);
    try {
      const res = await api.get<T>(path, query);
      if (my === seq.current) {
        setData(res);
        setError(null);
      }
    } catch (e) {
      if (my === seq.current) setError(errorMessage(e));
    } finally {
      if (my === seq.current) setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, queryKey, depsKey]);

  useEffect(() => {
    queueMicrotask(() => void reload());
  }, [reload]);

  return { data, error, loading, reload, setData };
}

/** 送信系アクションのローディング/エラー管理 */
export function useAction<A extends unknown[], R>(fn: (...args: A) => Promise<R>) {
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const run = useCallback(
    async (...args: A): Promise<R | undefined> => {
      setPending(true);
      setError(null);
      try {
        return await fn(...args);
      } catch (e) {
        setError(errorMessage(e));
        throw e;
      } finally {
        setPending(false);
      }
    },
    [fn],
  );
  return { run, pending, error, setError };
}
