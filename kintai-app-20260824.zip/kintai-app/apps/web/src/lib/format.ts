import { minutesToHm, toLocalTime, WEEKDAY_JA } from "@kintai/shared";

export const TZ = "Asia/Tokyo";

export { minutesToHm };

export function fmtTime(iso: string | null | undefined): string {
  return toLocalTime(iso ?? null, TZ);
}

export function fmtDateTime(iso: string | null | undefined): string {
  if (!iso) return "-";
  const d = new Date(iso);
  return new Intl.DateTimeFormat("ja-JP", { timeZone: TZ, month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false }).format(d);
}

export function fmtDateTimeFull(iso: string | null | undefined): string {
  if (!iso) return "-";
  const d = new Date(iso);
  return new Intl.DateTimeFormat("ja-JP", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).format(d);
}

/** "2026-08-21" → "8/21(金)" */
export function fmtDateShort(isoDate: string): string {
  const [y, m, d] = isoDate.split("-").map(Number);
  const wd = new Date(Date.UTC(y, m - 1, d)).getUTCDay();
  return `${m}/${d}(${WEEKDAY_JA[wd]})`;
}

export function fmtDate(isoDate: string | null | undefined): string {
  if (!isoDate) return "-";
  const [y, m, d] = isoDate.split("-").map(Number);
  const wd = new Date(Date.UTC(y, m - 1, d)).getUTCDay();
  return `${y}/${m}/${d}(${WEEKDAY_JA[wd]})`;
}

export function fmtYearMonth(ym: string): string {
  const [y, m] = ym.split("-");
  return `${y}年${Number(m)}月`;
}

export function weekdayOf(isoDate: string): number {
  const [y, m, d] = isoDate.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
}

export function todayLocal(): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}

export function currentYearMonth(): string {
  return todayLocal().slice(0, 7);
}

/** "2026-08-21" + "HH:mm"(JST) → ISO(UTC) */
export function localToIso(isoDate: string, hm: string): string {
  return new Date(`${isoDate}T${hm}:00+09:00`).toISOString();
}

/** ISO → "HH:mm"(JST) input 用 */
export function isoToHm(iso: string | null | undefined): string {
  if (!iso) return "";
  return fmtTime(iso);
}

export function fmtHours(min: number): string {
  return `${(min / 60).toFixed(1)}h`;
}
