"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import type { CurrentUser, Permission } from "@kintai/shared";
import { api } from "./api";

interface AuthState {
  user: CurrentUser | null;
  loading: boolean;
  refresh: () => Promise<void>;
  login: (email: string, password: string) => Promise<CurrentUser>;
  logout: () => Promise<void>;
  can: (...perms: Permission[]) => boolean;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<CurrentUser | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  const refresh = useCallback(async () => {
    try {
      const me = await api.get<CurrentUser>("/auth/me");
      setUser(me);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    // 初回マウント時にセッションを復元（effect 内の同期 setState を避けるためマイクロタスクで実行）
    queueMicrotask(() => void refresh());
  }, [refresh]);

  useEffect(() => {
    const handler = () => {
      setUser(null);
      if (!pathname.startsWith("/login")) router.replace(`/login?next=${encodeURIComponent(pathname)}`);
    };
    window.addEventListener("kintai:unauthorized", handler);
    return () => window.removeEventListener("kintai:unauthorized", handler);
  }, [pathname, router]);

  const login = useCallback(async (email: string, password: string) => {
    const res = await api.post<{ user: CurrentUser }>("/auth/login", { email, password });
    setUser(res.user);
    return res.user;
  }, []);

  const logout = useCallback(async () => {
    try {
      await api.post("/auth/logout");
    } finally {
      setUser(null);
      router.replace("/login");
    }
  }, [router]);

  const can = useCallback((...perms: Permission[]) => !!user && perms.some((p) => user.permissions.includes(p)), [user]);

  const value = useMemo(() => ({ user, loading, refresh, login, logout, can }), [user, loading, refresh, login, logout, can]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
