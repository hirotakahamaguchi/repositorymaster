import type { ApiError } from "@kintai/shared";

export class ApiRequestError extends Error {
  status: number;
  body: ApiError | null;
  constructor(status: number, body: ApiError | null, message: string) {
    super(message);
    this.status = status;
    this.body = body;
  }
  get issues() {
    return this.body?.issues ?? [];
  }
}

const BASE = "/api";

function buildUrl(path: string, query?: Record<string, string | number | boolean | undefined | null>) {
  const url = path.startsWith("/") ? `${BASE}${path}` : `${BASE}/${path}`;
  if (!query) return url;
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(query)) if (v !== undefined && v !== null && v !== "") sp.set(k, String(v));
  const qs = sp.toString();
  return qs ? `${url}?${qs}` : url;
}

async function request<T>(method: string, path: string, opts: { body?: unknown; query?: Record<string, string | number | boolean | undefined | null> } = {}): Promise<T> {
  const res = await fetch(buildUrl(path, opts.query), {
    method,
    headers: opts.body !== undefined ? { "Content-Type": "application/json" } : undefined,
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    credentials: "same-origin",
    cache: "no-store",
  });
  if (res.status === 204) return undefined as T;
  const text = await res.text();
  let json: unknown = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = null;
  }
  if (!res.ok) {
    const body = (json as ApiError) ?? null;
    const msg = Array.isArray(body?.message) ? body!.message.join(", ") : body?.message ?? `HTTP ${res.status}`;
    if (res.status === 401 && typeof window !== "undefined" && !location.pathname.startsWith("/login")) {
      window.dispatchEvent(new CustomEvent("kintai:unauthorized"));
    }
    throw new ApiRequestError(res.status, body, msg);
  }
  return json as T;
}

export const api = {
  get: <T>(path: string, query?: Record<string, string | number | boolean | undefined | null>) => request<T>("GET", path, { query }),
  post: <T>(path: string, body?: unknown, query?: Record<string, string | number | boolean | undefined | null>) => request<T>("POST", path, { body, query }),
  put: <T>(path: string, body?: unknown) => request<T>("PUT", path, { body }),
  patch: <T>(path: string, body?: unknown) => request<T>("PATCH", path, { body }),
  delete: <T>(path: string) => request<T>("DELETE", path),
  /** バイナリ（CSV ダウンロード等） */
  blob: async (path: string, query?: Record<string, string | number | boolean | undefined | null>) => {
    const res = await fetch(buildUrl(path, query), { credentials: "same-origin" });
    if (!res.ok) throw new ApiRequestError(res.status, null, `HTTP ${res.status}`);
    const cd = res.headers.get("content-disposition") ?? "";
    const m = /filename\*=UTF-8''([^;]+)/.exec(cd) ?? /filename="?([^";]+)"?/.exec(cd);
    return { blob: await res.blob(), fileName: m ? decodeURIComponent(m[1]) : "download" };
  },
};

export function errorMessage(e: unknown): string {
  if (e instanceof ApiRequestError) {
    if (e.issues.length) return `${e.message}: ${e.issues.map((i) => `${i.path} ${i.message}`).join(" / ")}`;
    return e.message;
  }
  if (e instanceof Error) return e.message;
  return String(e);
}
