"use client";

import type { CreatePunchInput, PunchDto } from "@kintai/shared";
import { api } from "./api";

/**
 * オフライン打刻キュー
 *  - ネットワーク断で送信できなかった打刻を localStorage に保持し、復帰時に再送する
 *  - clientRequestId による冪等性でサーバ側の二重登録を防ぐ
 */
const KEY = "kintai.punchQueue.v1";

export interface QueuedPunch extends CreatePunchInput {
  queuedAt: string;
}

export function loadQueue(): QueuedPunch[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(KEY) ?? "[]") as QueuedPunch[];
  } catch {
    return [];
  }
}

function saveQueue(q: QueuedPunch[]) {
  localStorage.setItem(KEY, JSON.stringify(q));
}

export function enqueue(p: CreatePunchInput) {
  const q = loadQueue();
  q.push({ ...p, queuedAt: new Date().toISOString() });
  saveQueue(q);
}

/** キューを順に再送。成功したものはキューから除去 */
export async function flushQueue(): Promise<{ sent: PunchDto[]; remaining: number }> {
  const q = loadQueue();
  const sent: PunchDto[] = [];
  const rest: QueuedPunch[] = [];
  for (const item of q) {
    try {
      const { queuedAt, ...body } = item;
      void queuedAt;
      const res = await api.post<{ punch: PunchDto }>("/punches", body);
      sent.push(res.punch);
    } catch (e) {
      // 4xx（バリデーション等）は破棄、それ以外は保持して再試行
      const status = (e as { status?: number }).status;
      if (!status || status >= 500) rest.push(item);
    }
  }
  saveQueue(rest);
  return { sent, remaining: rest.length };
}
