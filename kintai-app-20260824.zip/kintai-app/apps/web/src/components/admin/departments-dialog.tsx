"use client";

import { useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import type { DepartmentDto, EmployeeDto, Paginated } from "@kintai/shared";
import { UpsertDepartmentSchema } from "@kintai/shared";
import { api, errorMessage } from "@/lib/api";
import { useApi } from "@/lib/use-api";
import { Button } from "@/components/ui/button";
import { ConfirmDialog, Dialog } from "@/components/ui/dialog";
import { Field, Input, Select } from "@/components/ui/input";
import { Alert, EmptyState, Loading } from "@/components/ui/misc";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { useToast } from "@/components/ui/toast";
import { zodFieldErrors } from "./form-utils";

interface DeptForm {
  code: string;
  name: string;
  parentId: string;
  managerId: string;
}

const EMPTY: DeptForm = { code: "", name: "", parentId: "", managerId: "" };

export function DepartmentsDialog({ open, onClose, canWrite, onChanged }: { open: boolean; onClose: () => void; canWrite: boolean; onChanged: () => void }) {
  return (
    <Dialog open={open} onClose={onClose} title="部署管理" description="部署の追加・編集・削除を行います" size="lg">
      {/* Dialog は閉じると子を unmount するため、開くたびに状態がリセットされる */}
      <DepartmentsBody canWrite={canWrite} onChanged={onChanged} />
    </Dialog>
  );
}

function DepartmentsBody({ canWrite, onChanged }: { canWrite: boolean; onChanged: () => void }) {
  const toast = useToast();
  const { data: departments, loading, error, reload } = useApi<DepartmentDto[]>("/departments");
  const { data: employeesPage } = useApi<Paginated<EmployeeDto>>("/employees", { pageSize: 500 });
  const employees = employeesPage?.items ?? [];

  /** null = フォーム非表示, "new" = 新規, それ以外 = 編集対象ID */
  const [editing, setEditing] = useState<"new" | string | null>(null);
  const [form, setForm] = useState<DeptForm>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);
  const [deleting, setDeleting] = useState<DepartmentDto | null>(null);
  const [deletePending, setDeletePending] = useState(false);

  const startNew = () => {
    setEditing("new");
    setForm(EMPTY);
    setErrors({});
  };
  const startEdit = (d: DepartmentDto) => {
    setEditing(d.id);
    setForm({ code: d.code, name: d.name, parentId: d.parentId ?? "", managerId: d.managerId ?? "" });
    setErrors({});
  };
  const cancel = () => {
    setEditing(null);
    setForm(EMPTY);
    setErrors({});
  };

  const changed = async () => {
    await reload();
    onChanged();
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = UpsertDepartmentSchema.safeParse({
      code: form.code.trim(),
      name: form.name.trim(),
      parentId: form.parentId || null,
      managerId: form.managerId || null,
    });
    if (!parsed.success) {
      setErrors(zodFieldErrors(parsed.error));
      return;
    }
    setErrors({});
    setPending(true);
    try {
      if (editing === "new") {
        await api.post("/departments", parsed.data);
        toast.success("部署を追加しました");
      } else {
        await api.put(`/departments/${editing}`, parsed.data);
        toast.success("部署を更新しました");
      }
      cancel();
      await changed();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setPending(false);
    }
  };

  const remove = async () => {
    if (!deleting) return;
    setDeletePending(true);
    try {
      await api.delete(`/departments/${deleting.id}`);
      toast.success("部署を削除しました");
      setDeleting(null);
      await changed();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setDeletePending(false);
    }
  };

  const parentOptions = (departments ?? []).filter((d) => d.id !== editing);

  return (
    <>
      <div className="space-y-4">
        {loading && !departments ? (
          <Loading />
        ) : error ? (
          <Alert tone="error">{error}</Alert>
        ) : !departments || departments.length === 0 ? (
          <EmptyState title="部署が登録されていません" action={canWrite && editing === null ? <Button size="sm" onClick={startNew}>部署を追加</Button> : undefined} />
        ) : (
          <Table>
            <THead>
              <TR>
                <TH>コード</TH>
                <TH>部署名</TH>
                <TH>上位部署</TH>
                <TH>責任者</TH>
                <TH className="text-right">人数</TH>
                {canWrite && <TH className="w-20"></TH>}
              </TR>
            </THead>
            <TBody>
              {departments.map((d) => (
                <TR key={d.id} className={editing === d.id ? "bg-brand-50/40" : undefined}>
                  <TD className="tabular text-slate-600">{d.code}</TD>
                  <TD className="font-medium text-slate-900">{d.name}</TD>
                  <TD className="text-slate-600">{departments.find((p) => p.id === d.parentId)?.name ?? <span className="text-slate-400">-</span>}</TD>
                  <TD className="text-slate-600">{d.managerName ?? <span className="text-slate-400">未設定</span>}</TD>
                  <TD className="tabular text-right">{d.headcount}</TD>
                  {canWrite && (
                    <TD>
                      <div className="flex items-center justify-end gap-1">
                        <button type="button" onClick={() => startEdit(d)} className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700" aria-label="編集">
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button type="button" onClick={() => setDeleting(d)} className="rounded-md p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600" aria-label="削除">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </TD>
                  )}
                </TR>
              ))}
            </TBody>
          </Table>
        )}

        {canWrite && editing === null && departments && departments.length > 0 && (
          <div className="flex justify-end">
            <Button size="sm" variant="outline" onClick={startNew}>
              <Plus className="h-4 w-4" /> 部署を追加
            </Button>
          </div>
        )}

        {canWrite && editing !== null && (
          <form onSubmit={submit} className="rounded-xl border bg-slate-50 p-4">
            <p className="mb-3 text-sm font-semibold text-slate-700">{editing === "new" ? "部署を追加" : "部署を編集"}</p>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="コード" error={errors.code}>
                <Input value={form.code} onChange={(e) => setForm((f) => ({ ...f, code: e.target.value }))} required maxLength={20} />
              </Field>
              <Field label="部署名" error={errors.name}>
                <Input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} required maxLength={100} />
              </Field>
              <Field label="上位部署" error={errors.parentId}>
                <Select value={form.parentId} onChange={(e) => setForm((f) => ({ ...f, parentId: e.target.value }))}>
                  <option value="">（なし）</option>
                  {parentOptions.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="責任者" error={errors.managerId}>
                <Select value={form.managerId} onChange={(e) => setForm((f) => ({ ...f, managerId: e.target.value }))}>
                  <option value="">（未設定）</option>
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name}（{emp.employeeCode}）
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
            <div className="mt-3 flex justify-end gap-2">
              <Button type="button" size="sm" variant="outline" onClick={cancel}>
                キャンセル
              </Button>
              <Button type="submit" size="sm" loading={pending}>
                {editing === "new" ? "追加" : "保存"}
              </Button>
            </div>
          </form>
        )}
        {!canWrite && <Alert tone="info">部署の編集にはマスタ編集権限が必要です</Alert>}
      </div>

      <ConfirmDialog
        open={!!deleting}
        onClose={() => setDeleting(null)}
        onConfirm={() => void remove()}
        title="部署を削除"
        message={
          deleting ? (
            <>
              「{deleting.name}」（{deleting.code}）を削除します。
              {deleting.headcount > 0 && <span className="mt-1 block text-amber-700">所属している {deleting.headcount} 名の部署は未所属になります。</span>}
            </>
          ) : (
            ""
          )
        }
        confirmLabel="削除"
        danger
        pending={deletePending}
      />
    </>
  );
}
