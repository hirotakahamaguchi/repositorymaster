"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { CalendarRange, Trash2 } from "lucide-react";
import type { DepartmentDto, EmployeeDto, LeaveBalanceDto, LeaveType, RoleCode, WorkPatternAssignmentDto, WorkPatternDto } from "@kintai/shared";
import { LEAVE_TYPES, LEAVE_TYPE_LABEL, ROLE_CODES, ROLE_LABEL, UpsertEmployeeSchema, GrantLeaveSchema, AssignWorkPatternSchema } from "@kintai/shared";
import { api, errorMessage } from "@/lib/api";
import { useApi } from "@/lib/use-api";
import { fmtDate, todayLocal } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { ConfirmDialog, Dialog } from "@/components/ui/dialog";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/input";
import { Alert, EmptyState, Loading, Tabs } from "@/components/ui/misc";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { useToast } from "@/components/ui/toast";
import { addYears, zodFieldErrors } from "./form-utils";

type TabKey = "basic" | "patterns" | "leaves";

interface LeaveGrantDto {
  id: string;
  employeeId: string;
  leaveType: LeaveType;
  days: string | number;
  grantedAt: string;
  expiresAt: string;
  note: string | null;
}

interface BasicForm {
  employeeCode: string;
  name: string;
  nameKana: string;
  email: string;
  departmentId: string;
  hiredAt: string;
  retiredAt: string;
  roleCodes: RoleCode[];
  workPatternId: string;
  password: string;
}

function initialForm(emp: EmployeeDto | null): BasicForm {
  return {
    employeeCode: emp?.employeeCode ?? "",
    name: emp?.name ?? "",
    nameKana: emp?.nameKana ?? "",
    email: emp?.email ?? "",
    departmentId: emp?.departmentId ?? "",
    hiredAt: emp?.hiredAt ?? todayLocal(),
    retiredAt: emp?.retiredAt ?? "",
    roleCodes: emp?.roles?.length ? [...emp.roles] : ["EMPLOYEE"],
    workPatternId: emp?.currentWorkPattern?.id ?? "",
    password: "",
  };
}

export function EmployeeDialog({
  open,
  onClose,
  employee,
  departments,
  workPatterns,
  canWrite,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  /** null = 新規登録 */
  employee: EmployeeDto | null;
  departments: DepartmentDto[];
  workPatterns: WorkPatternDto[];
  canWrite: boolean;
  onSaved: () => void;
}) {
  const isCreate = !employee;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={isCreate ? "従業員の新規登録" : `${employee.name}（${employee.employeeCode}）`}
      description={isCreate ? "初期パスワードを設定して登録します" : employee.departmentName ?? undefined}
      size="lg"
    >
      {/* Dialog は閉じると子を unmount するため、開くたびに状態がリセットされる */}
      <DialogBody key={employee?.id ?? "new"} employee={employee} departments={departments} workPatterns={workPatterns} canWrite={canWrite} onSaved={onSaved} onClose={onClose} />
    </Dialog>
  );
}

function DialogBody({
  employee,
  departments,
  workPatterns,
  canWrite,
  onSaved,
  onClose,
}: {
  employee: EmployeeDto | null;
  departments: DepartmentDto[];
  workPatterns: WorkPatternDto[];
  canWrite: boolean;
  onSaved: () => void;
  onClose: () => void;
}) {
  const isCreate = !employee;
  const [tab, setTab] = useState<TabKey>("basic");
  const tabs: { value: TabKey; label: string }[] = isCreate
    ? [{ value: "basic", label: "基本情報" }]
    : [
        { value: "basic", label: "基本情報" },
        { value: "patterns", label: "勤務パターン履歴" },
        { value: "leaves", label: "休暇付与" },
      ];

  return (
    <div className="space-y-4">
      {!isCreate && (
        <div className="flex flex-wrap items-center justify-between gap-2">
          <Tabs tabs={tabs} value={tab} onChange={setTab} />
          <Link href={`/admin/attendance/${employee.id}`} className="inline-flex items-center gap-1 text-xs text-brand-600 hover:underline">
            <CalendarRange className="h-3.5 w-3.5" /> 勤怠を見る
          </Link>
        </div>
      )}
      {tab === "basic" && <BasicTab employee={employee} departments={departments} workPatterns={workPatterns} canWrite={canWrite} onSaved={onSaved} onClose={onClose} />}
      {tab === "patterns" && employee && <PatternsTab employeeId={employee.id} workPatterns={workPatterns} canWrite={canWrite} onChanged={onSaved} />}
      {tab === "leaves" && employee && <LeavesTab employeeId={employee.id} canWrite={canWrite} />}
    </div>
  );
}

// ─── 基本情報 ──────────────────────────────────────────────────────
function BasicTab({
  employee,
  departments,
  workPatterns,
  canWrite,
  onSaved,
  onClose,
}: {
  employee: EmployeeDto | null;
  departments: DepartmentDto[];
  workPatterns: WorkPatternDto[];
  canWrite: boolean;
  onSaved: () => void;
  onClose: () => void;
}) {
  const toast = useToast();
  const isCreate = !employee;
  const [form, setForm] = useState<BasicForm>(() => initialForm(employee));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);
  const readOnly = !canWrite;

  const set = <K extends keyof BasicForm>(k: K, v: BasicForm[K]) => setForm((f) => ({ ...f, [k]: v }));
  const toggleRole = (r: RoleCode) =>
    setForm((f) => ({ ...f, roleCodes: f.roleCodes.includes(r) ? f.roleCodes.filter((x) => x !== r) : [...f.roleCodes, r] }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (readOnly) return;
    const body = {
      employeeCode: form.employeeCode.trim(),
      name: form.name.trim(),
      nameKana: form.nameKana.trim() || undefined,
      email: form.email.trim(),
      departmentId: form.departmentId || null,
      hiredAt: form.hiredAt,
      retiredAt: form.retiredAt || null,
      roleCodes: form.roleCodes,
      workPatternId: form.workPatternId || undefined,
      password: form.password || undefined,
    };
    const parsed = UpsertEmployeeSchema.safeParse(body);
    if (!parsed.success) {
      setErrors(zodFieldErrors(parsed.error));
      return;
    }
    if (isCreate && !parsed.data.password) {
      setErrors({ password: "新規登録時はパスワードが必須です（8文字以上）" });
      return;
    }
    setErrors({});
    setPending(true);
    try {
      if (isCreate) {
        await api.post("/employees", parsed.data);
        toast.success("従業員を登録しました");
      } else {
        await api.put(`/employees/${employee.id}`, parsed.data);
        toast.success("従業員情報を更新しました");
      }
      onSaved();
      onClose();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setPending(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="社員番号" error={errors.employeeCode}>
          <Input value={form.employeeCode} onChange={(e) => set("employeeCode", e.target.value)} disabled={readOnly} required maxLength={20} />
        </Field>
        <Field label="メールアドレス" error={errors.email}>
          <Input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} disabled={readOnly} required />
        </Field>
        <Field label="氏名" error={errors.name}>
          <Input value={form.name} onChange={(e) => set("name", e.target.value)} disabled={readOnly} required maxLength={100} />
        </Field>
        <Field label="氏名（カナ）" error={errors.nameKana}>
          <Input value={form.nameKana} onChange={(e) => set("nameKana", e.target.value)} disabled={readOnly} maxLength={100} />
        </Field>
        <Field label="部署" error={errors.departmentId}>
          <Select value={form.departmentId} onChange={(e) => set("departmentId", e.target.value)} disabled={readOnly}>
            <option value="">（未所属）</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="勤務パターン" error={errors.workPatternId} hint={isCreate ? "入社日から適用されます" : "変更すると本日から新しい割当が追加されます"}>
          <Select value={form.workPatternId} onChange={(e) => set("workPatternId", e.target.value)} disabled={readOnly}>
            <option value="">（未設定）</option>
            {workPatterns.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}（{w.code}）
              </option>
            ))}
          </Select>
        </Field>
        <Field label="入社日" error={errors.hiredAt}>
          <Input type="date" value={form.hiredAt} onChange={(e) => set("hiredAt", e.target.value)} disabled={readOnly} required />
        </Field>
        <Field label="退職日" error={errors.retiredAt} hint="在籍中は空欄">
          <Input type="date" value={form.retiredAt} onChange={(e) => set("retiredAt", e.target.value)} disabled={readOnly} />
        </Field>
      </div>
      <Field label="ロール" error={errors.roleCodes}>
        <div className="flex flex-wrap gap-x-5 gap-y-2 rounded-lg border border-slate-200 px-3 py-2.5">
          {ROLE_CODES.map((r) => (
            <Checkbox key={r} label={ROLE_LABEL[r]} checked={form.roleCodes.includes(r)} onChange={() => toggleRole(r)} disabled={readOnly} />
          ))}
        </div>
      </Field>
      {!readOnly && (
        <Field label={isCreate ? "初期パスワード" : "パスワード"} error={errors.password} hint="8文字以上">
          <Input
            type="password"
            autoComplete="new-password"
            value={form.password}
            onChange={(e) => set("password", e.target.value)}
            placeholder={isCreate ? "8文字以上" : "変更する場合のみ"}
            minLength={8}
            required={isCreate}
          />
        </Field>
      )}
      {readOnly && <Alert tone="info">閲覧のみ可能です（編集権限がありません）</Alert>}
      <div className="flex justify-end gap-2 border-t pt-4">
        <Button type="button" variant="outline" onClick={onClose}>
          閉じる
        </Button>
        {!readOnly && (
          <Button type="submit" loading={pending}>
            {isCreate ? "登録" : "保存"}
          </Button>
        )}
      </div>
    </form>
  );
}

// ─── 勤務パターン履歴 ──────────────────────────────────────────────
function PatternsTab({ employeeId, workPatterns, canWrite, onChanged }: { employeeId: string; workPatterns: WorkPatternDto[]; canWrite: boolean; onChanged: () => void }) {
  const toast = useToast();
  const { data, loading, error, reload } = useApi<WorkPatternAssignmentDto[]>("/work-patterns/assignments", { employeeId });
  const [workPatternId, setWorkPatternId] = useState("");
  const [validFrom, setValidFrom] = useState(todayLocal());
  const [validTo, setValidTo] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);
  const [deleting, setDeleting] = useState<WorkPatternAssignmentDto | null>(null);
  const [deletePending, setDeletePending] = useState(false);

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = AssignWorkPatternSchema.safeParse({ employeeId, workPatternId, validFrom, validTo: validTo || null });
    if (!parsed.success) {
      setErrors(zodFieldErrors(parsed.error));
      return;
    }
    setErrors({});
    setPending(true);
    try {
      await api.post("/work-patterns/assignments", parsed.data);
      toast.success("勤務パターンを割り当てました");
      setWorkPatternId("");
      setValidTo("");
      await reload();
      onChanged();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setPending(false);
    }
  };

  const remove = async () => {
    if (!deleting) return;
    setDeletePending(true);
    try {
      await api.delete(`/work-patterns/assignments/${deleting.id}`);
      toast.success("割当を削除しました");
      setDeleting(null);
      await reload();
      onChanged();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setDeletePending(false);
    }
  };

  return (
    <div className="space-y-4">
      {loading && !data ? (
        <Loading />
      ) : error ? (
        <Alert tone="error">{error}</Alert>
      ) : !data || data.length === 0 ? (
        <EmptyState title="勤務パターンの割当がありません" />
      ) : (
        <Table>
          <THead>
            <TR>
              <TH>勤務パターン</TH>
              <TH>適用開始</TH>
              <TH>適用終了</TH>
              {canWrite && <TH className="w-12"></TH>}
            </TR>
          </THead>
          <TBody>
            {data.map((a) => (
              <TR key={a.id}>
                <TD className="font-medium text-slate-900">{a.workPatternName}</TD>
                <TD className="tabular">{fmtDate(a.validFrom)}</TD>
                <TD className="tabular">{a.validTo ? fmtDate(a.validTo) : <span className="text-slate-400">（継続中）</span>}</TD>
                {canWrite && (
                  <TD>
                    <button type="button" onClick={() => setDeleting(a)} className="rounded-md p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600" aria-label="削除">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </TD>
                )}
              </TR>
            ))}
          </TBody>
        </Table>
      )}

      {canWrite && (
        <form onSubmit={add} className="rounded-xl border bg-slate-50 p-4">
          <p className="mb-3 text-sm font-semibold text-slate-700">割当を追加</p>
          <div className="grid gap-3 sm:grid-cols-4">
            <Field label="勤務パターン" error={errors.workPatternId} className="sm:col-span-2">
              <Select value={workPatternId} onChange={(e) => setWorkPatternId(e.target.value)} required>
                <option value="">選択してください</option>
                {workPatterns.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.name}（{w.code}）
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="適用開始" error={errors.validFrom}>
              <Input type="date" value={validFrom} onChange={(e) => setValidFrom(e.target.value)} required />
            </Field>
            <Field label="適用終了（任意）" error={errors.validTo}>
              <Input type="date" value={validTo} onChange={(e) => setValidTo(e.target.value)} />
            </Field>
          </div>
          <div className="mt-3 flex justify-end">
            <Button type="submit" size="sm" loading={pending}>
              追加
            </Button>
          </div>
        </form>
      )}

      <ConfirmDialog
        open={!!deleting}
        onClose={() => setDeleting(null)}
        onConfirm={() => void remove()}
        title="割当を削除"
        message={deleting ? `「${deleting.workPatternName}」（${fmtDate(deleting.validFrom)}〜）の割当を削除します。よろしいですか？` : ""}
        confirmLabel="削除"
        danger
        pending={deletePending}
      />
    </div>
  );
}

// ─── 休暇付与 ──────────────────────────────────────────────────────
function LeavesTab({ employeeId, canWrite }: { employeeId: string; canWrite: boolean }) {
  const toast = useToast();
  const balances = useApi<LeaveBalanceDto[]>("/leaves/balances", { employeeId });
  const grants = useApi<LeaveGrantDto[]>("/leaves/grants", { employeeId });
  const today = useMemo(() => todayLocal(), []);
  const [leaveType, setLeaveType] = useState<LeaveType>("PAID");
  const [days, setDays] = useState("10");
  const [grantedAt, setGrantedAt] = useState(today);
  const [expiresAt, setExpiresAt] = useState(addYears(today, 2));
  const [note, setNote] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);
  const [deleting, setDeleting] = useState<LeaveGrantDto | null>(null);
  const [deletePending, setDeletePending] = useState(false);

  const reloadAll = async () => {
    await Promise.all([balances.reload(), grants.reload()]);
  };

  const grant = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = GrantLeaveSchema.safeParse({ employeeId, leaveType, days: Number(days), grantedAt, expiresAt, note: note.trim() || undefined });
    if (!parsed.success) {
      setErrors(zodFieldErrors(parsed.error));
      return;
    }
    setErrors({});
    setPending(true);
    try {
      await api.post("/leaves/grants", parsed.data);
      toast.success("休暇を付与しました");
      setNote("");
      await reloadAll();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setPending(false);
    }
  };

  const remove = async () => {
    if (!deleting) return;
    setDeletePending(true);
    try {
      await api.delete(`/leaves/grants/${deleting.id}`);
      toast.success("付与を取り消しました");
      setDeleting(null);
      await reloadAll();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setDeletePending(false);
    }
  };

  return (
    <div className="space-y-4">
      {balances.error ? (
        <Alert tone="error">{balances.error}</Alert>
      ) : balances.data && balances.data.length > 0 ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {balances.data.map((b) => (
            <div key={b.leaveType} className="rounded-xl border bg-white p-3">
              <p className="text-xs text-slate-500">{LEAVE_TYPE_LABEL[b.leaveType]}</p>
              <p className="tabular mt-1 text-xl font-bold text-slate-900">
                {b.remainingDays} <span className="text-xs font-normal text-slate-500">/ {b.grantedDays} 日</span>
              </p>
              <p className="text-[11px] text-slate-500">使用 {b.usedDays} 日</p>
              {b.nextExpiry && <p className="mt-0.5 text-[11px] text-amber-700">{b.nextExpiry.expiresAt} に {b.nextExpiry.days} 日失効</p>}
            </div>
          ))}
        </div>
      ) : balances.loading ? (
        <Loading />
      ) : (
        <p className="text-sm text-slate-500">休暇残高はまだありません</p>
      )}

      <div>
        <p className="mb-2 text-sm font-semibold text-slate-700">付与履歴</p>
        {grants.loading && !grants.data ? (
          <Loading />
        ) : grants.error ? (
          <Alert tone="error">{grants.error}</Alert>
        ) : !grants.data || grants.data.length === 0 ? (
          <EmptyState title="付与履歴がありません" />
        ) : (
          <Table>
            <THead>
              <TR>
                <TH>種別</TH>
                <TH className="text-right">日数</TH>
                <TH>付与日</TH>
                <TH>失効日</TH>
                <TH>備考</TH>
                {canWrite && <TH className="w-12"></TH>}
              </TR>
            </THead>
            <TBody>
              {grants.data.map((g) => (
                <TR key={g.id}>
                  <TD>{LEAVE_TYPE_LABEL[g.leaveType] ?? g.leaveType}</TD>
                  <TD className="tabular text-right">{Number(g.days)}</TD>
                  <TD className="tabular">{fmtDate(g.grantedAt)}</TD>
                  <TD className="tabular">{fmtDate(g.expiresAt)}</TD>
                  <TD className="max-w-[16rem] truncate text-slate-600">{g.note ?? ""}</TD>
                  {canWrite && (
                    <TD>
                      <button type="button" onClick={() => setDeleting(g)} className="rounded-md p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600" aria-label="取消">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </TD>
                  )}
                </TR>
              ))}
            </TBody>
          </Table>
        )}
      </div>

      {canWrite && (
        <form onSubmit={grant} className="rounded-xl border bg-slate-50 p-4">
          <p className="mb-3 text-sm font-semibold text-slate-700">休暇を付与</p>
          <div className="grid gap-3 sm:grid-cols-4">
            <Field label="種別" error={errors.leaveType}>
              <Select value={leaveType} onChange={(e) => setLeaveType(e.target.value as LeaveType)}>
                {LEAVE_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {LEAVE_TYPE_LABEL[t]}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="日数" error={errors.days}>
              <Input type="number" step={0.5} min={0.5} max={40} value={days} onChange={(e) => setDays(e.target.value)} required />
            </Field>
            <Field label="付与日" error={errors.grantedAt}>
              <Input
                type="date"
                value={grantedAt}
                onChange={(e) => {
                  setGrantedAt(e.target.value);
                  if (e.target.value) setExpiresAt(addYears(e.target.value, 2));
                }}
                required
              />
            </Field>
            <Field label="失効日" error={errors.expiresAt} hint="既定: 付与日の2年後">
              <Input type="date" value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} required />
            </Field>
            <Field label="備考" error={errors.note} className="sm:col-span-4">
              <Textarea value={note} onChange={(e) => setNote(e.target.value)} maxLength={200} className="min-h-[56px]" placeholder="例: 2026年度 法定付与" />
            </Field>
          </div>
          <div className="mt-3 flex justify-end">
            <Button type="submit" size="sm" loading={pending}>
              付与する
            </Button>
          </div>
        </form>
      )}

      <ConfirmDialog
        open={!!deleting}
        onClose={() => setDeleting(null)}
        onConfirm={() => void remove()}
        title="付与を取り消す"
        message={deleting ? `${LEAVE_TYPE_LABEL[deleting.leaveType] ?? deleting.leaveType} ${Number(deleting.days)} 日（付与日 ${fmtDate(deleting.grantedAt)}）の付与を取り消します。使用済みの日数がある場合、残高がマイナスになる可能性があります。` : ""}
        confirmLabel="取り消す"
        danger
        pending={deletePending}
      />
    </div>
  );
}
