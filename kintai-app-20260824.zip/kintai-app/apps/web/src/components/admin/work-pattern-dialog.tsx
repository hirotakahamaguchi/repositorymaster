"use client";

import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import type { RoundingMode, WorkPatternDto, WorkPatternType, UpsertWorkPatternInput } from "@kintai/shared";
import { ROUNDING_MODES, UpsertWorkPatternSchema, WEEKDAY_JA, WORK_PATTERN_TYPES, WORK_PATTERN_TYPE_LABEL, minutesToHm } from "@kintai/shared";
import { api, errorMessage } from "@/lib/api";
import { todayLocal } from "@/lib/format";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Checkbox, Field, Input, Select } from "@/components/ui/input";
import { Alert } from "@/components/ui/misc";
import { useToast } from "@/components/ui/toast";
import { zodFieldErrors } from "./form-utils";

export const ROUNDING_MODE_LABEL: Record<RoundingMode, string> = {
  NONE: "丸めなし",
  FLOOR: "切り捨て",
  CEIL: "切り上げ",
  ROUND: "四捨五入",
};
const ROUNDING_UNITS = [1, 5, 10, 15, 30] as const;
const OVERTIME_BASIS_LABEL = { SCHEDULED: "所定超（所定労働時間を超えた分）", LEGAL: "法定超（1日8時間を超えた分）" } as const;

interface RoundingForm {
  unitMinutes: number;
  mode: RoundingMode;
}

interface WpForm {
  code: string;
  name: string;
  patternType: WorkPatternType;
  validFrom: string;
  validTo: string;
  start: string;
  end: string;
  coreStart: string;
  coreEnd: string;
  flexStart: string;
  flexEnd: string;
  scheduledMinutes: string;
  breaks: { from: string; to: string }[];
  enforceLegalBreak: boolean;
  roundingIn: RoundingForm;
  roundingOut: RoundingForm;
  workdays: number[];
  legalHolidayWeekday: number;
  overtimeBasis: "SCHEDULED" | "LEGAL";
  unapprovedOvertimeThresholdMinutes: string;
  dayBoundary: string;
}

function toForm(wp: WorkPatternDto | null): WpForm {
  const r = wp?.rules;
  return {
    code: wp?.code ?? "",
    name: wp?.name ?? "",
    patternType: wp?.patternType ?? "FIXED",
    validFrom: wp?.validFrom ?? todayLocal(),
    validTo: wp?.validTo ?? "",
    start: r?.start ?? "09:00",
    end: r?.end ?? "18:00",
    coreStart: r?.coreStart ?? "10:00",
    coreEnd: r?.coreEnd ?? "15:00",
    flexStart: r?.flexStart ?? "07:00",
    flexEnd: r?.flexEnd ?? "22:00",
    scheduledMinutes: String(r?.scheduledMinutes ?? 480),
    breaks: r?.breaks?.map((b) => ({ from: b.from, to: b.to })) ?? (wp ? [] : [{ from: "12:00", to: "13:00" }]),
    enforceLegalBreak: r?.enforceLegalBreak ?? true,
    roundingIn: { unitMinutes: r?.roundingIn?.unitMinutes ?? 1, mode: r?.roundingIn?.mode ?? "NONE" },
    roundingOut: { unitMinutes: r?.roundingOut?.unitMinutes ?? 1, mode: r?.roundingOut?.mode ?? "NONE" },
    workdays: r?.workdays ? [...r.workdays] : [1, 2, 3, 4, 5],
    legalHolidayWeekday: r?.legalHolidayWeekday ?? 0,
    overtimeBasis: r?.overtimeBasis ?? "LEGAL",
    unapprovedOvertimeThresholdMinutes: String(r?.unapprovedOvertimeThresholdMinutes ?? 30),
    dayBoundary: r?.dayBoundary ?? "05:00",
  };
}

function toInput(f: WpForm): unknown {
  const timed = f.patternType === "FIXED" || f.patternType === "SHIFT";
  const flex = f.patternType === "FLEX";
  const numOrNaN = (s: string) => (s.trim() === "" ? NaN : Number(s));
  return {
    code: f.code.trim(),
    name: f.name.trim(),
    patternType: f.patternType,
    validFrom: f.validFrom,
    validTo: f.validTo || null,
    rules: {
      start: timed && f.start ? f.start : undefined,
      end: timed && f.end ? f.end : undefined,
      coreStart: flex && f.coreStart ? f.coreStart : undefined,
      coreEnd: flex && f.coreEnd ? f.coreEnd : undefined,
      flexStart: flex && f.flexStart ? f.flexStart : undefined,
      flexEnd: flex && f.flexEnd ? f.flexEnd : undefined,
      scheduledMinutes: numOrNaN(f.scheduledMinutes),
      breaks: f.breaks,
      enforceLegalBreak: f.enforceLegalBreak,
      roundingIn: { unitMinutes: f.roundingIn.unitMinutes, mode: f.roundingIn.mode },
      roundingOut: { unitMinutes: f.roundingOut.unitMinutes, mode: f.roundingOut.mode },
      workdays: [...f.workdays].sort((a, b) => a - b),
      legalHolidayWeekday: f.legalHolidayWeekday,
      overtimeBasis: f.overtimeBasis,
      unapprovedOvertimeThresholdMinutes: numOrNaN(f.unapprovedOvertimeThresholdMinutes),
      dayBoundary: f.dayBoundary,
    },
  };
}

export function WorkPatternDialog({
  open,
  onClose,
  pattern,
  canWrite,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  /** null = 新規作成 */
  pattern: WorkPatternDto | null;
  canWrite: boolean;
  onSaved: () => void;
}) {
  const isCreate = !pattern;
  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={isCreate ? "勤務パターンの新規作成" : `勤務パターン: ${pattern.name}`}
      description={isCreate ? undefined : `${pattern.code} · 割当 ${pattern.assignedCount} 名`}
      size="xl"
    >
      {/* Dialog は閉じると子を unmount するため、開くたびにフォームが初期化される */}
      <WorkPatternForm key={pattern?.id ?? "new"} pattern={pattern} canWrite={canWrite} onSaved={onSaved} onClose={onClose} />
    </Dialog>
  );
}

function WorkPatternForm({ pattern, canWrite, onSaved, onClose }: { pattern: WorkPatternDto | null; canWrite: boolean; onSaved: () => void; onClose: () => void }) {
  const toast = useToast();
  const isCreate = !pattern;
  const [form, setForm] = useState<WpForm>(() => toForm(pattern));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);
  const readOnly = !canWrite;

  const set = <K extends keyof WpForm>(k: K, v: WpForm[K]) => setForm((f) => ({ ...f, [k]: v }));
  const setBreak = (i: number, k: "from" | "to", v: string) => setForm((f) => ({ ...f, breaks: f.breaks.map((b, j) => (j === i ? { ...b, [k]: v } : b)) }));
  const addBreak = () => setForm((f) => ({ ...f, breaks: [...f.breaks, { from: "12:00", to: "13:00" }] }));
  const removeBreak = (i: number) => setForm((f) => ({ ...f, breaks: f.breaks.filter((_, j) => j !== i) }));
  const toggleWorkday = (d: number) => setForm((f) => ({ ...f, workdays: f.workdays.includes(d) ? f.workdays.filter((x) => x !== d) : [...f.workdays, d] }));

  const timed = form.patternType === "FIXED" || form.patternType === "SHIFT";
  const flex = form.patternType === "FLEX";
  const scheduledNum = Number(form.scheduledMinutes);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (readOnly) return;
    const parsed = UpsertWorkPatternSchema.safeParse(toInput(form));
    if (!parsed.success) {
      const errs = zodFieldErrors(parsed.error);
      setErrors(errs);
      toast.error("入力内容を確認してください");
      return;
    }
    setErrors({});
    const body: UpsertWorkPatternInput = parsed.data;
    setPending(true);
    try {
      if (isCreate) {
        await api.post("/work-patterns", body);
        toast.success("勤務パターンを作成しました");
      } else {
        await api.put(`/work-patterns/${pattern.id}`, body);
        toast.success("勤務パターンを更新しました");
      }
      onSaved();
      onClose();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setPending(false);
    }
  };

  const breakErrors = Object.keys(errors).filter((k) => k.startsWith("rules.breaks"));

  return (
      <form onSubmit={submit} className="space-y-6">
        {/* 基本 */}
        <section className="space-y-3">
          <h3 className="text-sm font-semibold text-slate-800">基本情報</h3>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Field label="コード" error={errors.code}>
              <Input value={form.code} onChange={(e) => set("code", e.target.value)} disabled={readOnly} required maxLength={32} />
            </Field>
            <Field label="名称" error={errors.name}>
              <Input value={form.name} onChange={(e) => set("name", e.target.value)} disabled={readOnly} required maxLength={100} />
            </Field>
            <Field label="種別" error={errors.patternType}>
              <Select value={form.patternType} onChange={(e) => set("patternType", e.target.value as WorkPatternType)} disabled={readOnly}>
                {WORK_PATTERN_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {WORK_PATTERN_TYPE_LABEL[t]}
                  </option>
                ))}
              </Select>
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="有効開始" error={errors.validFrom}>
                <Input type="date" value={form.validFrom} onChange={(e) => set("validFrom", e.target.value)} disabled={readOnly} required />
              </Field>
              <Field label="有効終了" error={errors.validTo}>
                <Input type="date" value={form.validTo} onChange={(e) => set("validTo", e.target.value)} disabled={readOnly} />
              </Field>
            </div>
          </div>
        </section>

        {/* 時間 */}
        <section className="space-y-3">
          <h3 className="text-sm font-semibold text-slate-800">所定時間</h3>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {timed && (
              <>
                <Field label="始業" error={errors["rules.start"]}>
                  <Input type="time" value={form.start} onChange={(e) => set("start", e.target.value)} disabled={readOnly} />
                </Field>
                <Field label="終業" error={errors["rules.end"]}>
                  <Input type="time" value={form.end} onChange={(e) => set("end", e.target.value)} disabled={readOnly} />
                </Field>
              </>
            )}
            {flex && (
              <>
                <Field label="コアタイム開始" error={errors["rules.coreStart"]}>
                  <Input type="time" value={form.coreStart} onChange={(e) => set("coreStart", e.target.value)} disabled={readOnly} />
                </Field>
                <Field label="コアタイム終了" error={errors["rules.coreEnd"]}>
                  <Input type="time" value={form.coreEnd} onChange={(e) => set("coreEnd", e.target.value)} disabled={readOnly} />
                </Field>
                <Field label="フレキシブル開始" error={errors["rules.flexStart"]}>
                  <Input type="time" value={form.flexStart} onChange={(e) => set("flexStart", e.target.value)} disabled={readOnly} />
                </Field>
                <Field label="フレキシブル終了" error={errors["rules.flexEnd"]}>
                  <Input type="time" value={form.flexEnd} onChange={(e) => set("flexEnd", e.target.value)} disabled={readOnly} />
                </Field>
              </>
            )}
            <Field label="1日の所定労働（分）" error={errors["rules.scheduledMinutes"]} hint={Number.isFinite(scheduledNum) ? `= ${minutesToHm(scheduledNum)}` : undefined}>
              <Input type="number" min={0} max={1440} step={1} value={form.scheduledMinutes} onChange={(e) => set("scheduledMinutes", e.target.value)} disabled={readOnly} required />
            </Field>
            <Field label="日付の切り替わり時刻" error={errors["rules.dayBoundary"]} hint="夜勤対応。例 05:00">
              <Input type="time" value={form.dayBoundary} onChange={(e) => set("dayBoundary", e.target.value)} disabled={readOnly} required />
            </Field>
          </div>
        </section>

        {/* 休憩 */}
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-800">休憩</h3>
            {!readOnly && (
              <Button type="button" size="sm" variant="outline" onClick={addBreak}>
                <Plus className="h-3.5 w-3.5" /> 休憩を追加
              </Button>
            )}
          </div>
          {form.breaks.length === 0 ? (
            <p className="text-xs text-slate-500">固定休憩なし（打刻による休憩のみ）</p>
          ) : (
            <div className="space-y-2">
              {form.breaks.map((b, i) => (
                <div key={i} className="flex flex-wrap items-center gap-2">
                  <span className="w-14 text-xs text-slate-500">休憩 {i + 1}</span>
                  <Input type="time" value={b.from} onChange={(e) => setBreak(i, "from", e.target.value)} disabled={readOnly} className="w-32" />
                  <span className="text-slate-400">〜</span>
                  <Input type="time" value={b.to} onChange={(e) => setBreak(i, "to", e.target.value)} disabled={readOnly} className="w-32" />
                  {!readOnly && (
                    <button type="button" onClick={() => removeBreak(i)} className="rounded-md p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600" aria-label="削除">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
          {breakErrors.length > 0 && <p className="text-xs text-rose-600">{breakErrors.map((k) => errors[k]).join(" / ")}</p>}
          <Checkbox label="法定休憩を自動控除する（6h超→45分、8h超→60分）" checked={form.enforceLegalBreak} onChange={(e) => set("enforceLegalBreak", e.target.checked)} disabled={readOnly} />
        </section>

        {/* 丸め */}
        <section className="space-y-3">
          <h3 className="text-sm font-semibold text-slate-800">打刻の丸め</h3>
          <div className="grid gap-3 sm:grid-cols-2">
            {(["roundingIn", "roundingOut"] as const).map((k) => (
              <div key={k} className="rounded-xl border p-3">
                <p className="mb-2 text-xs font-medium text-slate-600">{k === "roundingIn" ? "出勤打刻" : "退勤打刻"}</p>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="単位" error={errors[`rules.${k}.unitMinutes`]}>
                    <Select value={form[k].unitMinutes} onChange={(e) => set(k, { ...form[k], unitMinutes: Number(e.target.value) })} disabled={readOnly}>
                      {ROUNDING_UNITS.map((u) => (
                        <option key={u} value={u}>
                          {u} 分
                        </option>
                      ))}
                    </Select>
                  </Field>
                  <Field label="方式" error={errors[`rules.${k}.mode`]}>
                    <Select value={form[k].mode} onChange={(e) => set(k, { ...form[k], mode: e.target.value as RoundingMode })} disabled={readOnly}>
                      {ROUNDING_MODES.map((m) => (
                        <option key={m} value={m}>
                          {ROUNDING_MODE_LABEL[m]}
                        </option>
                      ))}
                    </Select>
                  </Field>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 労働日 */}
        <section className="space-y-3">
          <h3 className="text-sm font-semibold text-slate-800">所定労働日・休日</h3>
          <Field label="所定労働日" error={errors["rules.workdays"]}>
            <div className="flex flex-wrap gap-1.5">
              {[0, 1, 2, 3, 4, 5, 6].map((d) => {
                const on = form.workdays.includes(d);
                return (
                  <button
                    key={d}
                    type="button"
                    disabled={readOnly}
                    onClick={() => toggleWorkday(d)}
                    className={cn(
                      "h-9 w-9 rounded-lg border text-sm font-medium transition-colors disabled:opacity-60",
                      on ? "border-brand-600 bg-brand-600 text-white" : "border-slate-300 bg-white text-slate-600 hover:bg-slate-50",
                      d === 0 && !on && "text-rose-600",
                      d === 6 && !on && "text-sky-600",
                    )}
                    aria-pressed={on}
                  >
                    {WEEKDAY_JA[d]}
                  </button>
                );
              })}
            </div>
          </Field>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="法定休日（週1日）" error={errors["rules.legalHolidayWeekday"]}>
              <Select value={form.legalHolidayWeekday} onChange={(e) => set("legalHolidayWeekday", Number(e.target.value))} disabled={readOnly}>
                {[0, 1, 2, 3, 4, 5, 6].map((d) => (
                  <option key={d} value={d}>
                    {WEEKDAY_JA[d]}曜日
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="残業計算の基準" error={errors["rules.overtimeBasis"]}>
              <Select value={form.overtimeBasis} onChange={(e) => set("overtimeBasis", e.target.value as "SCHEDULED" | "LEGAL")} disabled={readOnly}>
                {(Object.keys(OVERTIME_BASIS_LABEL) as (keyof typeof OVERTIME_BASIS_LABEL)[]).map((k) => (
                  <option key={k} value={k}>
                    {OVERTIME_BASIS_LABEL[k]}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="未承認残業のフラグ閾値（分）" error={errors["rules.unapprovedOvertimeThresholdMinutes"]} hint="この分数以下の残業はフラグを立てません">
              <Input type="number" min={0} max={480} step={1} value={form.unapprovedOvertimeThresholdMinutes} onChange={(e) => set("unapprovedOvertimeThresholdMinutes", e.target.value)} disabled={readOnly} required />
            </Field>
          </div>
        </section>

        {errors.rules && <Alert tone="error">{errors.rules}</Alert>}
        {readOnly && <Alert tone="info">閲覧のみ可能です（マスタ編集権限がありません）</Alert>}

        <div className="flex justify-end gap-2 border-t pt-4">
          <Button type="button" variant="outline" onClick={onClose}>
            閉じる
          </Button>
          {!readOnly && (
            <Button type="submit" loading={pending}>
              {isCreate ? "作成" : "保存"}
            </Button>
          )}
        </div>
      </form>
  );
}
