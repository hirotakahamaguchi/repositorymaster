"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Lock, LockOpen, TriangleAlert } from "lucide-react";
import type { AttendanceMonthSummary, MonthlyClosingDto } from "@kintai/shared";
import { api, errorMessage } from "@/lib/api";
import { useApi, useAction } from "@/lib/use-api";
import { useToast } from "@/components/ui/toast";
import { currentYearMonth, fmtDateTime, fmtYearMonth, minutesToHm } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ConfirmDialog, Dialog } from "@/components/ui/dialog";
import { Alert, EmptyState, Loading, Stat } from "@/components/ui/misc";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";

/** 月次サマリのアラートコード → 表示ラベル */
export const CLOSING_ALERT_LABEL: Record<string, string> = {
  MISSING_PUNCH: "打刻漏れ",
  UNAPPROVED_OVERTIME: "未承認残業",
  OVERTIME_WARN: "残業45h超",
  OVERTIME_LIMIT: "残業80h超",
};

const ALERT_TONE: Record<string, "red" | "amber"> = {
  MISSING_PUNCH: "red",
  UNAPPROVED_OVERTIME: "amber",
  OVERTIME_WARN: "amber",
  OVERTIME_LIMIT: "red",
};

/** 締めをブロックする（または要確認の）アラート */
const BLOCKING_ALERTS = ["MISSING_PUNCH", "UNAPPROVED_OVERTIME"];

interface CloseResult {
  closed: number;
  blocked: { employeeId: string; name: string; alerts: string[] }[];
}

interface Row {
  employeeId: string;
  employeeCode: string;
  employeeName: string;
  departmentName: string | null;
  summary: AttendanceMonthSummary;
  closing: MonthlyClosingDto | null;
}

function AlertBadges({ alerts }: { alerts: string[] }) {
  if (!alerts.length) return <span className="text-xs text-slate-400">-</span>;
  return (
    <span className="inline-flex flex-wrap gap-1">
      {alerts.map((a) => (
        <Badge key={a} tone={ALERT_TONE[a] ?? "gray"}>
          {CLOSING_ALERT_LABEL[a] ?? a}
        </Badge>
      ))}
    </span>
  );
}

export function ClosingsStatusSection({ month }: { month: string }) {
  const { success, error: toastError } = useToast();
  const closings = useApi<MonthlyClosingDto[]>("/closings", { month });
  const summaries = useApi<AttendanceMonthSummary[]>("/attendance/company/summary", { month });

  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [reopenTarget, setReopenTarget] = useState<Row | null>(null);
  const [pendingClose, setPendingClose] = useState<{ employeeIds?: string[] } | null>(null);
  const [result, setResult] = useState<{ input: { employeeIds?: string[] }; res: CloseResult } | null>(null);

  const closable = month < currentYearMonth();

  const rows = useMemo<Row[]>(() => {
    const closingMap = new Map((closings.data ?? []).map((c) => [c.employeeId, c]));
    const out: Row[] = (summaries.data ?? []).map((s) => ({
      employeeId: s.employeeId,
      employeeCode: s.employeeCode ?? "",
      employeeName: s.employeeName ?? "",
      departmentName: s.departmentName ?? null,
      summary: s,
      closing: closingMap.get(s.employeeId) ?? null,
    }));
    // サマリに含まれないが締め済みの従業員（退職者等）はスナップショットから補完
    const seen = new Set(out.map((r) => r.employeeId));
    for (const c of closings.data ?? []) {
      if (seen.has(c.employeeId)) continue;
      out.push({
        employeeId: c.employeeId,
        employeeCode: c.employeeCode,
        employeeName: c.employeeName,
        departmentName: c.snapshot?.departmentName ?? null,
        summary: c.snapshot,
        closing: c,
      });
    }
    out.sort((a, b) => a.employeeCode.localeCompare(b.employeeCode, "ja"));
    return out;
  }, [closings.data, summaries.data]);

  const lockedCount = rows.filter((r) => r.closing).length;
  const unlockedRows = rows.filter((r) => !r.closing);
  const alertCount = rows.filter((r) => r.summary.alerts.some((a) => BLOCKING_ALERTS.includes(a))).length;

  const reloadAll = async () => {
    await Promise.all([closings.reload(), summaries.reload()]);
  };

  const closeAction = useAction(async (input: { employeeIds?: string[] }, force: boolean) => {
    const res = await api.post<CloseResult>("/closings", { yearMonth: month, ...(input.employeeIds ? { employeeIds: input.employeeIds } : {}) }, force ? { force: true } : undefined);
    return res;
  });

  const runClose = async (input: { employeeIds?: string[] }, force: boolean) => {
    try {
      const res = await closeAction.run(input, force);
      if (!res) return;
      setPendingClose(null);
      setResult({ input, res });
      setSelected(new Set());
      if (res.closed > 0) success(`${res.closed} 名を締めました`);
      await reloadAll();
    } catch (e) {
      toastError(errorMessage(e));
    }
  };

  const reopenAction = useAction(async (employeeId: string) => {
    await api.post(`/closings/${month}/reopen/${employeeId}`);
  });

  const runReopen = async () => {
    if (!reopenTarget) return;
    try {
      await reopenAction.run(reopenTarget.employeeId);
      success(`${reopenTarget.employeeName} さんの締めを解除しました`);
      setReopenTarget(null);
      await reloadAll();
    } catch (e) {
      toastError(errorMessage(e));
    }
  };

  const toggleAll = (checked: boolean) => {
    setSelected(checked ? new Set(unlockedRows.map((r) => r.employeeId)) : new Set());
  };
  const toggle = (id: string, checked: boolean) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (checked) next.add(id);
      else next.delete(id);
      return next;
    });
  };

  const loading = (closings.loading && !closings.data) || (summaries.loading && !summaries.data);
  const err = closings.error ?? summaries.error;

  const allSelected = unlockedRows.length > 0 && unlockedRows.every((r) => selected.has(r.employeeId));

  return (
    <Card>
      <CardHeader className="flex-col items-start sm:flex-row sm:items-center">
        <div>
          <CardTitle className="flex items-center gap-2">
            <Lock className="h-4 w-4 text-violet-500" /> 締め状況
          </CardTitle>
          <CardDescription>{fmtYearMonth(month)} の月次締め。締めると当月の勤怠が確定（編集不可）になります。</CardDescription>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" size="sm" disabled={!closable || selected.size === 0 || closeAction.pending} onClick={() => setPendingClose({ employeeIds: [...selected] })}>
            選択を締め{selected.size > 0 && ` (${selected.size})`}
          </Button>
          <Button size="sm" disabled={!closable || unlockedRows.length === 0 || closeAction.pending} onClick={() => setPendingClose({})}>
            <Lock className="h-3.5 w-3.5" /> 未締めを一括締め
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {!closable && (
          <Alert tone="info">
            当月以降は締められません。月が終了してから実行してください（現在 {fmtYearMonth(currentYearMonth())}）。
          </Alert>
        )}

        {loading ? (
          <Loading />
        ) : err && rows.length === 0 ? (
          <Alert tone="error">{err}</Alert>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Stat label="対象人数" value={`${rows.length}`} sub="名" />
              <Stat label="締め済人数" value={`${lockedCount}`} sub="名" tone={rows.length > 0 && lockedCount === rows.length ? "good" : "default"} />
              <Stat label="未締め人数" value={`${rows.length - lockedCount}`} sub="名" tone={rows.length - lockedCount > 0 ? "warn" : "good"} />
              <Stat label="アラート人数" value={`${alertCount}`} sub="打刻漏れ・未承認残業" tone={alertCount > 0 ? "danger" : "good"} />
            </div>

            {rows.length === 0 ? (
              <EmptyState title="対象の従業員がいません" description="この月に在籍する従業員がいないか、勤怠データがありません。" />
            ) : (
              <Table>
                <THead>
                  <TR>
                    <TH className="w-8">
                      <input
                        type="checkbox"
                        aria-label="未締めをすべて選択"
                        className="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500"
                        checked={allSelected}
                        disabled={!closable || unlockedRows.length === 0}
                        onChange={(e) => toggleAll(e.target.checked)}
                      />
                    </TH>
                    <TH>社員番号</TH>
                    <TH>氏名</TH>
                    <TH>部署</TH>
                    <TH className="text-right">出勤日数</TH>
                    <TH className="text-right">総労働</TH>
                    <TH className="text-right">法定外</TH>
                    <TH>アラート</TH>
                    <TH>締め状態</TH>
                    <TH className="text-right">操作</TH>
                  </TR>
                </THead>
                <TBody>
                  {rows.map((r) => {
                    const s = r.summary;
                    return (
                      <TR key={r.employeeId}>
                        <TD>
                          {!r.closing && (
                            <input
                              type="checkbox"
                              aria-label={`${r.employeeName} を選択`}
                              className="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500"
                              checked={selected.has(r.employeeId)}
                              disabled={!closable}
                              onChange={(e) => toggle(r.employeeId, e.target.checked)}
                            />
                          )}
                        </TD>
                        <TD className="tabular text-xs text-slate-500">{r.employeeCode}</TD>
                        <TD className="font-medium text-slate-900">
                          <Link href={`/admin/attendance/${r.employeeId}?month=${month}`} className="hover:underline">
                            {r.employeeName}
                          </Link>
                        </TD>
                        <TD className="text-slate-600">{r.departmentName ?? "-"}</TD>
                        <TD className="tabular text-right">
                          {s.actualWorkDays} <span className="text-xs text-slate-400">/ {s.scheduledDays}</span>
                        </TD>
                        <TD className="tabular text-right">{minutesToHm(s.workMinutes)}</TD>
                        <TD className={`tabular text-right ${s.legalOvertimeMinutes > 0 ? "text-amber-700" : ""}`}>{minutesToHm(s.legalOvertimeMinutes)}</TD>
                        <TD>
                          <AlertBadges alerts={s.alerts} />
                        </TD>
                        <TD>
                          {r.closing ? (
                            <div className="flex flex-col gap-0.5">
                              <Badge tone="violet" className="w-fit">
                                <Lock className="mr-1 h-3 w-3" /> 締め済
                              </Badge>
                              <span className="text-[11px] text-slate-500">
                                {fmtDateTime(r.closing.lockedAt)} · {r.closing.lockedByName}
                              </span>
                            </div>
                          ) : (
                            <Badge tone="gray">未締め</Badge>
                          )}
                        </TD>
                        <TD className="text-right">
                          {r.closing && (
                            <Button variant="ghost" size="sm" onClick={() => setReopenTarget(r)}>
                              <LockOpen className="h-3.5 w-3.5" /> 締め解除
                            </Button>
                          )}
                        </TD>
                      </TR>
                    );
                  })}
                </TBody>
              </Table>
            )}
          </>
        )}
      </CardContent>

      {/* 締め実行の確認 */}
      <ConfirmDialog
        open={!!pendingClose}
        onClose={() => setPendingClose(null)}
        onConfirm={() => pendingClose && void runClose(pendingClose, false)}
        title={pendingClose?.employeeIds ? "選択した従業員を締めます" : "未締めの従業員を一括で締めます"}
        confirmLabel="締めを実行"
        pending={closeAction.pending}
        message={
          <div className="space-y-2">
            <p>
              {fmtYearMonth(month)} の勤怠を
              {pendingClose?.employeeIds ? ` ${pendingClose.employeeIds.length} 名分` : ` 未締めの ${unlockedRows.length} 名分`}
              締めます。締め後は勤怠の編集ができなくなります。
            </p>
            <p className="text-xs text-slate-500">打刻漏れがある従業員は自動的にスキップされ、結果に表示されます。</p>
          </div>
        }
      />

      {/* 締め結果 */}
      <Dialog
        open={!!result}
        onClose={() => setResult(null)}
        title="締め処理の結果"
        description={`${fmtYearMonth(month)} · ${result?.res.closed ?? 0} 名を締めました`}
        size="lg"
        footer={
          <>
            <Button variant="outline" onClick={() => setResult(null)}>
              閉じる
            </Button>
            {result && result.res.blocked.length > 0 && (
              <Button variant="danger" loading={closeAction.pending} onClick={() => void runClose({ employeeIds: result.res.blocked.map((b) => b.employeeId) }, true)}>
                <TriangleAlert className="h-4 w-4" /> 警告を無視して強制締め
              </Button>
            )}
          </>
        }
      >
        {result && result.res.blocked.length === 0 ? (
          <Alert tone="success">すべての対象を締めました。</Alert>
        ) : (
          result && (
            <div className="space-y-3">
              <Alert tone="warning" title={`${result.res.blocked.length} 名は打刻漏れ等のため締められませんでした`}>
                勤怠を修正してから再度締めるか、「警告を無視して強制締め」で現在の値のまま締めることができます。
              </Alert>
              <Table>
                <THead>
                  <TR>
                    <TH>氏名</TH>
                    <TH>アラート</TH>
                    <TH className="text-right"></TH>
                  </TR>
                </THead>
                <TBody>
                  {result.res.blocked.map((b) => (
                    <TR key={b.employeeId}>
                      <TD className="font-medium text-slate-900">{b.name}</TD>
                      <TD>
                        <AlertBadges alerts={b.alerts} />
                      </TD>
                      <TD className="text-right">
                        <Link href={`/admin/attendance/${b.employeeId}?month=${month}`} className="text-xs text-brand-600 hover:underline">
                          勤怠を確認 →
                        </Link>
                      </TD>
                    </TR>
                  ))}
                </TBody>
              </Table>
            </div>
          )
        )}
      </Dialog>

      {/* 締め解除の確認 */}
      <ConfirmDialog
        open={!!reopenTarget}
        onClose={() => setReopenTarget(null)}
        onConfirm={() => void runReopen()}
        title="締めを解除しますか？"
        confirmLabel="締め解除"
        danger
        pending={reopenAction.pending}
        message={
          <p>
            {reopenTarget?.employeeName} さんの {fmtYearMonth(month)} の締めを解除します。解除後は勤怠の修正が可能になります。給与計算に反映済みの場合は再出力が必要です。
          </p>
        }
      />
    </Card>
  );
}
