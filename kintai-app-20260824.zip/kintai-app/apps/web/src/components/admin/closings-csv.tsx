"use client";

import { useState } from "react";
import { Download, FileSpreadsheet, History } from "lucide-react";
import type { DepartmentDto } from "@kintai/shared";
import { api, errorMessage } from "@/lib/api";
import { useApi, useAction } from "@/lib/use-api";
import { useToast } from "@/components/ui/toast";
import { fmtDateTimeFull, fmtYearMonth } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox, Field, Select } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert } from "@/components/ui/misc";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";

type Encoding = "utf8" | "sjis";

interface ExportHistoryRow {
  id: string;
  yearMonth: string;
  format: string;
  fileName: string;
  rowCount: number;
  createdByName: string | null;
  createdAt: string;
}

/** 給与 CSV の列説明（API の PAYROLL_CSV_COLUMNS と同じ並び） */
const CSV_COLUMNS: { header: string; desc: string }[] = [
  { header: "対象年月", desc: "YYYY-MM" },
  { header: "社員番号", desc: "従業員コード" },
  { header: "氏名", desc: "" },
  { header: "部署", desc: "所属部署名" },
  { header: "所定日数", desc: "勤務パターン上の所定出勤日数" },
  { header: "出勤日数", desc: "実際に出勤した日数" },
  { header: "欠勤日数", desc: "" },
  { header: "有給取得日数", desc: "半休は 0.5 日" },
  { header: "総労働時間", desc: "HH:mm 表記" },
  { header: "総労働時間(分)", desc: "休憩を除く実労働（分）" },
  { header: "所定外労働(分)", desc: "所定時間を超えた労働（分）" },
  { header: "法定外労働(分)", desc: "1日8h/週40hを超えた労働（分）" },
  { header: "深夜労働(分)", desc: "22:00〜5:00 の労働（分）" },
  { header: "法定休日労働(分)", desc: "法定休日の労働（分）" },
  { header: "遅刻回数", desc: "" },
  { header: "早退回数", desc: "" },
  { header: "締め状態", desc: "LOCKED=締め済 / CONFIRMED / DRAFT" },
];

function FormatBadge({ format }: { format: string }) {
  return <Badge tone={format === "sjis" ? "amber" : "blue"}>{format === "sjis" ? "Shift_JIS" : "UTF-8"}</Badge>;
}

export function ClosingsCsvSection({ month }: { month: string }) {
  const { success, error: toastError } = useToast();
  const departments = useApi<DepartmentDto[]>("/departments");
  const history = useApi<ExportHistoryRow[]>("/closings/exports");

  const [encoding, setEncoding] = useState<Encoding>("utf8");
  const [departmentId, setDepartmentId] = useState<string>("");
  const [lockedOnly, setLockedOnly] = useState(false);
  const [showColumns, setShowColumns] = useState(false);

  const download = useAction(async () => {
    const { blob, fileName } = await api.blob("/closings/csv", {
      month,
      encoding,
      departmentId: departmentId || undefined,
      lockedOnly: lockedOnly ? true : undefined,
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return fileName;
  });

  const onDownload = async () => {
    try {
      const fileName = await download.run();
      if (fileName) success(`${fileName} をダウンロードしました`);
      await history.reload();
    } catch (e) {
      toastError(errorMessage(e));
    }
  };

  return (
    <Card>
      <CardHeader className="flex-col items-start sm:flex-row sm:items-center">
        <div>
          <CardTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-4 w-4 text-emerald-600" /> 給与システム向け CSV
          </CardTitle>
          <CardDescription>{fmtYearMonth(month)} の月次集計を CSV で出力します。締め済みの従業員は締め時点のスナップショット、未締めは現在値（プレビュー）です。</CardDescription>
        </div>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="文字コード" hint="Excel で開く場合は UTF-8 (BOM付き) を推奨">
            <Select value={encoding} onChange={(e) => setEncoding(e.target.value as Encoding)}>
              <option value="utf8">UTF-8 (BOM付き)</option>
              <option value="sjis">Shift_JIS</option>
            </Select>
          </Field>
          <Field label="部署" hint="未指定の場合は全従業員">
            <Select value={departmentId} onChange={(e) => setDepartmentId(e.target.value)} disabled={departments.loading && !departments.data}>
              <option value="">すべての部署</option>
              {(departments.data ?? []).map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </Select>
          </Field>
          <div className="flex flex-col justify-end gap-2">
            <Checkbox label="締め済みのみ出力" checked={lockedOnly} onChange={(e) => setLockedOnly(e.target.checked)} />
            <Button onClick={() => void onDownload()} loading={download.pending}>
              {!download.pending && <Download className="h-4 w-4" />}
              CSV ダウンロード
            </Button>
          </div>
        </div>
        {!lockedOnly && (
          <Alert tone="info">未締めの従業員も現在値で出力されます（ファイル名に _preview が付きます）。給与確定用には「締め済みのみ出力」を推奨します。</Alert>
        )}

        <div>
          <button type="button" onClick={() => setShowColumns((v) => !v)} className="text-xs font-medium text-brand-600 hover:underline">
            {showColumns ? "出力される列を隠す ▲" : "出力される列を表示 ▼"}
          </button>
          {showColumns && (
            <div className="mt-2">
              <Table>
                <THead>
                  <TR>
                    <TH className="w-10">#</TH>
                    <TH>列名</TH>
                    <TH>内容</TH>
                  </TR>
                </THead>
                <TBody>
                  {CSV_COLUMNS.map((c, i) => (
                    <TR key={c.header}>
                      <TD className="tabular text-xs text-slate-400">{i + 1}</TD>
                      <TD className="font-medium text-slate-900">{c.header}</TD>
                      <TD className="text-xs text-slate-600">{c.desc || "-"}</TD>
                    </TR>
                  ))}
                </TBody>
              </Table>
            </div>
          )}
        </div>

        <div>
          <h4 className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-700">
            <History className="h-4 w-4" /> 出力履歴
          </h4>
          {history.error && !history.data ? (
            <Alert tone="error">{history.error}</Alert>
          ) : (history.data ?? []).length === 0 ? (
            <p className="rounded-xl border border-dashed px-4 py-6 text-center text-xs text-slate-500">{history.loading ? "読み込み中..." : "まだ出力履歴がありません"}</p>
          ) : (
            <Table>
              <THead>
                <TR>
                  <TH>出力日時</TH>
                  <TH>対象年月</TH>
                  <TH>形式</TH>
                  <TH>ファイル名</TH>
                  <TH className="text-right">行数</TH>
                  <TH>出力者</TH>
                </TR>
              </THead>
              <TBody>
                {(history.data ?? []).map((h) => (
                  <TR key={h.id}>
                    <TD className="tabular text-xs text-slate-600">{fmtDateTimeFull(h.createdAt)}</TD>
                    <TD className="tabular">{fmtYearMonth(h.yearMonth)}</TD>
                    <TD>
                      <FormatBadge format={h.format} />
                    </TD>
                    <TD className="font-mono text-xs text-slate-700">{h.fileName}</TD>
                    <TD className="tabular text-right">{h.rowCount}</TD>
                    <TD className="text-slate-600">{h.createdByName ?? "-"}</TD>
                  </TR>
                ))}
              </TBody>
            </Table>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
