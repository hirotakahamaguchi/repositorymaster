import type { ZodError } from "zod";

/** zod の issues を path → message のマップへ変換（フォーム表示用） */
export function zodFieldErrors(err: ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of err.issues) {
    const key = issue.path.map(String).join(".") || "_";
    if (!out[key]) out[key] = issue.message;
  }
  return out;
}

/** 最初のエラーを文章化 */
export function zodSummary(err: ZodError): string {
  return err.issues.map((i) => `${i.path.map(String).join(".")}: ${i.message}`).join(" / ");
}

/** "YYYY-MM-DD" に年を加算 */
export function addYears(isoDate: string, years: number): string {
  const [y, m, d] = isoDate.split("-").map(Number);
  const dt = new Date(Date.UTC(y + years, m - 1, d));
  return dt.toISOString().slice(0, 10);
}
