"use client";

import { useState } from "react";
import { Check, Clock, Minus, X } from "lucide-react";
import type { ApprovalDecision, RequestDto } from "@kintai/shared";
import { REQUEST_TYPE_LABEL } from "@kintai/shared";
import { api, errorMessage } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { fmtDate, fmtDateTime } from "@/lib/format";
import { cn } from "@/lib/utils";
import { Badge, RequestStatusBadge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ConfirmDialog, Dialog } from "@/components/ui/dialog";
import { Field, Textarea } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";
import { PayloadDetails } from "./payload-summary";

const DECISION_LABEL: Record<ApprovalDecision, string> = {
  PENDING: "承認待ち",
  APPROVED: "承認",
  REJECTED: "却下",
  SKIPPED: "スキップ",
};

function DecisionBadge({ decision }: { decision: ApprovalDecision }) {
  const tone = decision === "APPROVED" ? "green" : decision === "REJECTED" ? "red" : decision === "PENDING" ? "amber" : "gray";
  return <Badge tone={tone}>{DECISION_LABEL[decision]}</Badge>;
}

function approverLabel(a: RequestDto["approvals"][number]) {
  if (a.approverName) return a.approverName;
  // approverId 未指定の場合: 1段目は部署管理者、それ以降は労務担当
  return a.stepNo <= 1 ? "部署管理者" : "労務担当";
}

interface RequestDetailDialogProps {
  request: RequestDto | null;
  open: boolean;
  onClose: () => void;
  /** 承認/却下/取下げ後に呼ばれる（一覧の再読込用） */
  onChanged?: () => void;
}

/** 開くたびにコメント等を初期化するため、open のときだけ本体をマウントする */
export function RequestDetailDialog(props: RequestDetailDialogProps) {
  if (!props.open || !props.request) return null;
  return <RequestDetailDialogBody key={props.request.id} {...props} request={props.request} />;
}

function RequestDetailDialogBody({ request, open, onClose, onChanged }: RequestDetailDialogProps & { request: RequestDto }) {
  const { user } = useAuth();
  const toast = useToast();
  const [comment, setComment] = useState("");
  const [pending, setPending] = useState<"APPROVED" | "REJECTED" | "WITHDRAW" | null>(null);
  const [confirmWithdraw, setConfirmWithdraw] = useState(false);

  const canWithdraw = request.status === "PENDING" && !!user && request.employeeId === user.id;
  const canDecide = !!request.canDecide && request.status === "PENDING";

  const decide = async (decision: "APPROVED" | "REJECTED") => {
    if (pending) return;
    setPending(decision);
    try {
      await api.post(`/requests/${request.id}/decide`, {
        decision,
        comment: comment.trim() || undefined,
      });
      toast.success(decision === "APPROVED" ? "申請を承認しました" : "申請を却下しました");
      onChanged?.();
      onClose();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setPending(null);
    }
  };

  const withdraw = async () => {
    if (pending) return;
    setPending("WITHDRAW");
    try {
      await api.post(`/requests/${request.id}/withdraw`);
      toast.success("申請を取下げました");
      setConfirmWithdraw(false);
      onChanged?.();
      onClose();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setPending(null);
    }
  };

  const target = request.targetDateFrom === request.targetDateTo ? fmtDate(request.targetDateFrom) : `${fmtDate(request.targetDateFrom)} 〜 ${fmtDate(request.targetDateTo)}`;

  const footer = (
    <>
      {canWithdraw && (
        <Button variant="outline" onClick={() => setConfirmWithdraw(true)} disabled={pending !== null} className="mr-auto text-rose-700">
          取下げ
        </Button>
      )}
      <Button variant="ghost" onClick={onClose} disabled={pending !== null}>
        閉じる
      </Button>
      {canDecide && (
        <>
          <Button variant="danger" onClick={() => void decide("REJECTED")} loading={pending === "REJECTED"} disabled={pending !== null && pending !== "REJECTED"}>
            <X className="h-4 w-4" /> 却下
          </Button>
          <Button variant="success" onClick={() => void decide("APPROVED")} loading={pending === "APPROVED"} disabled={pending !== null && pending !== "APPROVED"}>
            <Check className="h-4 w-4" /> 承認
          </Button>
        </>
      )}
    </>
  );

  return (
    <>
      <Dialog open={open} onClose={onClose} title={`${REQUEST_TYPE_LABEL[request.requestType]}の詳細`} description={`申請日時 ${fmtDateTime(request.createdAt)}`} size="lg" footer={footer}>
        <div className="space-y-5">
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="blue">{REQUEST_TYPE_LABEL[request.requestType]}</Badge>
            <RequestStatusBadge status={request.status} />
            {request.status === "PENDING" && (
              <span className="text-xs text-slate-500">
                現在ステップ {request.currentStep} / {request.approvals.length}
              </span>
            )}
          </div>

          <dl className="grid grid-cols-1 gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
            <div>
              <dt className="text-xs font-medium text-slate-500">申請者</dt>
              <dd className="mt-0.5 text-slate-900">
                {request.employeeName} <span className="text-xs text-slate-500">({request.employeeCode})</span>
                {request.departmentName && <span className="ml-2 text-xs text-slate-500">{request.departmentName}</span>}
              </dd>
            </div>
            <div>
              <dt className="text-xs font-medium text-slate-500">対象日</dt>
              <dd className="tabular mt-0.5 text-slate-900">{target}</dd>
            </div>
          </dl>

          <section>
            <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">申請内容</h4>
            <div className="rounded-xl bg-slate-50 px-4 py-3">
              <PayloadDetails request={request} />
            </div>
          </section>

          <section>
            <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">理由</h4>
            <p className="whitespace-pre-wrap rounded-xl border px-4 py-3 text-sm text-slate-800">{request.reason || "-"}</p>
          </section>

          <section>
            <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">承認状況</h4>
            {request.approvals.length === 0 ? (
              <p className="text-sm text-slate-500">承認ステップはありません</p>
            ) : (
              <ol className="space-y-0">
                {[...request.approvals]
                  .sort((a, b) => a.stepNo - b.stepNo)
                  .map((a, idx, arr) => {
                    const isCurrent = request.status === "PENDING" && a.stepNo === request.currentStep;
                    const Icon = a.decision === "APPROVED" ? Check : a.decision === "REJECTED" ? X : a.decision === "SKIPPED" ? Minus : Clock;
                    const iconCls =
                      a.decision === "APPROVED"
                        ? "bg-emerald-100 text-emerald-700"
                        : a.decision === "REJECTED"
                          ? "bg-rose-100 text-rose-700"
                          : isCurrent
                            ? "bg-amber-100 text-amber-700"
                            : "bg-slate-100 text-slate-400";
                    return (
                      <li key={a.stepNo} className="relative flex gap-3 pb-4">
                        {idx < arr.length - 1 && <span className="absolute left-[11px] top-6 h-[calc(100%-1.5rem)] w-px bg-slate-200" aria-hidden />}
                        <span className={cn("mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full", iconCls)}>
                          <Icon className="h-3.5 w-3.5" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2 text-sm">
                            <span className="text-xs text-slate-500">STEP {a.stepNo}</span>
                            <span className={cn("font-medium", isCurrent ? "text-slate-900" : "text-slate-700")}>{approverLabel(a)}</span>
                            <DecisionBadge decision={a.decision} />
                            {isCurrent && <span className="text-[11px] text-amber-700">対応待ち</span>}
                          </div>
                          {a.comment && <p className="mt-1 whitespace-pre-wrap rounded-lg bg-slate-50 px-3 py-1.5 text-xs text-slate-700">{a.comment}</p>}
                          {a.decidedAt && <p className="tabular mt-0.5 text-[11px] text-slate-400">{fmtDateTime(a.decidedAt)}</p>}
                        </div>
                      </li>
                    );
                  })}
              </ol>
            )}
          </section>

          {canDecide && (
            <section className="rounded-xl border border-brand-200 bg-brand-50/40 p-4">
              <Field label="コメント（任意・却下時は理由を記入してください）">
                <Textarea value={comment} onChange={(e) => setComment(e.target.value)} maxLength={500} placeholder="申請者へのコメント" rows={3} />
              </Field>
            </section>
          )}
        </div>
      </Dialog>

      <ConfirmDialog
        open={confirmWithdraw}
        onClose={() => setConfirmWithdraw(false)}
        onConfirm={() => void withdraw()}
        title="申請を取下げますか？"
        message="取下げた申請は元に戻せません。必要な場合は再度申請してください。"
        confirmLabel="取下げる"
        danger
        pending={pending === "WITHDRAW"}
      />
    </>
  );
}
