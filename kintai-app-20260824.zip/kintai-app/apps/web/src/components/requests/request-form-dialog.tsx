"use client";

import { useMemo, useState } from "react";
import type { CreateRequestInput, LeaveBalanceDto, LeaveType, RequestDto, RequestType } from "@kintai/shared";
import { CreateRequestSchema, LEAVE_TYPES, LEAVE_TYPE_LABEL, REQUEST_TYPES, REQUEST_TYPE_LABEL } from "@kintai/shared";
import { api, errorMessage } from "@/lib/api";
import { localToIso, todayLocal } from "@/lib/format";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast";

const REQUEST_TYPE_HINT: Record<RequestType, string> = {
  CORRECTION: "打刻漏れや誤った打刻時刻の修正を申請します。変更しない項目は空欄のままにしてください。",
  OVERTIME: "事前に残業の予定を申請します。承認されると未承認残業フラグが解消されます。",
  LEAVE: "有給休暇・特別休暇などの取得を申請します。",
  HOLIDAY_WORK: "休日に出勤する予定を申請します。",
  LATE_EARLY: "遅刻または早退の事前・事後申請を行います。",
};

type LeaveUnit = "FULL" | "AM" | "PM";
type LateEarlyKind = "LATE" | "EARLY";

interface FormState {
  requestType: RequestType;
  date: string;
  dateTo: string;
  clockIn: string;
  clockOut: string;
  breakMinutes: string;
  plannedMinutes: string;
  leaveType: LeaveType;
  unit: LeaveUnit;
  plannedStart: string;
  plannedEnd: string;
  compensatory: boolean;
  kind: LateEarlyKind;
  minutes: string;
  reason: string;
}

function initialState(type: RequestType | undefined, date: string | undefined): FormState {
  const d = date && /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : todayLocal();
  return {
    requestType: type ?? "CORRECTION",
    date: d,
    dateTo: d,
    clockIn: "",
    clockOut: "",
    breakMinutes: "",
    plannedMinutes: "60",
    leaveType: "PAID",
    unit: "FULL",
    plannedStart: "09:00",
    plannedEnd: "18:00",
    compensatory: false,
    kind: "LATE",
    minutes: "30",
    reason: "",
  };
}

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
const HHMM = /^([01]\d|2[0-3]):[0-5]\d$/;

function toIsoOrNull(date: string, hm: string): string | null | undefined {
  if (!hm) return undefined;
  if (!ISO_DATE.test(date) || !HHMM.test(hm)) return undefined;
  try {
    return localToIso(date, hm);
  } catch {
    return undefined;
  }
}

function toNumber(v: string): number | undefined {
  if (v.trim() === "") return undefined;
  const n = Number(v);
  return Number.isFinite(n) ? n : undefined;
}

/** フォーム状態 → API 入力（スキーマ検証前の生データ） */
function buildBody(s: FormState): unknown {
  const reason = s.reason.trim();
  switch (s.requestType) {
    case "CORRECTION":
      return {
        requestType: "CORRECTION",
        reason,
        payload: {
          date: s.date,
          clockInAt: toIsoOrNull(s.date, s.clockIn),
          clockOutAt: toIsoOrNull(s.date, s.clockOut),
          breakMinutes: toNumber(s.breakMinutes),
        },
      };
    case "OVERTIME":
      return {
        requestType: "OVERTIME",
        reason,
        payload: { date: s.date, plannedMinutes: toNumber(s.plannedMinutes) },
      };
    case "LEAVE":
      return {
        requestType: "LEAVE",
        reason,
        payload: {
          dateFrom: s.date,
          dateTo: s.unit === "FULL" ? s.dateTo : s.date,
          leaveType: s.leaveType,
          unit: s.unit,
        },
      };
    case "HOLIDAY_WORK":
      return {
        requestType: "HOLIDAY_WORK",
        reason,
        payload: {
          date: s.date,
          plannedStart: s.plannedStart,
          plannedEnd: s.plannedEnd,
          compensatory: s.compensatory,
        },
      };
    case "LATE_EARLY":
      return {
        requestType: "LATE_EARLY",
        reason,
        payload: { date: s.date, kind: s.kind, minutes: toNumber(s.minutes) },
      };
  }
}

function countLeaveDays(from: string, to: string, unit: LeaveUnit): number | null {
  if (!ISO_DATE.test(from)) return null;
  if (unit !== "FULL") return 0.5;
  if (!ISO_DATE.test(to)) return null;
  const a = new Date(`${from}T00:00:00Z`).getTime();
  const b = new Date(`${to}T00:00:00Z`).getTime();
  if (Number.isNaN(a) || Number.isNaN(b) || b < a) return null;
  return Math.round((b - a) / 86400_000) + 1;
}

interface RequestFormDialogProps {
  open: boolean;
  onClose: () => void;
  onCreated?: (created: RequestDto) => void;
  balances?: LeaveBalanceDto[] | null;
  initialType?: RequestType;
  initialDate?: string;
}

/** 開くたびに内部状態を初期化するため、open のときだけ本体をマウントする */
export function RequestFormDialog(props: RequestFormDialogProps) {
  if (!props.open) return null;
  return <RequestFormDialogBody {...props} />;
}

function RequestFormDialogBody({ open, onClose, onCreated, balances, initialType, initialDate }: RequestFormDialogProps) {
  const toast = useToast();
  const [form, setForm] = useState<FormState>(() => initialState(initialType, initialDate));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, setPending] = useState(false);

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => (Object.keys(e).length ? {} : e));
  };

  const err = (path: string) => errors[path] ?? errors[`payload.${path}`];

  const balance = useMemo(() => balances?.find((b) => b.leaveType === form.leaveType) ?? null, [balances, form.leaveType]);
  const leaveDays = form.requestType === "LEAVE" ? countLeaveDays(form.date, form.dateTo, form.unit) : null;
  const leaveShort = form.requestType === "LEAVE" && form.leaveType !== "UNPAID" && balance && leaveDays !== null && leaveDays > balance.remainingDays;

  const submit = async () => {
    if (pending) return;
    const body = buildBody(form);
    const parsed = CreateRequestSchema.safeParse(body);
    if (!parsed.success) {
      const next: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        const key = issue.path.map(String).join(".");
        if (!next[key]) next[key] = issue.message;
      }
      // 判別子など全体に関するエラー
      if (!Object.keys(next).length) next._ = "入力内容を確認してください";
      setErrors(next);
      return;
    }
    // 追加の業務チェック
    if (parsed.data.requestType === "LEAVE" && parsed.data.payload.dateTo < parsed.data.payload.dateFrom) {
      setErrors({ "payload.dateTo": "終了日は開始日以降にしてください" });
      return;
    }
    if (parsed.data.requestType === "HOLIDAY_WORK" && parsed.data.payload.plannedEnd <= parsed.data.payload.plannedStart) {
      setErrors({
        "payload.plannedEnd": "終了時刻は開始時刻より後にしてください",
      });
      return;
    }
    if (parsed.data.requestType === "CORRECTION") {
      const p = parsed.data.payload;
      if (p.clockInAt == null && p.clockOutAt == null && p.breakMinutes === undefined) {
        setErrors({
          "payload.clockInAt": "出勤時刻・退勤時刻・休憩のいずれかを入力してください",
        });
        return;
      }
      if (p.clockInAt && p.clockOutAt && p.clockOutAt <= p.clockInAt) {
        setErrors({
          "payload.clockOutAt": "退勤時刻は出勤時刻より後にしてください",
        });
        return;
      }
    }
    setPending(true);
    try {
      const created = await api.post<RequestDto>("/requests", parsed.data satisfies CreateRequestInput);
      toast.success(`${REQUEST_TYPE_LABEL[parsed.data.requestType]}を申請しました`);
      onCreated?.(created);
      onClose();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setPending(false);
    }
  };

  const footer = (
    <>
      <Button variant="ghost" onClick={onClose} disabled={pending}>
        キャンセル
      </Button>
      <Button onClick={() => void submit()} loading={pending}>
        申請する
      </Button>
    </>
  );

  return (
    <Dialog open={open} onClose={onClose} title="新規申請" description={REQUEST_TYPE_HINT[form.requestType]} size="md" footer={footer}>
      <div className="space-y-4">
        <Field label="申請種別" error={err("requestType")}>
          <Select value={form.requestType} onChange={(e) => set("requestType", e.target.value as RequestType)}>
            {REQUEST_TYPES.map((t) => (
              <option key={t} value={t}>
                {REQUEST_TYPE_LABEL[t]}
              </option>
            ))}
          </Select>
        </Field>

        {form.requestType === "CORRECTION" && (
          <>
            <Field label="対象日" error={err("date")}>
              <Input type="date" value={form.date} onChange={(e) => set("date", e.target.value)} required />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="出勤時刻（任意）" error={err("clockInAt")}>
                <Input type="time" value={form.clockIn} onChange={(e) => set("clockIn", e.target.value)} />
              </Field>
              <Field label="退勤時刻（任意）" error={err("clockOutAt")}>
                <Input type="time" value={form.clockOut} onChange={(e) => set("clockOut", e.target.value)} />
              </Field>
            </div>
            <Field label="休憩（分・任意）" error={err("breakMinutes")} hint="空欄の場合は休憩時間を変更しません">
              <Input type="number" inputMode="numeric" min={0} max={1440} step={1} value={form.breakMinutes} onChange={(e) => set("breakMinutes", e.target.value)} placeholder="例: 60" />
            </Field>
          </>
        )}

        {form.requestType === "OVERTIME" && (
          <>
            <Field label="対象日" error={err("date")}>
              <Input type="date" value={form.date} onChange={(e) => set("date", e.target.value)} required />
            </Field>
            <Field label="予定残業（分）" error={err("plannedMinutes")}>
              <Input type="number" inputMode="numeric" min={1} max={720} step={1} value={form.plannedMinutes} onChange={(e) => set("plannedMinutes", e.target.value)} />
              <div className="mt-2 flex flex-wrap gap-1.5">
                {[30, 60, 90, 120].map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => set("plannedMinutes", String(m))}
                    className={cn(
                      "rounded-full border px-3 py-1 text-xs transition-colors",
                      form.plannedMinutes === String(m) ? "border-brand-500 bg-brand-50 text-brand-700" : "border-slate-300 text-slate-600 hover:bg-slate-50",
                    )}
                  >
                    {m}分
                  </button>
                ))}
              </div>
            </Field>
          </>
        )}

        {form.requestType === "LEAVE" && (
          <>
            <div className="grid grid-cols-2 gap-3">
              <Field label="開始日" error={err("dateFrom")}>
                <Input
                  type="date"
                  value={form.date}
                  onChange={(e) => {
                    const v = e.target.value;
                    setForm((f) => ({
                      ...f,
                      date: v,
                      dateTo: f.unit !== "FULL" || !f.dateTo || f.dateTo < v ? v : f.dateTo,
                    }));
                    setErrors({});
                  }}
                  required
                />
              </Field>
              <Field label="終了日" error={err("dateTo")}>
                <Input
                  type="date"
                  value={form.unit === "FULL" ? form.dateTo : form.date}
                  min={form.date || undefined}
                  onChange={(e) => set("dateTo", e.target.value)}
                  disabled={form.unit !== "FULL"}
                  required
                />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="休暇種別" error={err("leaveType")}>
                <Select value={form.leaveType} onChange={(e) => set("leaveType", e.target.value as LeaveType)}>
                  {LEAVE_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {LEAVE_TYPE_LABEL[t]}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="単位" error={err("unit")}>
                <Select
                  value={form.unit}
                  onChange={(e) => {
                    const u = e.target.value as LeaveUnit;
                    setForm((f) => ({
                      ...f,
                      unit: u,
                      dateTo: u === "FULL" ? f.dateTo || f.date : f.date,
                    }));
                  }}
                >
                  <option value="FULL">終日</option>
                  <option value="AM">午前半休</option>
                  <option value="PM">午後半休</option>
                </Select>
              </Field>
            </div>
            <div className={cn("rounded-xl px-3 py-2 text-xs", leaveShort ? "bg-rose-50 text-rose-700" : "bg-slate-50 text-slate-600")}>
              {form.leaveType === "UNPAID" ? (
                <>無給休暇は残日数の制限はありません。</>
              ) : balance ? (
                <>
                  {LEAVE_TYPE_LABEL[form.leaveType]}の残日数: <b className="tabular">{balance.remainingDays}</b> 日
                  {leaveDays !== null && (
                    <>
                      {" "}
                      / 今回の取得: <b className="tabular">{leaveDays}</b> 日{leaveShort && <span className="ml-1 font-medium">（残日数が不足しています）</span>}
                    </>
                  )}
                  {balance.nextExpiry && (
                    <span className="ml-2 text-slate-500">
                      {balance.nextExpiry.expiresAt} に {balance.nextExpiry.days} 日失効
                    </span>
                  )}
                </>
              ) : (
                <>{LEAVE_TYPE_LABEL[form.leaveType]}の付与がありません。</>
              )}
            </div>
          </>
        )}

        {form.requestType === "HOLIDAY_WORK" && (
          <>
            <Field label="対象日" error={err("date")}>
              <Input type="date" value={form.date} onChange={(e) => set("date", e.target.value)} required />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="予定開始" error={err("plannedStart")}>
                <Input type="time" value={form.plannedStart} onChange={(e) => set("plannedStart", e.target.value)} required />
              </Field>
              <Field label="予定終了" error={err("plannedEnd")}>
                <Input type="time" value={form.plannedEnd} onChange={(e) => set("plannedEnd", e.target.value)} required />
              </Field>
            </div>
            <Checkbox label="代休を取得する" checked={form.compensatory} onChange={(e) => set("compensatory", e.target.checked)} />
            {err("compensatory") && <p className="text-xs text-rose-600">{err("compensatory")}</p>}
          </>
        )}

        {form.requestType === "LATE_EARLY" && (
          <>
            <Field label="対象日" error={err("date")}>
              <Input type="date" value={form.date} onChange={(e) => set("date", e.target.value)} required />
            </Field>
            <Field label="区分" error={err("kind")}>
              <div className="flex gap-4 py-1">
                {(["LATE", "EARLY"] as const).map((k) => (
                  <label key={k} className="inline-flex items-center gap-2 text-sm text-slate-700">
                    <input type="radio" name="late-early-kind" className="h-4 w-4 border-slate-300 text-brand-600 focus:ring-brand-500" checked={form.kind === k} onChange={() => set("kind", k)} />
                    {k === "LATE" ? "遅刻" : "早退"}
                  </label>
                ))}
              </div>
            </Field>
            <Field label={`${form.kind === "LATE" ? "遅刻" : "早退"}時間（分）`} error={err("minutes")}>
              <Input type="number" inputMode="numeric" min={1} max={720} step={1} value={form.minutes} onChange={(e) => set("minutes", e.target.value)} />
            </Field>
          </>
        )}

        <Field label="理由（必須）" error={err("reason")}>
          <Textarea value={form.reason} onChange={(e) => set("reason", e.target.value)} maxLength={500} rows={3} placeholder="申請の理由を入力してください" required />
        </Field>

        {errors._ && <p className="text-xs text-rose-600">{errors._}</p>}
      </div>
    </Dialog>
  );
}
