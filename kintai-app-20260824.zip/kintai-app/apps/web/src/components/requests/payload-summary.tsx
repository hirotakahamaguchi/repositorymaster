"use client";

import type { z } from "zod";
import type { CorrectionPayloadSchema, HolidayWorkPayloadSchema, LateEarlyPayloadSchema, LeavePayloadSchema, OvertimePayloadSchema, RequestDto, RequestType } from "@kintai/shared";
import { LEAVE_TYPE_LABEL } from "@kintai/shared";
import { fmtDate, fmtTime, minutesToHm } from "@/lib/format";

export type CorrectionPayload = z.infer<typeof CorrectionPayloadSchema>;
export type OvertimePayload = z.infer<typeof OvertimePayloadSchema>;
export type LeavePayload = z.infer<typeof LeavePayloadSchema>;
export type HolidayWorkPayload = z.infer<typeof HolidayWorkPayloadSchema>;
export type LateEarlyPayload = z.infer<typeof LateEarlyPayloadSchema>;

export const LEAVE_UNIT_LABEL: Record<string, string> = {
  FULL: "終日",
  AM: "午前半休",
  PM: "午後半休",
};
export const LATE_EARLY_KIND_LABEL: Record<string, string> = {
  LATE: "遅刻",
  EARLY: "早退",
};

type Item = { label: string; value: string };

/** payload を「項目名: 値」の配列に変換（詳細表示用） */
export function payloadItems(requestType: RequestType, payload: Record<string, unknown>): Item[] {
  switch (requestType) {
    case "CORRECTION": {
      const p = payload as Partial<CorrectionPayload>;
      const items: Item[] = [{ label: "対象日", value: fmtDate(p.date) }];
      items.push({
        label: "出勤時刻",
        value: p.clockInAt ? fmtTime(p.clockInAt) : "（変更なし）",
      });
      items.push({
        label: "退勤時刻",
        value: p.clockOutAt ? fmtTime(p.clockOutAt) : "（変更なし）",
      });
      if (p.breakMinutes !== undefined && p.breakMinutes !== null) items.push({ label: "休憩", value: minutesToHm(p.breakMinutes) });
      return items;
    }
    case "OVERTIME": {
      const p = payload as Partial<OvertimePayload>;
      return [
        { label: "対象日", value: fmtDate(p.date) },
        { label: "予定残業", value: minutesToHm(p.plannedMinutes ?? 0) },
      ];
    }
    case "LEAVE": {
      const p = payload as Partial<LeavePayload>;
      return [
        {
          label: "期間",
          value: p.dateFrom === p.dateTo ? fmtDate(p.dateFrom) : `${fmtDate(p.dateFrom)} 〜 ${fmtDate(p.dateTo)}`,
        },
        {
          label: "休暇種別",
          value: p.leaveType ? LEAVE_TYPE_LABEL[p.leaveType] : "-",
        },
        {
          label: "単位",
          value: LEAVE_UNIT_LABEL[p.unit ?? "FULL"] ?? String(p.unit),
        },
      ];
    }
    case "HOLIDAY_WORK": {
      const p = payload as Partial<HolidayWorkPayload>;
      return [
        { label: "対象日", value: fmtDate(p.date) },
        {
          label: "予定時間",
          value: `${p.plannedStart ?? "-"} 〜 ${p.plannedEnd ?? "-"}`,
        },
        { label: "代休", value: p.compensatory ? "取得する" : "取得しない" },
      ];
    }
    case "LATE_EARLY": {
      const p = payload as Partial<LateEarlyPayload>;
      return [
        { label: "対象日", value: fmtDate(p.date) },
        { label: "区分", value: LATE_EARLY_KIND_LABEL[p.kind ?? ""] ?? "-" },
        { label: "時間", value: minutesToHm(p.minutes ?? 0) },
      ];
    }
    default:
      return [];
  }
}

/** 一覧用の 1 行サマリ文字列 */
export function payloadSummaryText(requestType: RequestType, payload: Record<string, unknown>): string {
  switch (requestType) {
    case "CORRECTION": {
      const p = payload as Partial<CorrectionPayload>;
      const parts: string[] = [];
      parts.push(`出勤 ${p.clockInAt ? fmtTime(p.clockInAt) : "-"}`);
      parts.push(`退勤 ${p.clockOutAt ? fmtTime(p.clockOutAt) : "-"}`);
      if (p.breakMinutes !== undefined && p.breakMinutes !== null) parts.push(`休憩 ${p.breakMinutes}分`);
      return parts.join(" / ");
    }
    case "OVERTIME": {
      const p = payload as Partial<OvertimePayload>;
      return `予定 ${minutesToHm(p.plannedMinutes ?? 0)}`;
    }
    case "LEAVE": {
      const p = payload as Partial<LeavePayload>;
      return `${p.leaveType ? LEAVE_TYPE_LABEL[p.leaveType] : "-"}（${LEAVE_UNIT_LABEL[p.unit ?? "FULL"] ?? p.unit}）`;
    }
    case "HOLIDAY_WORK": {
      const p = payload as Partial<HolidayWorkPayload>;
      return `${p.plannedStart ?? "-"}–${p.plannedEnd ?? "-"}${p.compensatory ? " / 代休あり" : " / 代休なし"}`;
    }
    case "LATE_EARLY": {
      const p = payload as Partial<LateEarlyPayload>;
      return `${LATE_EARLY_KIND_LABEL[p.kind ?? ""] ?? "-"} ${p.minutes ?? 0}分`;
    }
    default:
      return "";
  }
}

/** 一覧セル用: 申請内容の簡潔な表示 */
export function PayloadSummary({ request, className }: { request: Pick<RequestDto, "requestType" | "payload">; className?: string }) {
  return <span className={className ?? "text-slate-700"}>{payloadSummaryText(request.requestType, request.payload)}</span>;
}

/** 詳細ダイアログ用: 項目ごとの表示 */
export function PayloadDetails({ request }: { request: Pick<RequestDto, "requestType" | "payload"> }) {
  const items = payloadItems(request.requestType, request.payload);
  if (!items.length) return <p className="text-sm text-slate-500">-</p>;
  return (
    <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 text-sm">
      {items.map((it) => (
        <div key={it.label} className="contents">
          <dt className="text-slate-500">{it.label}</dt>
          <dd className="tabular text-slate-900">{it.value}</dd>
        </div>
      ))}
    </dl>
  );
}
