import { AlertCircle, CheckCircle2, Info, Loader2, TriangleAlert } from "lucide-react";
import { cn } from "@/lib/utils";

export function Spinner({ className }: { className?: string }) {
  return <Loader2 className={cn("h-5 w-5 animate-spin text-slate-400", className)} />;
}

export function Loading({ label = "読み込み中..." }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2 py-16 text-sm text-slate-500">
      <Spinner /> {label}
    </div>
  );
}

export function PageHeader({ title, description, actions }: { title: string; description?: string; actions?: React.ReactNode }) {
  return (
    <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-xl font-bold text-slate-900 sm:text-2xl">{title}</h1>
        {description && <p className="mt-1 text-sm text-slate-500">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function EmptyState({ title, description, action }: { title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed py-14 text-center">
      <p className="text-sm font-medium text-slate-700">{title}</p>
      {description && <p className="mt-1 text-xs text-slate-500">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Alert({ tone = "info", title, children, className }: { tone?: "info" | "success" | "warning" | "error"; title?: string; children?: React.ReactNode; className?: string }) {
  const styles = {
    info: "bg-blue-50 text-blue-900 border-blue-200",
    success: "bg-emerald-50 text-emerald-900 border-emerald-200",
    warning: "bg-amber-50 text-amber-900 border-amber-200",
    error: "bg-rose-50 text-rose-900 border-rose-200",
  }[tone];
  const Icon = { info: Info, success: CheckCircle2, warning: TriangleAlert, error: AlertCircle }[tone];
  return (
    <div className={cn("flex gap-3 rounded-xl border px-4 py-3 text-sm", styles, className)}>
      <Icon className="mt-0.5 h-4 w-4 shrink-0" />
      <div>
        {title && <p className="font-medium">{title}</p>}
        {children && <div className={title ? "mt-0.5" : ""}>{children}</div>}
      </div>
    </div>
  );
}

export function Stat({ label, value, sub, tone = "default", className }: { label: string; value: React.ReactNode; sub?: React.ReactNode; tone?: "default" | "warn" | "danger" | "good"; className?: string }) {
  const v = { default: "text-slate-900", warn: "text-amber-600", danger: "text-rose-600", good: "text-emerald-600" }[tone];
  return (
    <div className={cn("rounded-2xl border bg-white p-4 shadow-sm", className)}>
      <p className="text-xs font-medium text-slate-500">{label}</p>
      <p className={cn("tabular mt-1 text-2xl font-bold", v)}>{value}</p>
      {sub && <p className="mt-0.5 text-xs text-slate-500">{sub}</p>}
    </div>
  );
}

export function MonthNav({ value, onChange, label }: { value: string; onChange: (ym: string) => void; label?: string }) {
  const [y, m] = value.split("-").map(Number);
  const shift = (d: number) => {
    const dt = new Date(Date.UTC(y, m - 1 + d, 1));
    onChange(`${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, "0")}`);
  };
  return (
    <div className="inline-flex items-center rounded-lg border bg-white shadow-sm">
      <button onClick={() => shift(-1)} className="h-9 px-3 text-slate-600 hover:bg-slate-50" aria-label="前月">
        ‹
      </button>
      <span className="tabular min-w-[7.5rem] text-center text-sm font-semibold">{label ?? `${y}年${m}月`}</span>
      <button onClick={() => shift(1)} className="h-9 px-3 text-slate-600 hover:bg-slate-50" aria-label="翌月">
        ›
      </button>
    </div>
  );
}

export function Tabs<T extends string>({ tabs, value, onChange }: { tabs: { value: T; label: string; count?: number }[]; value: T; onChange: (v: T) => void }) {
  return (
    <div className="flex gap-1 overflow-x-auto rounded-lg bg-slate-100 p-1">
      {tabs.map((t) => (
        <button
          key={t.value}
          onClick={() => onChange(t.value)}
          className={cn(
            "flex items-center gap-1.5 whitespace-nowrap rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
            value === t.value ? "bg-white text-slate-900 shadow-sm" : "text-slate-600 hover:text-slate-900",
          )}
        >
          {t.label}
          {t.count !== undefined && <span className="rounded-full bg-slate-200 px-1.5 text-[10px] text-slate-700">{t.count}</span>}
        </button>
      ))}
    </div>
  );
}

export function Pagination({ page, pageSize, total, onChange }: { page: number; pageSize: number; total: number; onChange: (p: number) => void }) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  if (pages <= 1) return null;
  return (
    <div className="flex items-center justify-between px-1 pt-3 text-xs text-slate-500">
      <span>
        {total} 件中 {(page - 1) * pageSize + 1}–{Math.min(total, page * pageSize)}
      </span>
      <div className="flex gap-1">
        <button disabled={page <= 1} onClick={() => onChange(page - 1)} className="rounded border px-2 py-1 disabled:opacity-40">
          前へ
        </button>
        <span className="px-2 py-1">
          {page} / {pages}
        </span>
        <button disabled={page >= pages} onClick={() => onChange(page + 1)} className="rounded border px-2 py-1 disabled:opacity-40">
          次へ
        </button>
      </div>
    </div>
  );
}
