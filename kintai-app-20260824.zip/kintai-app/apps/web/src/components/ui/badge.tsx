import { cn } from "@/lib/utils";
import type { AttendanceStatus, DayType, RequestStatus } from "@kintai/shared";
import { ATTENDANCE_STATUS_LABEL, DAY_TYPE_LABEL, REQUEST_STATUS_LABEL } from "@kintai/shared";

type Tone = "gray" | "blue" | "green" | "amber" | "red" | "violet" | "sky";

const tones: Record<Tone, string> = {
  gray: "bg-slate-100 text-slate-700 ring-slate-200",
  blue: "bg-blue-50 text-blue-700 ring-blue-200",
  green: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  amber: "bg-amber-50 text-amber-800 ring-amber-200",
  red: "bg-rose-50 text-rose-700 ring-rose-200",
  violet: "bg-violet-50 text-violet-700 ring-violet-200",
  sky: "bg-sky-50 text-sky-700 ring-sky-200",
};

export function Badge({ tone = "gray", className, ...props }: React.HTMLAttributes<HTMLSpanElement> & { tone?: Tone }) {
  return <span className={cn("inline-flex items-center whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-medium ring-1 ring-inset", tones[tone], className)} {...props} />;
}

export function RequestStatusBadge({ status }: { status: RequestStatus }) {
  const tone: Tone = status === "APPROVED" ? "green" : status === "REJECTED" ? "red" : status === "PENDING" ? "amber" : "gray";
  return <Badge tone={tone}>{REQUEST_STATUS_LABEL[status]}</Badge>;
}

export function AttendanceStatusBadge({ status }: { status: AttendanceStatus }) {
  const tone: Tone = status === "LOCKED" ? "violet" : status === "CONFIRMED" ? "green" : "gray";
  return <Badge tone={tone}>{ATTENDANCE_STATUS_LABEL[status]}</Badge>;
}

export function DayTypeBadge({ dayType }: { dayType: DayType }) {
  const tone: Tone =
    dayType === "WORKDAY" ? "gray" : dayType === "PAID_LEAVE" || dayType === "SPECIAL_LEAVE" ? "sky" : dayType === "ABSENCE" ? "red" : dayType === "LEGAL_HOLIDAY" ? "red" : "amber";
  return <Badge tone={tone}>{DAY_TYPE_LABEL[dayType]}</Badge>;
}

export const FLAG_LABEL: Record<string, string> = {
  MISSING_IN: "出勤打刻なし",
  MISSING_OUT: "退勤打刻なし",
  NO_PUNCH: "打刻なし",
  BREAK_ADJUSTED: "休憩自動控除",
  UNAPPROVED_OVERTIME: "未承認残業",
  UNAPPROVED_HOLIDAY_WORK: "未承認休日出勤",
  WORK_ON_LEAVE: "休暇日に勤務",
  GEOFENCE_NG: "勤務地外打刻",
  LATE: "遅刻",
  LATE_APPROVED: "遅刻(承認済)",
  EARLY_LEAVE: "早退",
  EARLY_APPROVED: "早退(承認済)",
  HALF_LEAVE_AM: "午前半休",
  HALF_LEAVE_PM: "午後半休",
  MANUAL: "手修正",
  CORE_TIME_VIOLATION: "コアタイム違反",
  OVER_12H: "12h超",
};

const FLAG_TONE: Record<string, Tone> = {
  MISSING_IN: "red",
  MISSING_OUT: "red",
  NO_PUNCH: "red",
  UNAPPROVED_OVERTIME: "amber",
  UNAPPROVED_HOLIDAY_WORK: "amber",
  WORK_ON_LEAVE: "amber",
  GEOFENCE_NG: "amber",
  LATE: "amber",
  EARLY_LEAVE: "amber",
  CORE_TIME_VIOLATION: "amber",
  OVER_12H: "red",
  MANUAL: "violet",
  HALF_LEAVE_AM: "sky",
  HALF_LEAVE_PM: "sky",
  LATE_APPROVED: "gray",
  EARLY_APPROVED: "gray",
  BREAK_ADJUSTED: "gray",
};

export function FlagBadges({ flags, max = 3 }: { flags: string[]; max?: number }) {
  if (!flags.length) return null;
  const shown = flags.slice(0, max);
  const rest = flags.length - shown.length;
  return (
    <span className="inline-flex flex-wrap gap-1">
      {shown.map((f) => (
        <Badge key={f} tone={FLAG_TONE[f] ?? "gray"}>
          {FLAG_LABEL[f] ?? f}
        </Badge>
      ))}
      {rest > 0 && <Badge tone="gray">+{rest}</Badge>}
    </span>
  );
}
