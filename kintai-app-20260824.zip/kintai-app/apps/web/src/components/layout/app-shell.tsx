"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  Building2,
  CalendarDays,
  CalendarRange,
  ClipboardCheck,
  ClipboardList,
  Clock,
  FileSpreadsheet,
  Home,
  LayoutDashboard,
  LogOut,
  Menu,
  ScrollText,
  Settings,
  ShieldCheck,
  Users,
  X,
  Briefcase,
} from "lucide-react";
import { ROLE_LABEL, type Permission } from "@kintai/shared";
import { useAuth } from "@/lib/auth";
import { cn } from "@/lib/utils";

interface NavItem {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  perms?: Permission[];
  mobile?: boolean;
}

const EMPLOYEE_NAV: NavItem[] = [
  { href: "/", label: "ホーム（打刻）", icon: Home, mobile: true },
  { href: "/attendance", label: "勤怠照会", icon: CalendarDays, mobile: true },
  { href: "/requests", label: "申請", icon: ClipboardList, mobile: true },
  { href: "/approvals", label: "承認", icon: ClipboardCheck, perms: ["request:approve:department", "request:approve:company"], mobile: true },
];

const ADMIN_NAV: NavItem[] = [
  { href: "/admin", label: "管理ダッシュボード", icon: LayoutDashboard, perms: ["attendance:read:department", "attendance:read:company"] },
  { href: "/admin/attendance", label: "勤怠管理", icon: CalendarRange, perms: ["attendance:read:department", "attendance:read:company"] },
  { href: "/admin/employees", label: "従業員", icon: Users, perms: ["employee:read:company"] },
  { href: "/admin/work-patterns", label: "勤務パターン", icon: Briefcase, perms: ["master:write:company"] },
  { href: "/admin/holidays", label: "休日カレンダー", icon: CalendarDays, perms: ["master:write:company"] },
  { href: "/admin/closings", label: "月次締め・CSV", icon: FileSpreadsheet, perms: ["closing:execute:company", "export:csv:company"] },
  { href: "/admin/audit", label: "監査ログ", icon: ScrollText, perms: ["audit:read:company"] },
  { href: "/admin/settings", label: "会社設定", icon: Building2, perms: ["master:write:company"] },
];

function NavLink({ item, onClick }: { item: NavItem; onClick?: () => void }) {
  const pathname = usePathname();
  const active = item.href === "/" ? pathname === "/" : item.href === "/admin" ? pathname === "/admin" : pathname.startsWith(item.href);
  const Icon = item.icon;
  return (
    <Link
      href={item.href}
      onClick={onClick}
      className={cn(
        "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
        active ? "bg-white/10 text-white" : "text-slate-300 hover:bg-white/5 hover:text-white",
      )}
    >
      <Icon className="h-4 w-4 shrink-0" />
      {item.label}
    </Link>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const { user, logout, can } = useAuth();
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  if (!user) return null;
  const visible = (items: NavItem[]) => items.filter((i) => !i.perms || can(...i.perms));
  const empNav = visible(EMPLOYEE_NAV);
  const adminNav = visible(ADMIN_NAV);

  const Sidebar = (
    <div className="flex h-full flex-col bg-slate-900 text-white">
      <div className="flex items-center gap-2 px-5 py-5">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-sky-500/20 ring-1 ring-sky-400/40">
          <Clock className="h-5 w-5 text-sky-300" />
        </div>
        <div>
          <p className="text-sm font-bold leading-tight">勤怠管理</p>
          <p className="text-[11px] text-slate-400">{user.companyName}</p>
        </div>
        <button className="ml-auto rounded-md p-1 text-slate-400 hover:text-white lg:hidden" onClick={() => setOpen(false)} aria-label="閉じる">
          <X className="h-5 w-5" />
        </button>
      </div>
      <nav className="flex-1 space-y-5 overflow-y-auto px-3 pb-4">
        <div className="space-y-0.5">
          {empNav.map((i) => (
            <NavLink key={i.href} item={i} onClick={() => setOpen(false)} />
          ))}
        </div>
        {adminNav.length > 0 && (
          <div>
            <p className="mb-1 flex items-center gap-1 px-3 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
              <ShieldCheck className="h-3 w-3" /> 管理
            </p>
            <div className="space-y-0.5">
              {adminNav.map((i) => (
                <NavLink key={i.href} item={i} onClick={() => setOpen(false)} />
              ))}
            </div>
          </div>
        )}
      </nav>
      <div className="border-t border-white/10 px-4 py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-700 text-sm font-bold">{user.name.slice(0, 1)}</div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium">{user.name}</p>
            <p className="truncate text-[11px] text-slate-400">
              {user.departmentName ?? "-"} · {user.roles.map((r) => ROLE_LABEL[r]).join("/")}
            </p>
          </div>
        </div>
        <div className="mt-3 flex gap-2">
          <Link href="/settings" className="flex flex-1 items-center justify-center gap-1 rounded-lg bg-white/5 py-1.5 text-xs text-slate-300 hover:bg-white/10" onClick={() => setOpen(false)}>
            <Settings className="h-3.5 w-3.5" /> 設定
          </Link>
          <button onClick={() => void logout()} className="flex flex-1 items-center justify-center gap-1 rounded-lg bg-white/5 py-1.5 text-xs text-slate-300 hover:bg-white/10">
            <LogOut className="h-3.5 w-3.5" /> ログアウト
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen lg:flex">
      {/* Desktop sidebar */}
      <aside className="hidden w-64 shrink-0 lg:block">
        <div className="fixed inset-y-0 w-64">{Sidebar}</div>
      </aside>
      {/* Mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-slate-900/60" onClick={() => setOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-72 shadow-2xl">{Sidebar}</div>
        </div>
      )}
      <div className="flex min-h-screen flex-1 flex-col">
        {/* Mobile header */}
        <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b bg-white/90 px-4 backdrop-blur lg:hidden">
          <button onClick={() => setOpen(true)} className="rounded-md p-1.5 text-slate-600 hover:bg-slate-100" aria-label="メニュー">
            <Menu className="h-5 w-5" />
          </button>
          <span className="text-sm font-semibold">勤怠管理</span>
          <span className="ml-auto text-xs text-slate-500">{user.name}</span>
        </header>
        <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-5 pb-24 sm:px-6 lg:px-8 lg:pb-8">{children}</main>
        {/* Mobile bottom nav */}
        <nav className="fixed inset-x-0 bottom-0 z-30 grid border-t bg-white/95 backdrop-blur lg:hidden" style={{ gridTemplateColumns: `repeat(${empNav.length}, minmax(0, 1fr))` }}>
          {empNav.map((i) => {
            const Icon = i.icon;
            const active = i.href === "/" ? pathname === "/" : pathname.startsWith(i.href);
            return (
              <Link key={i.href} href={i.href} className={cn("flex flex-col items-center gap-0.5 py-2 text-[10px] font-medium", active ? "text-brand-600" : "text-slate-500")}>
                <Icon className="h-5 w-5" />
                {i.label.replace(/（.*）/, "")}
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
