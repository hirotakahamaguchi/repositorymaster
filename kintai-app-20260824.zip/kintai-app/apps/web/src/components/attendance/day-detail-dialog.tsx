"use client";

import { useMemo } from "react";
import { useRouter } from "next/navigation";
import { ClipboardEdit, History, MapPinOff, Palmtree } from "lucide-react";
import type { AttendanceDayDto, AttendanceRevisionDto, PunchDto } from "@kintai/shared";
import { addDays, DAY_TYPE_LABEL, PUNCH_TYPE_LABEL } from "@kintai/shared";
import { useApi } from "@/lib/use-api";
import { fmtDate, fmtDateTime, fmtDateTimeFull, fmtTime, localToIso, minutesToHm } from "@/lib/format";
import { cn } from "@/lib/utils";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge, AttendanceStatusBadge, DayTypeBadge, FLAG_LABEL } from "@/components/ui/badge";
import { Alert, Spinner } from "@/components/ui/misc";

type Rec = Record<string, unknown>;

/** 改定履歴の差分表示対象 */
const DIFF_FIELDS: { key: string; label: string; get: (o: Rec) => unknown; fmt: (v: unknown) => string }[] = [
  { key: "clockInAt", label: "出勤", get: (o) => o.clockInAt, fmt: (v) => (v == null ? "—" : fmtDateTime(String(v))) },
  { key: "clockOutAt", label: "退勤", get: (o) => o.clockOutAt, fmt: (v) => (v == null ? "—" : fmtDateTime(String(v))) },
  { key: "breakMinutes", label: "休憩", get: (o) => o.breakMinutes, fmt: (v) => (v == null ? "—" : minutesToHm(Number(v))) },
  { key: "dayType", label: "種別", get: (o) => o.dayType, fmt: (v) => (v == null ? "—" : ((DAY_TYPE_LABEL as Record<string, string>)[String(v)] ?? String(v))) },
  { key: "note", label: "備考", get: (o) => o.note, fmt: (v) => (v ? String(v) : "—") },
  {
    key: "manual",
    label: "手修正",
    get: (o) => (o.manual !== undefined ? Boolean(o.manual) : Array.isArray(o.flags) ? (o.flags as unknown[]).includes("MANUAL") : undefined),
    fmt: (v) => (v === undefined ? "—" : v ? "あり" : "なし"),
  },
];

function revisionDiff(rev: AttendanceRevisionDto) {
  const after = (rev.after ?? {}) as Rec;
  const before = (rev.before ?? null) as Rec | null;
  return DIFF_FIELDS.flatMap((f) => {
    const a = f.get(after);
    if (!before) return a === undefined ? [] : [{ key: f.key, label: f.label, before: null as string | null, after: f.fmt(a) }];
    const b = f.get(before);
    if (a === undefined && b === undefined) return [];
    if (JSON.stringify(a ?? null) === JSON.stringify(b ?? null)) return [];
    return [{ key: f.key, label: f.label, before: f.fmt(b), after: f.fmt(a) }];
  });
}

function DetailItem({ label, children, className }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={cn("rounded-xl bg-slate-50 px-3 py-2", className)}>
      <p className="text-[11px] font-medium text-slate-500">{label}</p>
      <div className="mt-0.5 text-sm text-slate-900">{children}</div>
    </div>
  );
}

export function DayDetailDialog({
  day,
  open,
  onClose,
  showRequestLinks,
  extraActions,
}: {
  day: AttendanceDayDto | null;
  open: boolean;
  onClose: () => void;
  /** 本人向け: 打刻修正申請 / 休暇申請へのリンクを表示 */
  showRequestLinks?: boolean;
  /** 管理者向けの追加操作（フッター） */
  extraActions?: React.ReactNode;
}) {
  const router = useRouter();
  const active = open && !!day;

  // 打刻: 対象日の前日 00:00 〜 翌々日 00:00 (JST) を取得し、当日分に絞る
  const punchQuery = useMemo(
    () => (day ? { employeeId: day.employeeId, from: localToIso(addDays(day.workDate, -1), "00:00"), to: localToIso(addDays(day.workDate, 2), "00:00") } : undefined),
    [day],
  );
  const punches = useApi<PunchDto[]>(active ? "/punches" : null, punchQuery, [day?.version]);
  const revisions = useApi<AttendanceRevisionDto[]>(active && day ? `/attendance/days/${day.id}/revisions` : null, undefined, [day?.version]);

  const dayPunches = useMemo(() => {
    if (!day || !punches.data) return [];
    const dayStart = new Date(localToIso(day.workDate, "00:00")).getTime();
    const dayEnd = new Date(localToIso(addDays(day.workDate, 1), "00:00")).getTime();
    const start = Math.min(dayStart, day.clockInAt ? new Date(day.clockInAt).getTime() : dayStart);
    const end = Math.max(dayEnd, day.clockOutAt ? new Date(day.clockOutAt).getTime() + 60_000 : dayEnd);
    return punches.data.filter((p) => {
      const t = new Date(p.punchedAt).getTime();
      return t >= start && t < end;
    });
  }, [day, punches.data]);

  if (!day) return null;

  const goRequest = (type: "CORRECTION" | "LEAVE") => router.push(`/requests?new=${type}&date=${day.workDate}`);

  return (
    <Dialog
      open={open}
      onClose={onClose}
      title={`${fmtDate(day.workDate)} の勤怠`}
      description={[day.employeeName ? `${day.employeeName}${day.employeeCode ? `（${day.employeeCode}）` : ""}` : null, day.workPatternName ? `勤務パターン: ${day.workPatternName}` : null].filter(Boolean).join(" · ") || undefined}
      size="lg"
      footer={
        <div className="flex w-full flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap gap-2">
            {showRequestLinks && (
              <>
                <Button variant="outline" size="sm" onClick={() => goRequest("CORRECTION")}>
                  <ClipboardEdit className="h-3.5 w-3.5" /> 打刻修正を申請
                </Button>
                <Button variant="outline" size="sm" onClick={() => goRequest("LEAVE")}>
                  <Palmtree className="h-3.5 w-3.5" /> 休暇を申請
                </Button>
              </>
            )}
            {extraActions}
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            閉じる
          </Button>
        </div>
      }
    >
      <div className="space-y-5">
        <div className="flex flex-wrap items-center gap-2">
          <DayTypeBadge dayType={day.dayType} />
          <AttendanceStatusBadge status={day.status} />
          {day.flags.map((f) => (
            <Badge key={f} tone={f === "MANUAL" ? "violet" : f.startsWith("MISSING") || f === "NO_PUNCH" || f === "OVER_12H" ? "red" : f.endsWith("APPROVED") || f === "BREAK_ADJUSTED" ? "gray" : "amber"}>
              {FLAG_LABEL[f] ?? f}
            </Badge>
          ))}
          <span className="ml-auto text-[11px] text-slate-400">
            v{day.version} · 更新 {fmtDateTimeFull(day.updatedAt)}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          <DetailItem label="出勤">
            <span className="tabular">{fmtTime(day.clockInAt)}</span>
            {day.clockInAt && <span className="ml-1 text-[11px] text-slate-500">{fmtDateTime(day.clockInAt).slice(0, 5)}</span>}
          </DetailItem>
          <DetailItem label="退勤">
            <span className="tabular">{fmtTime(day.clockOutAt)}</span>
            {day.clockOutAt && <span className="ml-1 text-[11px] text-slate-500">{fmtDateTime(day.clockOutAt).slice(0, 5)}</span>}
          </DetailItem>
          <DetailItem label="休憩">
            <span className="tabular">{minutesToHm(day.breakMinutes)}</span>
          </DetailItem>
          <DetailItem label="実労働">
            <span className="tabular font-semibold">{minutesToHm(day.workMinutes)}</span>
            <span className="ml-1 text-[11px] text-slate-500">/ 所定 {minutesToHm(day.scheduledMinutes)}</span>
          </DetailItem>
          <DetailItem label="所定外残業">
            <span className="tabular">{minutesToHm(day.overtimeMinutes)}</span>
          </DetailItem>
          <DetailItem label="法定外残業">
            <span className={cn("tabular", day.legalOvertimeMinutes > 0 && "font-medium text-amber-700")}>{minutesToHm(day.legalOvertimeMinutes)}</span>
          </DetailItem>
          <DetailItem label="深夜労働">
            <span className="tabular">{minutesToHm(day.lateNightMinutes)}</span>
          </DetailItem>
          <DetailItem label="休日労働">
            <span className="tabular">{minutesToHm(day.holidayWorkMinutes)}</span>
          </DetailItem>
          <DetailItem label="遅刻">
            <span className={cn("tabular", day.lateMinutes > 0 && "text-amber-700")}>{day.lateMinutes ? `${day.lateMinutes} 分` : "-"}</span>
          </DetailItem>
          <DetailItem label="早退">
            <span className={cn("tabular", day.earlyLeaveMinutes > 0 && "text-amber-700")}>{day.earlyLeaveMinutes ? `${day.earlyLeaveMinutes} 分` : "-"}</span>
          </DetailItem>
          <DetailItem label="勤務パターン" className="col-span-2">
            {day.workPatternName ?? <span className="text-slate-400">未設定</span>}
          </DetailItem>
          <DetailItem label="備考" className="col-span-2 sm:col-span-4">
            {day.note ? <span className="whitespace-pre-wrap">{day.note}</span> : <span className="text-slate-400">なし</span>}
          </DetailItem>
        </div>

        <section>
          <h4 className="mb-2 text-xs font-semibold text-slate-600">当日の打刻</h4>
          {punches.loading && !punches.data ? (
            <div className="flex items-center gap-2 py-2 text-xs text-slate-500">
              <Spinner className="h-4 w-4" /> 読み込み中...
            </div>
          ) : punches.error ? (
            <Alert tone="error">{punches.error}</Alert>
          ) : dayPunches.length === 0 ? (
            <p className="rounded-xl border border-dashed px-3 py-3 text-center text-xs text-slate-500">打刻はありません</p>
          ) : (
            <ul className="divide-y rounded-xl border text-sm">
              {dayPunches.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-3 px-3 py-1.5">
                  <span className="text-slate-700">{PUNCH_TYPE_LABEL[p.punchType]}</span>
                  <span className="tabular flex items-center gap-2 text-slate-900">
                    {fmtDateTime(p.punchedAt)}
                    {p.geofenceOk === false && (
                      <span className="inline-flex items-center gap-0.5 rounded bg-amber-50 px-1.5 text-[10px] text-amber-700 ring-1 ring-amber-200">
                        <MapPinOff className="h-3 w-3" /> エリア外
                      </span>
                    )}
                    <span className="w-12 text-right text-[10px] text-slate-400">{p.source}</span>
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section>
          <h4 className="mb-2 flex items-center gap-1 text-xs font-semibold text-slate-600">
            <History className="h-3.5 w-3.5" /> 改定履歴
          </h4>
          {revisions.loading && !revisions.data ? (
            <div className="flex items-center gap-2 py-2 text-xs text-slate-500">
              <Spinner className="h-4 w-4" /> 読み込み中...
            </div>
          ) : revisions.error ? (
            <Alert tone="error">{revisions.error}</Alert>
          ) : !revisions.data || revisions.data.length === 0 ? (
            <p className="rounded-xl border border-dashed px-3 py-3 text-center text-xs text-slate-500">改定履歴はありません</p>
          ) : (
            <ol className="relative ml-2 space-y-4 border-l border-slate-200 pl-4">
              {[...revisions.data]
                .sort((a, b) => b.version - a.version)
                .map((rev) => {
                  const diff = revisionDiff(rev);
                  return (
                    <li key={rev.id} className="relative">
                      <span className="absolute -left-[21px] top-1.5 h-2.5 w-2.5 rounded-full border-2 border-white bg-brand-500 ring-1 ring-brand-200" />
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs">
                        <Badge tone="blue">v{rev.version}</Badge>
                        <span className="tabular text-slate-500">{fmtDateTimeFull(rev.changedAt)}</span>
                        <span className="font-medium text-slate-800">{rev.changedBy?.name ?? "システム"}</span>
                        {rev.requestId && <Badge tone="sky">申請経由</Badge>}
                      </div>
                      <p className="mt-1 text-sm text-slate-800">{rev.reason}</p>
                      {diff.length > 0 && (
                        <dl className="mt-1.5 grid gap-x-3 gap-y-0.5 text-xs sm:grid-cols-[auto_1fr]">
                          {diff.map((d) => (
                            <div key={d.key} className="contents">
                              <dt className="text-slate-500">{d.label}</dt>
                              <dd className="tabular">
                                {d.before != null && (
                                  <>
                                    <span className="text-slate-400 line-through">{d.before}</span>
                                    <span className="mx-1 text-slate-400">→</span>
                                  </>
                                )}
                                <span className="font-medium text-slate-900">{d.after}</span>
                              </dd>
                            </div>
                          ))}
                        </dl>
                      )}
                    </li>
                  );
                })}
            </ol>
          )}
        </section>
      </div>
    </Dialog>
  );
}
