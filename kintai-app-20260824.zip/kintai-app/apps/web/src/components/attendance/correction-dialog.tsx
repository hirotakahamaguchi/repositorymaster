"use client";

import { useState } from "react";
import type { AttendanceDayDto, CorrectAttendanceInput, DayType } from "@kintai/shared";
import { addDays, DAY_TYPES, DAY_TYPE_LABEL, hmToMinutes } from "@kintai/shared";
import { api, ApiRequestError, errorMessage } from "@/lib/api";
import { fmtDate, isoToHm, localToIso, minutesToHm } from "@/lib/format";
import { useToast } from "@/components/ui/toast";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/input";
import { Alert } from "@/components/ui/misc";

export function CorrectionDialog({
  day,
  open,
  onClose,
  onSaved,
  onConflict,
}: {
  day: AttendanceDayDto | null;
  open: boolean;
  onClose: () => void;
  /** 保存成功時（更新後の日次データ） */
  onSaved: (updated: AttendanceDayDto) => void;
  /** 409 競合時（呼び出し側で再読み込み） */
  onConflict?: () => void;
}) {
  if (!day || !open) return null;
  // 対象日/バージョンが変わったらフォームを初期化し直す
  return <CorrectionForm key={`${day.id}:${day.version}`} day={day} onClose={onClose} onSaved={onSaved} onConflict={onConflict} />;
}

function CorrectionForm({ day, onClose, onSaved, onConflict }: { day: AttendanceDayDto; onClose: () => void; onSaved: (d: AttendanceDayDto) => void; onConflict?: () => void }) {
  const toast = useToast();
  const origIn = isoToHm(day.clockInAt);
  const origOut = isoToHm(day.clockOutAt);
  const [inHm, setInHm] = useState(origIn);
  const [outHm, setOutHm] = useState(origOut);
  const [breakMin, setBreakMin] = useState(String(day.breakMinutes));
  const [dayType, setDayType] = useState<DayType>(day.dayType);
  const [note, setNote] = useState(day.note ?? "");
  const [reason, setReason] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const breakNum = Number(breakMin);
  const breakInvalid = breakMin.trim() === "" || !Number.isInteger(breakNum) || breakNum < 0 || breakNum > 1440;
  const outIsNextDay = !!inHm && !!outHm && hmToMinutes(outHm) < hmToMinutes(inHm);
  const reasonMissing = reason.trim().length === 0;

  /** "HH:mm" → ISO。未変更なら元の ISO をそのまま使う（夜勤など日付跨ぎの保持） */
  const toIso = (hm: string, orig: string, origIso: string | null, nextDay: boolean): string | null => {
    if (!hm) return null;
    if (hm === orig && origIso) return origIso;
    return localToIso(nextDay ? addDays(day.workDate, 1) : day.workDate, hm);
  };

  const submit = async () => {
    if (reasonMissing || breakInvalid) return;
    setPending(true);
    setError(null);
    const clockInAt = toIso(inHm, origIn, day.clockInAt, false);
    // 出勤・退勤とも未変更なら元の ISO を保持。どちらかが変わった場合は退勤の日付を再計算する
    const clockOutAt = !outHm ? null : outHm === origOut && inHm === origIn && day.clockOutAt ? day.clockOutAt : localToIso(outIsNextDay ? addDays(day.workDate, 1) : day.workDate, outHm);
    const body: CorrectAttendanceInput = {
      clockInAt,
      clockOutAt,
      breakMinutes: breakNum,
      dayType,
      note: note.trim(),
      reason: reason.trim(),
      version: day.version,
    };
    try {
      const res = await api.patch<AttendanceDayDto>(`/attendance/days/${day.id}`, body);
      toast.success(`${fmtDate(day.workDate)} の勤怠を修正しました`);
      onSaved(res);
      onClose();
    } catch (e) {
      if (e instanceof ApiRequestError && e.status === 409) {
        toast.error("他のユーザが更新しました。再読み込みしてください");
        onConflict?.();
        onClose();
      } else {
        setError(errorMessage(e));
      }
    } finally {
      setPending(false);
    }
  };

  return (
    <Dialog
      open
      onClose={onClose}
      title={`勤怠の修正 — ${fmtDate(day.workDate)}`}
      description={day.employeeName ? `${day.employeeName}${day.employeeCode ? `（${day.employeeCode}）` : ""}` : undefined}
      size="md"
      footer={
        <>
          <Button variant="outline" onClick={onClose} disabled={pending}>
            キャンセル
          </Button>
          <Button onClick={() => void submit()} loading={pending} disabled={reasonMissing || breakInvalid}>
            保存する
          </Button>
        </>
      }
    >
      <form
        className="space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          void submit();
        }}
      >
        {error && <Alert tone="error">{error}</Alert>}
        {day.flags.includes("MANUAL") && (
          <Alert tone="info">この日は手修正済みです。保存すると新しい改定として記録されます（v{day.version} → v{day.version + 1}）。</Alert>
        )}
        <div className="grid grid-cols-2 gap-3">
          <Field label="出勤時刻" hint={origIn ? `現在 ${origIn}` : "現在 未打刻"}>
            <Input type="time" value={inHm} onChange={(e) => setInHm(e.target.value)} className="tabular" />
          </Field>
          <Field label="退勤時刻" hint={outIsNextDay ? "翌日として登録されます" : origOut ? `現在 ${origOut}` : "現在 未打刻"}>
            <Input type="time" value={outHm} onChange={(e) => setOutHm(e.target.value)} className="tabular" />
          </Field>
          <Field label="休憩（分）" hint={`現在 ${minutesToHm(day.breakMinutes)}`} error={breakInvalid ? "0〜1440 の整数で入力してください" : null}>
            <Input type="number" inputMode="numeric" min={0} max={1440} step={1} value={breakMin} onChange={(e) => setBreakMin(e.target.value)} className="tabular" />
          </Field>
          <Field label="日種別">
            <Select value={dayType} onChange={(e) => setDayType(e.target.value as DayType)}>
              {DAY_TYPES.map((t) => (
                <option key={t} value={t}>
                  {DAY_TYPE_LABEL[t]}
                </option>
              ))}
            </Select>
          </Field>
        </div>
        <Field label="備考" hint="勤怠レコードに残る備考（任意）">
          <Textarea value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} rows={2} placeholder="例: 客先直行のため出勤打刻なし" />
        </Field>
        <Field label="修正理由（必須）" error={reasonMissing && reason.length > 0 ? "修正理由を入力してください" : null}>
          <Textarea value={reason} onChange={(e) => setReason(e.target.value)} maxLength={500} rows={2} placeholder="例: 本人申告により出勤時刻を修正" required />
        </Field>
        <p className="text-[11px] text-slate-500">時刻を空にするとその打刻は「なし」として保存されます。修正内容は改定履歴に記録され、手修正フラグが付きます。</p>
        <button type="submit" className="hidden" />
      </form>
    </Dialog>
  );
}
