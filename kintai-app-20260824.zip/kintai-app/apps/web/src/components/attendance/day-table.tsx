"use client";

import type { AttendanceDayDto, AttendanceMonthSummary, HolidayDto } from "@kintai/shared";
import { daysInMonth, WEEKDAY_JA } from "@kintai/shared";
import { cn } from "@/lib/utils";
import { fmtTime, minutesToHm, todayLocal, weekdayOf } from "@/lib/format";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { AttendanceStatusBadge, DayTypeBadge, FlagBadges } from "@/components/ui/badge";

/** GET /attendance/me, GET /attendance/employees/:id のレスポンス */
export interface AttendanceMonthDto {
  yearMonth: string;
  days: AttendanceDayDto[];
  summary: AttendanceMonthSummary;
}

/** 月のカレンダー日 1 行分（勤怠レコードが無い日は day=null） */
export interface CalendarRow {
  date: string;
  day: AttendanceDayDto | null;
  holiday: HolidayDto | null;
  weekday: number;
}

export function buildCalendarRows(yearMonth: string, days: AttendanceDayDto[], holidays?: HolidayDto[] | null): CalendarRow[] {
  const byDate = new Map(days.map((d) => [d.workDate, d]));
  const hol = new Map((holidays ?? []).map((h) => [h.date, h]));
  const n = daysInMonth(yearMonth);
  const rows: CalendarRow[] = [];
  for (let i = 1; i <= n; i++) {
    const date = `${yearMonth}-${String(i).padStart(2, "0")}`;
    rows.push({ date, day: byDate.get(date) ?? null, holiday: hol.get(date) ?? null, weekday: weekdayOf(date) });
  }
  return rows;
}

const NON_WORK_DAY_TYPES = new Set(["LEGAL_HOLIDAY", "NON_LEGAL_HOLIDAY", "COMPANY_HOLIDAY"]);

/** 日付セルの色: 土=青, 日・祝=赤 */
export function dateTone(row: CalendarRow): string {
  const isHoliday = !!row.holiday || (row.day ? row.day.dayType === "LEGAL_HOLIDAY" || row.day.dayType === "COMPANY_HOLIDAY" : false);
  if (row.weekday === 0 || isHoliday) return "text-rose-600";
  if (row.weekday === 6) return "text-blue-600";
  return "text-slate-900";
}

function Min({ value, emphasize }: { value: number; emphasize?: "amber" | "violet" }) {
  if (!value) return <span className="text-slate-300">-</span>;
  return <span className={cn("tabular", emphasize === "amber" && "font-medium text-amber-700", emphasize === "violet" && "font-medium text-violet-700")}>{minutesToHm(value)}</span>;
}

export function DayTable({
  days,
  yearMonth,
  onRowClick,
  holidays,
  renderActions,
  className,
}: {
  days: AttendanceDayDto[];
  yearMonth: string;
  onRowClick?: (day: AttendanceDayDto) => void;
  holidays?: HolidayDto[] | null;
  /** 行末の操作列（管理者向け）。戻り値が無い場合は列を表示しない */
  renderActions?: (row: CalendarRow) => React.ReactNode;
  className?: string;
}) {
  const rows = buildCalendarRows(yearMonth, days, holidays);
  const today = todayLocal();
  const hasActions = !!renderActions;

  return (
    <Table className={className}>
      <THead>
        <TR className="hover:bg-transparent">
          <TH>日付</TH>
          <TH>種別</TH>
          <TH className="text-right">出勤</TH>
          <TH className="text-right">退勤</TH>
          <TH className="text-right">休憩</TH>
          <TH className="text-right">実労働</TH>
          <TH className="text-right">残業</TH>
          <TH className="text-right">深夜</TH>
          <TH>フラグ</TH>
          <TH>状態</TH>
          {hasActions && <TH className="text-right">操作</TH>}
        </TR>
      </THead>
      <TBody>
        {rows.map((row) => {
          const d = row.day;
          const isToday = row.date === today;
          const offDay = !!row.holiday || row.weekday === 0 || row.weekday === 6 || (d ? NON_WORK_DAY_TYPES.has(d.dayType) : false);
          const clickable = !!d && !!onRowClick;
          return (
            <TR
              key={row.date}
              onClick={clickable ? () => onRowClick(d) : undefined}
              className={cn(offDay && "bg-slate-50/70", clickable && "cursor-pointer", isToday && "ring-1 ring-inset ring-brand-200 bg-brand-50/40")}
              aria-current={isToday ? "date" : undefined}
            >
              <TD className={cn("whitespace-nowrap font-medium", dateTone(row))}>
                <span className="tabular">
                  {Number(row.date.slice(8))}
                  <span className="ml-0.5 text-xs">({WEEKDAY_JA[row.weekday]})</span>
                </span>
                {row.holiday && <span className="ml-1.5 text-[10px] font-normal text-rose-500">{row.holiday.name}</span>}
              </TD>
              <TD>{d ? <DayTypeBadge dayType={d.dayType} /> : <span className="text-xs text-slate-300">{row.holiday ? "休日" : "-"}</span>}</TD>
              {d ? (
                <>
                  <TD className="tabular text-right">{fmtTime(d.clockInAt)}</TD>
                  <TD className="tabular text-right">{fmtTime(d.clockOutAt)}</TD>
                  <TD className="text-right">
                    <Min value={d.breakMinutes} />
                  </TD>
                  <TD className="tabular text-right font-medium text-slate-900">{d.workMinutes || d.clockInAt ? minutesToHm(d.workMinutes) : <span className="text-slate-300">-</span>}</TD>
                  <TD className="text-right">
                    <Min value={d.overtimeMinutes} emphasize="amber" />
                  </TD>
                  <TD className="text-right">
                    <Min value={d.lateNightMinutes} emphasize="violet" />
                  </TD>
                  <TD>
                    <FlagBadges flags={d.flags} />
                  </TD>
                  <TD>
                    <AttendanceStatusBadge status={d.status} />
                  </TD>
                </>
              ) : (
                <>
                  <TD className="text-right text-slate-300">-</TD>
                  <TD className="text-right text-slate-300">-</TD>
                  <TD className="text-right text-slate-300">-</TD>
                  <TD className="text-right text-slate-300">-</TD>
                  <TD className="text-right text-slate-300">-</TD>
                  <TD className="text-right text-slate-300">-</TD>
                  <TD />
                  <TD />
                </>
              )}
              {hasActions && (
                <TD className="text-right" onClick={(e) => e.stopPropagation()}>
                  <div className="flex items-center justify-end gap-1">{renderActions(row)}</div>
                </TD>
              )}
            </TR>
          );
        })}
      </TBody>
    </Table>
  );
}
