"use client";

import type { AttendanceMonthSummary } from "@kintai/shared";
import { minutesToHm } from "@/lib/format";
import { Stat } from "@/components/ui/misc";
import { Badge } from "@/components/ui/badge";

/** 月次サマリのアラートコード → ラベル/色 */
export const ALERT_LABEL: Record<string, string> = {
  OVERTIME_WARN: "残業 45h 超",
  OVERTIME_LIMIT: "残業上限超過",
  MISSING_PUNCH: "打刻漏れ",
  UNAPPROVED_OVERTIME: "未承認残業",
  UNCONFIRMED: "未確定",
};
const ALERT_TONE: Record<string, "amber" | "red" | "gray"> = {
  OVERTIME_WARN: "amber",
  OVERTIME_LIMIT: "red",
  MISSING_PUNCH: "red",
  UNAPPROVED_OVERTIME: "amber",
};

export function AlertBadges({ alerts }: { alerts: string[] }) {
  if (!alerts.length) return <span className="text-slate-300">-</span>;
  return (
    <span className="inline-flex flex-wrap gap-1">
      {alerts.map((a) => (
        <Badge key={a} tone={ALERT_TONE[a] ?? "gray"}>
          {ALERT_LABEL[a] ?? a}
        </Badge>
      ))}
    </span>
  );
}

export function overtimeTone(alerts: string[]): "default" | "warn" | "danger" {
  if (alerts.includes("OVERTIME_LIMIT")) return "danger";
  if (alerts.includes("OVERTIME_WARN")) return "warn";
  return "default";
}

/** 勤怠照会 / 管理者の従業員詳細で共通の月次サマリカード */
export function SummaryStats({ summary: s, paidLeaveRemaining }: { summary: AttendanceMonthSummary; paidLeaveRemaining?: number | null }) {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
      <Stat label="出勤日数" value={`${s.actualWorkDays}`} sub={`所定 ${s.scheduledDays} 日${s.absenceDays ? ` / 欠勤 ${s.absenceDays}` : ""}`} />
      <Stat label="総労働時間" value={minutesToHm(s.workMinutes)} sub={`所定外 ${minutesToHm(s.overtimeMinutes)}`} />
      <Stat
        label="残業（法定外）"
        value={minutesToHm(s.legalOvertimeMinutes)}
        tone={overtimeTone(s.alerts)}
        sub={s.alerts.includes("OVERTIME_LIMIT") ? "上限超過" : s.alerts.includes("OVERTIME_WARN") ? "45h 超過注意" : s.holidayWorkMinutes ? `休日労働 ${minutesToHm(s.holidayWorkMinutes)}` : undefined}
      />
      <Stat label="深夜労働" value={minutesToHm(s.lateNightMinutes)} />
      <Stat label="遅刻 / 早退" value={`${s.lateCount} / ${s.earlyLeaveCount}`} tone={s.lateCount + s.earlyLeaveCount > 0 ? "warn" : "default"} />
      <Stat label="有給取得" value={`${s.paidLeaveDays} 日`} sub={paidLeaveRemaining != null ? `残 ${paidLeaveRemaining} 日` : undefined} />
    </div>
  );
}
