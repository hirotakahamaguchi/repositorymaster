"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Coffee, LogIn, LogOut, MapPin, MapPinOff, Play, WifiOff } from "lucide-react";
import type { CreatePunchInput, DashboardDto, PunchDto, PunchType } from "@kintai/shared";
import { PUNCH_TYPE_LABEL, haversineMeters } from "@kintai/shared";
import { api, errorMessage } from "@/lib/api";
import { uuid, cn } from "@/lib/utils";
import { enqueue, flushQueue, loadQueue } from "@/lib/punch-queue";
import { useToast } from "@/components/ui/toast";
import { fmtTime } from "@/lib/format";

interface Geo {
  latitude: number;
  longitude: number;
  accuracyM: number;
  distanceM: number | null;
  inside: boolean | null;
}

function useClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return now;
}

export function PunchCard({ dashboard, onPunched }: { dashboard: DashboardDto; onPunched: (p: PunchDto) => void }) {
  const toast = useToast();
  const now = useClock();
  const [geo, setGeo] = useState<Geo | null>(null);
  const [geoError, setGeoError] = useState<string | null>(null);
  const [geoLoading, setGeoLoading] = useState(true);
  const [pending, setPending] = useState<PunchType | null>(null);
  const [queued, setQueued] = useState(0);
  const [online, setOnline] = useState(true);
  const watchRef = useRef<number | null>(null);

  const fence = dashboard.geofence;

  const updateGeo = useCallback(
    (pos: GeolocationPosition) => {
      const { latitude, longitude, accuracy } = pos.coords;
      const distanceM = fence ? haversineMeters(latitude, longitude, fence.latitude, fence.longitude) : null;
      setGeo({
        latitude,
        longitude,
        accuracyM: accuracy,
        distanceM,
        inside: fence && distanceM != null ? distanceM <= fence.radiusM + accuracy : null,
      });
      setGeoError(null);
      setGeoLoading(false);
    },
    [fence],
  );

  useEffect(() => {
    if (!("geolocation" in navigator)) {
      queueMicrotask(() => {
        setGeoLoading(false);
        setGeoError("この端末では位置情報が利用できません");
      });
      return;
    }
    watchRef.current = navigator.geolocation.watchPosition(
      updateGeo,
      (err) => {
        setGeoLoading(false);
        setGeoError(err.code === err.PERMISSION_DENIED ? "位置情報の利用が許可されていません（打刻は可能です）" : "位置情報を取得できませんでした");
      },
      { enableHighAccuracy: true, maximumAge: 15000, timeout: 10000 },
    );
    return () => {
      if (watchRef.current != null) navigator.geolocation.clearWatch(watchRef.current);
    };
  }, [updateGeo]);

  // オフラインキュー再送
  useEffect(() => {
    queueMicrotask(() => {
      setOnline(navigator.onLine);
      setQueued(loadQueue().length);
    });
    const flush = async () => {
      setOnline(true);
      if (loadQueue().length === 0) return;
      const { sent, remaining } = await flushQueue();
      setQueued(remaining);
      if (sent.length) {
        toast.success(`オフライン中の打刻 ${sent.length} 件を送信しました`);
        sent.forEach(onPunched);
      }
    };
    const off = () => setOnline(false);
    window.addEventListener("online", flush);
    window.addEventListener("offline", off);
    void flush();
    return () => {
      window.removeEventListener("online", flush);
      window.removeEventListener("offline", off);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const punch = async (type: PunchType) => {
    if (pending) return;
    setPending(type);
    const body: CreatePunchInput = {
      punchType: type,
      punchedAt: new Date().toISOString(),
      source: /Mobi|Android|iPhone/i.test(navigator.userAgent) ? "MOBILE" : "WEB",
      clientRequestId: uuid(),
      latitude: geo?.latitude,
      longitude: geo?.longitude,
      accuracyM: geo ? Math.round(geo.accuracyM) : undefined,
      deviceInfo: { ua: navigator.userAgent.slice(0, 200), platform: navigator.platform },
    };
    try {
      const res = await api.post<{ punch: PunchDto; duplicate: boolean }>("/punches", body);
      onPunched(res.punch);
      toast.success(`${PUNCH_TYPE_LABEL[type]}を記録しました（${fmtTime(res.punch.punchedAt)}）`);
    } catch (e) {
      const status = (e as { status?: number }).status;
      if (!status || status >= 500 || !navigator.onLine) {
        enqueue(body);
        setQueued(loadQueue().length);
        toast.toast(`通信できないため打刻を端末に保存しました。オンライン復帰後に自動送信します`, "info");
      } else {
        toast.error(errorMessage(e));
      }
    } finally {
      setPending(null);
    }
  };

  const { working, onBreak } = dashboard;
  const canIn = !working;
  const canOut = working && !onBreak;
  const canBreakStart = working && !onBreak;
  const canBreakEnd = working && onBreak;

  const timeStr = new Intl.DateTimeFormat("ja-JP", { timeZone: "Asia/Tokyo", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).format(now);
  const dateStr = new Intl.DateTimeFormat("ja-JP", { timeZone: "Asia/Tokyo", year: "numeric", month: "long", day: "numeric", weekday: "short" }).format(now);

  return (
    <div className="overflow-hidden rounded-3xl bg-slate-900 text-white shadow-xl">
      <div className="px-6 pt-6 pb-4 text-center">
        <p className="text-sm text-slate-400">{dateStr}</p>
        <p className="tabular mt-1 text-5xl font-bold tracking-tight sm:text-6xl">{timeStr}</p>
        <div className="mt-3 flex items-center justify-center gap-2 text-xs">
          <span className={cn("inline-flex items-center gap-1 rounded-full px-2.5 py-1 font-medium", working ? (onBreak ? "bg-amber-500/20 text-amber-300" : "bg-emerald-500/20 text-emerald-300") : "bg-slate-700 text-slate-300")}>
            <span className={cn("h-1.5 w-1.5 rounded-full", working ? (onBreak ? "bg-amber-400" : "bg-emerald-400 animate-pulse") : "bg-slate-400")} />
            {working ? (onBreak ? "休憩中" : "勤務中") : "未出勤 / 退勤済"}
          </span>
          {dashboard.lastPunch && (
            <span className="text-slate-400">
              最終: {PUNCH_TYPE_LABEL[dashboard.lastPunch.punchType]} {fmtTime(dashboard.lastPunch.punchedAt)}
            </span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 px-6 pb-5">
        <PunchButton icon={LogIn} label="出勤" tone="emerald" disabled={!canIn} loading={pending === "IN"} onClick={() => punch("IN")} />
        <PunchButton icon={LogOut} label="退勤" tone="rose" disabled={!canOut} loading={pending === "OUT"} onClick={() => punch("OUT")} />
        <PunchButton icon={Coffee} label="休憩開始" tone="amber" small disabled={!canBreakStart} loading={pending === "BREAK_START"} onClick={() => punch("BREAK_START")} />
        <PunchButton icon={Play} label="休憩終了" tone="sky" small disabled={!canBreakEnd} loading={pending === "BREAK_END"} onClick={() => punch("BREAK_END")} />
      </div>

      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 border-t border-white/10 bg-white/5 px-6 py-3 text-xs text-slate-300">
        {geoLoading && <span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5 animate-pulse" /> 位置情報を取得中...</span>}
        {geo && fence && (
          <span className={cn("inline-flex items-center gap-1", geo.inside ? "text-emerald-300" : "text-amber-300")}>
            {geo.inside ? <MapPin className="h-3.5 w-3.5" /> : <MapPinOff className="h-3.5 w-3.5" />}
            {geo.inside ? "勤務地エリア内" : "勤務地エリア外"}（オフィスまで {Math.round(geo.distanceM ?? 0)}m / 精度±{Math.round(geo.accuracyM)}m）
          </span>
        )}
        {geo && !fence && <span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5" /> 位置情報を記録します</span>}
        {geoError && <span className="inline-flex items-center gap-1 text-slate-400"><MapPinOff className="h-3.5 w-3.5" /> {geoError}</span>}
        {!online && <span className="inline-flex items-center gap-1 text-amber-300"><WifiOff className="h-3.5 w-3.5" /> オフライン</span>}
        {queued > 0 && <span className="text-amber-300">未送信の打刻 {queued} 件</span>}
      </div>
    </div>
  );
}

function PunchButton({
  icon: Icon,
  label,
  tone,
  disabled,
  loading,
  onClick,
  small,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  tone: "emerald" | "rose" | "amber" | "sky";
  disabled?: boolean;
  loading?: boolean;
  onClick: () => void;
  small?: boolean;
}) {
  const tones = {
    emerald: "bg-emerald-500 hover:bg-emerald-400 text-white shadow-emerald-500/30",
    rose: "bg-rose-500 hover:bg-rose-400 text-white shadow-rose-500/30",
    amber: "bg-amber-400/90 hover:bg-amber-400 text-slate-900 shadow-amber-400/20",
    sky: "bg-sky-400/90 hover:bg-sky-400 text-slate-900 shadow-sky-400/20",
  }[tone];
  return (
    <button
      onClick={onClick}
      disabled={disabled || loading}
      className={cn(
        "flex items-center justify-center gap-2 rounded-2xl font-bold shadow-lg transition-all active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-30 disabled:shadow-none",
        small ? "h-14 text-sm" : "h-20 text-xl",
        tones,
      )}
    >
      <Icon className={small ? "h-4 w-4" : "h-6 w-6"} />
      {loading ? "送信中..." : label}
    </button>
  );
}
